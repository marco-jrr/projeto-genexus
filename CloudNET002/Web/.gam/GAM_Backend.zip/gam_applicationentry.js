/*
               File: GAM_ApplicationEntry
        Description: GAM_Application
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:35:16.17
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_applicationentry', false, function () {
   this.ServerClass =  "gam_applicationentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_applicationentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.subGridapplanguages_Recordcount=gx.fn.getIntegerValue("subGridapplanguages_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Clientaccessstatus=function()
   {
      return this.validCliEvt("Validv_Clientaccessstatus", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCLIENTACCESSSTATUS");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV78ClientAccessStatus , "on" ) == 0 || gx.text.compare( this.AV78ClientAccessStatus , "off" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Status"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Clientrevoked=function()
   {
      return this.validCliEvt("Validv_Clientrevoked", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCLIENTREVOKED");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV18ClientRevoked)===0) || new gx.date.gxdate( this.AV18ClientRevoked ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Client Revoked"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Delegateauthorizationversion=function()
   {
      return this.validCliEvt("Validv_Delegateauthorizationversion", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vDELEGATEAUTHORIZATIONVERSION");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV91DelegateAuthorizationVersion , "10" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Version"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Ssorestmode=function()
   {
      return this.validCliEvt("Validv_Ssorestmode", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vSSORESTMODE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV63SSORestMode , "server" ) == 0 || gx.text.compare( this.AV63SSORestMode , "client" ) == 0 || (gx.text.compare('',this.AV63SSORestMode)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Mode"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Stsmode=function()
   {
      return this.validCliEvt("Validv_Stsmode", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vSTSMODE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV48STSMode , "server" ) == 0 || gx.text.compare( this.AV48STSMode , "gettoken" ) == 0 || gx.text.compare( this.AV48STSMode , "checktoken" ) == 0 || gx.text.compare( this.AV48STSMode , "fulltoken" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Mode"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Miniappmode=function()
   {
      return this.validCliEvt("Validv_Miniappmode", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vMINIAPPMODE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV99MiniAppMode , "server" ) == 0 || gx.text.compare( this.AV99MiniAppMode , "client" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Mode"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s142_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UI_REMOTEAUTHENTICATIONWEB' Routine */
         if ( this.AV11ClientAllowRemoteAuth )
         {
            gx.fn.setCtrlProperty("TBLWEBAUTH","Visible", true );
            gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", true );
         }
         else
         {
            gx.fn.setCtrlProperty("TBLWEBAUTH","Visible", false );
            if ( ! this.AV61ClientAllowRemoteRESTAuth )
            {
               gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", false );
            }
         }
      }, arguments);
   };
   this.s152_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UI_REMOTEAUTHENTICATIONREST' Routine */
         if ( this.AV61ClientAllowRemoteRESTAuth )
         {
            gx.fn.setCtrlProperty("TBLRESTAUTH","Visible", true );
            gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", true );
         }
         else
         {
            gx.fn.setCtrlProperty("TBLRESTAUTH","Visible", false );
            if ( ! this.AV11ClientAllowRemoteAuth )
            {
               gx.fn.setCtrlProperty("TBLGENERALAUTH","Visible", false );
            }
         }
      }, arguments);
   };
   this.s162_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UI_DELEGATEAUTHORIZATION' Routine */
         if ( this.AV5AccessRequiresPermission )
         {
            gx.fn.setCtrlProperty("TBLDELEGATEAUTHORIZATION","Visible", true );
            if ( this.AV94IsAuthorizationDelegated )
            {
               gx.fn.setCtrlProperty("TBLDELEGATEAUTHORIZATIONPROP","Visible", true );
            }
            else
            {
               gx.fn.setCtrlProperty("TBLDELEGATEAUTHORIZATIONPROP","Visible", false );
            }
         }
         else
         {
            gx.fn.setCtrlProperty("TBLDELEGATEAUTHORIZATION","Visible", false );
         }
      }, arguments);
   };
   this.s202_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UI_STSPROTOCOL' Routine */
         if ( this.AV46STSProtocolEnable )
         {
            gx.fn.setCtrlProperty("TABLESTS","Visible", true );
            if ( gx.text.compare( this.AV48STSMode , "server" ) == 0 )
            {
               gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
               gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", false );
               gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", false );
            }
            else if ( gx.text.compare( this.AV48STSMode , "gettoken" ) == 0 )
            {
               gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", false );
               gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", true );
               gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
            }
            else if ( gx.text.compare( this.AV48STSMode , "checktoken" ) == 0 )
            {
               gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
               gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", false );
               gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
            }
            else if ( gx.text.compare( this.AV48STSMode , "fulltoken" ) == 0 )
            {
               gx.fn.setCtrlProperty("TABLESTSSERVERCHECKTOKEN","Visible", true );
               gx.fn.setCtrlProperty("TABLESTSCLIENTGETTOKEN","Visible", true );
               gx.fn.setCtrlProperty("TABLESTSCLIENT","Visible", true );
            }
         }
         else
         {
            gx.fn.setCtrlProperty("TABLESTS","Visible", false );
         }
      }, arguments);
   };
   this.s132_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e29101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Gam_headerentry_tableback_Click Routine */
         this.clearMessages();
         this.call("gam_wwapplications.aspx", [], null, []);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e30101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Clientallowremoteauth_Controlvaluechanged Routine */
         this.clearMessages();
         this.s142_client();
         if ( gx.text.compare( this.Gx_mode , "INS" ) == 0 && ( this.AV11ClientAllowRemoteAuth == true ) )
         {
            this.AV83ClientAllowGetUserData =  true  ;
         }
         this.refreshOutputs([{"av":"AV83ClientAllowGetUserData","fld":"vCLIENTALLOWGETUSERDATA"},{"av":"gx.fn.getCtrlProperty(\u0027TBLGENERALAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLGENERALAUTH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLWEBAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLWEBAUTH","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e31101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Clientallowremoterestauth_Controlvaluechanged Routine */
         this.clearMessages();
         this.s152_client();
         if ( gx.text.compare( this.Gx_mode , "INS" ) == 0 && ( this.AV61ClientAllowRemoteRESTAuth == true ) )
         {
            this.AV84ClientAllowGetUserDataREST =  true  ;
         }
         this.refreshOutputs([{"av":"AV84ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"gx.fn.getCtrlProperty(\u0027TBLGENERALAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLGENERALAUTH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLRESTAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLRESTAUTH","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e32101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Accessrequirespermission_Isvalid Routine */
         this.clearMessages();
         this.s162_client();
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATIONPROP\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATIONPROP","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATION\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATION","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e33101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Isauthorizationdelegated_Isvalid Routine */
         this.clearMessages();
         this.s162_client();
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATIONPROP\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATIONPROP","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATION\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATION","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e15101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ChangeClientSecret' Routine */
         this.clearMessages();
         this.AV105Window.Url =  gx.http.formatLink("gam_applicationclientsecret.aspx",[this.AV14ClientId])  ;
         this.AV105Window.ReturnParms =  []  ;
         this.popupOpen(this.AV105Window) ;
         this.call("gam_applicationentry.aspx", ["DSP", this.AV37Id], null, ["Mode","Id"]);
         this.refreshOutputs([{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e12101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Delete' Routine */
         this.clearMessages();
         this.call("gam_applicationentry.aspx", ["DLT", this.AV37Id], null, ["Mode","Id"]);
         this.refreshOutputs([{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e13101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Permissions' Routine */
         this.clearMessages();
         this.call("gam_wwapppermissions.aspx", [this.AV37Id], null, ["ApplicationId"]);
         this.refreshOutputs([{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e14101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Menus' Routine */
         this.clearMessages();
         this.call("gam_wwappmenus.aspx", [this.AV37Id], null, ["ApplicationId"]);
         this.refreshOutputs([{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e11101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Edit' Routine */
         this.clearMessages();
         this.call("gam_applicationentry.aspx", ["UPD", this.AV37Id], null, ["Mode","Id"]);
         this.refreshOutputs([{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e34101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Stsmode_Controlvaluechanged Routine */
         this.clearMessages();
         this.s202_client();
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSSERVERCHECKTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSSERVERCHECKTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENTGETTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENTGETTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENT\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTS\u0027,\u0027Visible\u0027)","ctrl":"TABLESTS","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e35101_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Stsprotocolenable_Controlvaluechanged Routine */
         this.clearMessages();
         this.s202_client();
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSSERVERCHECKTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSSERVERCHECKTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENTGETTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENTGETTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENT\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTS\u0027,\u0027Visible\u0027)","ctrl":"TABLESTS","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e16102_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e17102_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e18102_client=function()
   {
      /* 'GenerateKeyGAMRemote' Routine */
      return this.executeServerEvent("'GENERATEKEYGAMREMOTE'", false, null, false, false);
   };
   this.e19102_client=function()
   {
      /* 'Revoke-Authorize' Routine */
      return this.executeServerEvent("'REVOKE-AUTHORIZE'", true, null, false, false);
   };
   this.e20102_client=function()
   {
      /* 'Translations' Routine */
      return this.executeServerEvent("'TRANSLATIONS'", true, null, false, false);
   };
   this.e21102_client=function()
   {
      /* 'CustomProperties' Routine */
      return this.executeServerEvent("'CUSTOMPROPERTIES'", true, null, false, false);
   };
   this.e22102_client=function()
   {
      /* Ssorestenable_Controlvaluechanged Routine */
      return this.executeServerEvent("VSSORESTENABLE.CONTROLVALUECHANGED", true, null, false, true);
   };
   this.e23102_client=function()
   {
      /* Ssorestmode_Controlvaluechanged Routine */
      return this.executeServerEvent("VSSORESTMODE.CONTROLVALUECHANGED", true, null, false, true);
   };
   this.e24102_client=function()
   {
      /* Miniappenable_Controlvaluechanged Routine */
      return this.executeServerEvent("VMINIAPPENABLE.CONTROLVALUECHANGED", true, null, false, true);
   };
   this.e25102_client=function()
   {
      /* Miniappmode_Controlvaluechanged Routine */
      return this.executeServerEvent("VMINIAPPMODE.CONTROLVALUECHANGED", true, null, false, true);
   };
   this.e26102_client=function()
   {
      /* Apikeyenable_Controlvaluechanged Routine */
      return this.executeServerEvent("VAPIKEYENABLE.CONTROLVALUECHANGED", true, null, false, true);
   };
   this.e36102_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e37102_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,137,138,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,330,331,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,376,377,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,427,428,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,478,479,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,537,538,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,565,566,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587,588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,605,606,608,609,610,612,613,614,615,616,618,619,620,621,622,623,624,625,626,627];
   this.GXLastCtrlId =627;
   this.GridapplanguagesContainer = new gx.grid.grid(this, 2,"WbpLvl2",611,"Gridapplanguages","Gridapplanguages","GridapplanguagesContainer",this.CmpContext,this.IsMasterPage,"gam_applicationentry",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridapplanguagesContainer = this.GridapplanguagesContainer;
   GridapplanguagesContainer.addCheckBox("Online",612,"vONLINE",gx.getMessage( "GAM_Online"),"","Online","boolean","true","false",null,true,false,0,"px","");
   GridapplanguagesContainer.addSingleLineEdit("Language",613,"vLANGUAGE",gx.getMessage( "GAM_Name"),"","Language","svchar",35,"%",40,40,"start",null,[],"Language","Language",true,0,false,false,"Attribute",0,"");
   GridapplanguagesContainer.addSingleLineEdit("Languagedesc",614,"vLANGUAGEDESC",gx.getMessage( "GAM_Description"),"","LanguageDesc","char",60,"%",60,60,"start",null,[],"Languagedesc","LanguageDesc",true,0,false,false,"Attribute",0,"");
   this.GridapplanguagesContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridapplanguagesContainer);
   this.TAB1Container = gx.uc.getNew(this, 135, 61, "gx.ui.controls.BasicTab", "TAB1Container", "Tab1", "TAB1");
   var TAB1Container = this.TAB1Container;
   TAB1Container.setProp("Enabled", "Enabled", true, "boolean");
   TAB1Container.setProp("ActivePage", "Activepage", '', "int");
   TAB1Container.setProp("ActivePageControlName", "Activepagecontrolname", "", "char");
   TAB1Container.setProp("PageCount", "Pagecount", 8, "num");
   TAB1Container.setProp("Class", "Class", "Tab", "str");
   TAB1Container.setProp("HistoryManagement", "Historymanagement", false, "bool");
   TAB1Container.setProp("Visible", "Visible", true, "bool");
   TAB1Container.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(TAB1Container);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e29101_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[30]={ id: 30, fld:"BUTTONEDIT", format:0,grid:0,evt:"e11101_client", ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"BUTTONDELETE", format:0,grid:0,evt:"e12101_client", ctrltype: "textblock"};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[38]={ id: 38, fld:"GAM_HEADERENTRY_MENUTOOLBAR_INNER",grid:0};
   GXValidFnc[39]={ id: 39, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[40]={ id: 40, fld:"BUTTONCUSTOMPROPERTIES", format:0,grid:0,evt:"e21102_client", ctrltype: "textblock"};
   GXValidFnc[41]={ id: 41, fld:"BUTTONPERMISSIONS", format:0,grid:0,evt:"e13101_client", ctrltype: "textblock"};
   GXValidFnc[42]={ id: 42, fld:"BUTTONMENU", format:0,grid:0,evt:"e14101_client", ctrltype: "textblock"};
   GXValidFnc[43]={ id: 43, fld:"BUTTONREVOKE", format:0,grid:0,evt:"e19102_client", ctrltype: "textblock"};
   GXValidFnc[44]={ id: 44, fld:"BUTTONTRANSLATIONS", format:0,grid:0,evt:"e20102_client", ctrltype: "textblock"};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"GAM_DATACARD_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id:61 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV37Id",gxold:"OV37Id",gxvar:"AV37Id",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV37Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV37Id=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vID",gx.O.AV37Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37Id=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 61 , function() {
   });
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id:66 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV35GUID",gxold:"OV35GUID",gxvar:"AV35GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV35GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV35GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 66 , function() {
   });
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id:71 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV43Name",gxold:"OV43Name",gxvar:"AV43Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV43Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV43Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV43Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV43Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 71 , function() {
   });
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id:76 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV22Dsc",gxold:"OV22Dsc",gxvar:"AV22Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV22Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV22Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV22Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 76 , function() {
   });
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id:81 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vVERSION",fmt:0,gxz:"ZV54Version",gxold:"OV54Version",gxvar:"AV54Version",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV54Version=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV54Version=Value},v2c:function(){gx.fn.setControlValue("vVERSION",gx.O.AV54Version,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV54Version=this.val()},val:function(){return gx.fn.getControlValue("vVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 81 , function() {
   });
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id:86 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOMPANY",fmt:0,gxz:"ZV20Company",gxold:"OV20Company",gxvar:"AV20Company",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV20Company=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20Company=Value},v2c:function(){gx.fn.setControlValue("vCOMPANY",gx.O.AV20Company,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20Company=this.val()},val:function(){return gx.fn.getControlValue("vCOMPANY")},nac:gx.falseFn};
   this.declareDomainHdlr( 86 , function() {
   });
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id:91 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCOPYRIGHT",fmt:0,gxz:"ZV21Copyright",gxold:"OV21Copyright",gxvar:"AV21Copyright",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21Copyright=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Copyright=Value},v2c:function(){gx.fn.setControlValue("vCOPYRIGHT",gx.O.AV21Copyright,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV21Copyright=this.val()},val:function(){return gx.fn.getControlValue("vCOPYRIGHT")},nac:gx.falseFn};
   this.declareDomainHdlr( 91 , function() {
   });
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id: 94, fld:"",grid:0};
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id:96 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vRETURNMENUOPTIONSWITHOUTPERMISSION",fmt:0,gxz:"ZV104ReturnMenuOptionsWithoutPermission",gxold:"OV104ReturnMenuOptionsWithoutPermission",gxvar:"AV104ReturnMenuOptionsWithoutPermission",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV104ReturnMenuOptionsWithoutPermission=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV104ReturnMenuOptionsWithoutPermission=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vRETURNMENUOPTIONSWITHOUTPERMISSION",gx.O.AV104ReturnMenuOptionsWithoutPermission,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV104ReturnMenuOptionsWithoutPermission=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vRETURNMENUOPTIONSWITHOUTPERMISSION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 96 , function() {
   });
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id: 99, fld:"",grid:0};
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id:101 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMAINMENU",fmt:0,gxz:"ZV40MainMenu",gxold:"OV40MainMenu",gxvar:"AV40MainMenu",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV40MainMenu=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV40MainMenu=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vMAINMENU",gx.O.AV40MainMenu)},c2v:function(){if(this.val()!==undefined)gx.O.AV40MainMenu=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vMAINMENU",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[102]={ id: 102, fld:"",grid:0};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id: 104, fld:"",grid:0};
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id:106 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSEABSOLUTEURLBYENVIRONMENT",fmt:0,gxz:"ZV51UseAbsoluteUrlByEnvironment",gxold:"OV51UseAbsoluteUrlByEnvironment",gxvar:"AV51UseAbsoluteUrlByEnvironment",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV51UseAbsoluteUrlByEnvironment=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV51UseAbsoluteUrlByEnvironment=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vUSEABSOLUTEURLBYENVIRONMENT",gx.O.AV51UseAbsoluteUrlByEnvironment,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV51UseAbsoluteUrlByEnvironment=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vUSEABSOLUTEURLBYENVIRONMENT")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 106 , function() {
   });
   GXValidFnc[107]={ id: 107, fld:"",grid:0};
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id: 109, fld:"",grid:0};
   GXValidFnc[110]={ id: 110, fld:"",grid:0};
   GXValidFnc[111]={ id:111 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vHOMEOBJECT",fmt:0,gxz:"ZV36HomeObject",gxold:"OV36HomeObject",gxvar:"AV36HomeObject",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV36HomeObject=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV36HomeObject=Value},v2c:function(){gx.fn.setControlValue("vHOMEOBJECT",gx.O.AV36HomeObject,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV36HomeObject=this.val()},val:function(){return gx.fn.getControlValue("vHOMEOBJECT")},nac:gx.falseFn};
   this.declareDomainHdlr( 111 , function() {
   });
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id: 114, fld:"",grid:0};
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[116]={ id:116 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCOUNTACTIVATIONOBJECT",fmt:0,gxz:"ZV68AccountActivationObject",gxold:"OV68AccountActivationObject",gxvar:"AV68AccountActivationObject",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV68AccountActivationObject=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV68AccountActivationObject=Value},v2c:function(){gx.fn.setControlValue("vACCOUNTACTIVATIONOBJECT",gx.O.AV68AccountActivationObject,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV68AccountActivationObject=this.val()},val:function(){return gx.fn.getControlValue("vACCOUNTACTIVATIONOBJECT")},nac:gx.falseFn};
   this.declareDomainHdlr( 116 , function() {
   });
   GXValidFnc[117]={ id: 117, fld:"",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id: 119, fld:"",grid:0};
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id:121 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGOUTOBJECT",fmt:0,gxz:"ZV39LogoutObject",gxold:"OV39LogoutObject",gxvar:"AV39LogoutObject",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV39LogoutObject=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV39LogoutObject=Value},v2c:function(){gx.fn.setControlValue("vLOGOUTOBJECT",gx.O.AV39LogoutObject,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV39LogoutObject=this.val()},val:function(){return gx.fn.getControlValue("vLOGOUTOBJECT")},nac:gx.falseFn};
   this.declareDomainHdlr( 121 , function() {
   });
   GXValidFnc[122]={ id: 122, fld:"",grid:0};
   GXValidFnc[123]={ id: 123, fld:"STENCIL1",grid:0};
   GXValidFnc[124]={ id: 124, fld:"",grid:0};
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id: 126, fld:"STENCIL1_TABLEGENERALTITLE",grid:0};
   GXValidFnc[127]={ id: 127, fld:"",grid:0};
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id: 129, fld:"STENCIL1_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[130]={ id: 130, fld:"",grid:0};
   GXValidFnc[131]={ id: 131, fld:"",grid:0};
   GXValidFnc[132]={ id: 132, fld:"STENCIL1_TABLEDATAGENERAL",grid:0};
   GXValidFnc[133]={ id: 133, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"",grid:0};
   GXValidFnc[137]={ id: 137, fld:"TABPAGE3_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[138]={ id: 138, fld:"",grid:0};
   GXValidFnc[140]={ id: 140, fld:"TABPAGE3TABLE1",grid:0};
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[142]={ id: 142, fld:"",grid:0};
   GXValidFnc[143]={ id: 143, fld:"TABLE3",grid:0};
   GXValidFnc[144]={ id: 144, fld:"",grid:0};
   GXValidFnc[145]={ id: 145, fld:"",grid:0};
   GXValidFnc[146]={ id: 146, fld:"",grid:0};
   GXValidFnc[147]={ id: 147, fld:"",grid:0};
   GXValidFnc[148]={ id:148 ,lvl:0,type:"char",len:3,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Clientaccessstatus,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTACCESSSTATUS",fmt:0,gxz:"ZV78ClientAccessStatus",gxold:"OV78ClientAccessStatus",gxvar:"AV78ClientAccessStatus",ucs:[],op:[148],ip:[148],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV78ClientAccessStatus=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV78ClientAccessStatus=Value},v2c:function(){gx.fn.setComboBoxValue("vCLIENTACCESSSTATUS",gx.O.AV78ClientAccessStatus);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV78ClientAccessStatus=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTACCESSSTATUS")},nac:gx.falseFn};
   this.declareDomainHdlr( 148 , function() {
   });
   GXValidFnc[149]={ id: 149, fld:"",grid:0};
   GXValidFnc[150]={ id: 150, fld:"",grid:0};
   GXValidFnc[151]={ id: 151, fld:"",grid:0};
   GXValidFnc[152]={ id:152 ,lvl:0,type:"dtime",len:10,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Clientrevoked,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTREVOKED",fmt:0,gxz:"ZV18ClientRevoked",gxold:"OV18ClientRevoked",gxvar:"AV18ClientRevoked",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/9999 99:99",dec:5},ucs:[],op:[152],ip:[152],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18ClientRevoked=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV18ClientRevoked=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vCLIENTREVOKED",gx.O.AV18ClientRevoked,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18ClientRevoked=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vCLIENTREVOKED")},nac:gx.falseFn};
   this.declareDomainHdlr( 152 , function() {
   });
   GXValidFnc[153]={ id: 153, fld:"",grid:0};
   GXValidFnc[154]={ id: 154, fld:"",grid:0};
   GXValidFnc[155]={ id: 155, fld:"",grid:0};
   GXValidFnc[156]={ id: 156, fld:"",grid:0};
   GXValidFnc[157]={ id:157 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTID",fmt:0,gxz:"ZV14ClientId",gxold:"OV14ClientId",gxvar:"AV14ClientId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14ClientId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14ClientId=Value},v2c:function(){gx.fn.setControlValue("vCLIENTID",gx.O.AV14ClientId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14ClientId=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 157 , function() {
   });
   GXValidFnc[158]={ id: 158, fld:"",grid:0};
   GXValidFnc[159]={ id: 159, fld:"",grid:0};
   GXValidFnc[160]={ id: 160, fld:"",grid:0};
   GXValidFnc[161]={ id: 161, fld:"",grid:0};
   GXValidFnc[162]={ id: 162, fld:"",grid:0};
   GXValidFnc[163]={ id:163 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTSECRET",fmt:0,gxz:"ZV19ClientSecret",gxold:"OV19ClientSecret",gxvar:"AV19ClientSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV19ClientSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19ClientSecret=Value},v2c:function(){gx.fn.setControlValue("vCLIENTSECRET",gx.O.AV19ClientSecret,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19ClientSecret=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTSECRET")},nac:gx.falseFn};
   this.declareDomainHdlr( 163 , function() {
   });
   GXValidFnc[164]={ id: 164, fld:"",grid:0};
   GXValidFnc[165]={ id: 165, fld:"TABLE9",grid:0};
   GXValidFnc[166]={ id: 166, fld:"",grid:0};
   GXValidFnc[167]={ id: 167, fld:"BTNCHANGECLIENTSECRET",grid:0,evt:"e15101_client"};
   GXValidFnc[168]={ id: 168, fld:"",grid:0};
   GXValidFnc[169]={ id: 169, fld:"",grid:0};
   GXValidFnc[170]={ id: 170, fld:"TABLE6",grid:0};
   GXValidFnc[171]={ id: 171, fld:"",grid:0};
   GXValidFnc[172]={ id: 172, fld:"",grid:0};
   GXValidFnc[173]={ id: 173, fld:"",grid:0};
   GXValidFnc[174]={ id: 174, fld:"",grid:0};
   GXValidFnc[175]={ id:175 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTAUTHREQUESTMUSTINCLUDEUSERSCOPES",fmt:0,gxz:"ZV85ClientAuthRequestMustIncludeUserScopes",gxold:"OV85ClientAuthRequestMustIncludeUserScopes",gxvar:"AV85ClientAuthRequestMustIncludeUserScopes",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV85ClientAuthRequestMustIncludeUserScopes=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV85ClientAuthRequestMustIncludeUserScopes=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTAUTHREQUESTMUSTINCLUDEUSERSCOPES",gx.O.AV85ClientAuthRequestMustIncludeUserScopes,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV85ClientAuthRequestMustIncludeUserScopes=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTAUTHREQUESTMUSTINCLUDEUSERSCOPES")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 175 , function() {
   });
   GXValidFnc[176]={ id: 176, fld:"",grid:0};
   GXValidFnc[177]={ id: 177, fld:"",grid:0};
   GXValidFnc[178]={ id: 178, fld:"",grid:0};
   GXValidFnc[179]={ id:179 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTDONOTSHAREUSERIDS",fmt:0,gxz:"ZV86ClientDoNotShareUserIDs",gxold:"OV86ClientDoNotShareUserIDs",gxvar:"AV86ClientDoNotShareUserIDs",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV86ClientDoNotShareUserIDs=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV86ClientDoNotShareUserIDs=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTDONOTSHAREUSERIDS",gx.O.AV86ClientDoNotShareUserIDs,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV86ClientDoNotShareUserIDs=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTDONOTSHAREUSERIDS")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 179 , function() {
   });
   GXValidFnc[180]={ id: 180, fld:"",grid:0};
   GXValidFnc[181]={ id: 181, fld:"",grid:0};
   GXValidFnc[182]={ id: 182, fld:"GRPWEBAUTHENTICATION",grid:0};
   GXValidFnc[183]={ id: 183, fld:"GROUP1TABLE1",grid:0};
   GXValidFnc[184]={ id: 184, fld:"",grid:0};
   GXValidFnc[185]={ id: 185, fld:"",grid:0};
   GXValidFnc[186]={ id: 186, fld:"",grid:0};
   GXValidFnc[187]={ id: 187, fld:"",grid:0};
   GXValidFnc[188]={ id:188 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e30101_client',evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWREMOTEAUTH",fmt:0,gxz:"ZV11ClientAllowRemoteAuth",gxold:"OV11ClientAllowRemoteAuth",gxvar:"AV11ClientAllowRemoteAuth",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV11ClientAllowRemoteAuth=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11ClientAllowRemoteAuth=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWREMOTEAUTH",gx.O.AV11ClientAllowRemoteAuth,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11ClientAllowRemoteAuth=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWREMOTEAUTH")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 188 , function() {
   });
   GXValidFnc[189]={ id: 189, fld:"",grid:0};
   GXValidFnc[190]={ id: 190, fld:"",grid:0};
   GXValidFnc[191]={ id: 191, fld:"TBLWEBAUTH",grid:0};
   GXValidFnc[192]={ id: 192, fld:"",grid:0};
   GXValidFnc[193]={ id: 193, fld:"",grid:0};
   GXValidFnc[194]={ id: 194, fld:"TABLE1",grid:0};
   GXValidFnc[195]={ id: 195, fld:"",grid:0};
   GXValidFnc[196]={ id: 196, fld:"",grid:0};
   GXValidFnc[197]={ id: 197, fld:"TBALLOWEDWEBSCOPES", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[198]={ id: 198, fld:"",grid:0};
   GXValidFnc[199]={ id: 199, fld:"TABLE7",grid:0};
   GXValidFnc[200]={ id: 200, fld:"",grid:0};
   GXValidFnc[201]={ id: 201, fld:"",grid:0};
   GXValidFnc[202]={ id: 202, fld:"",grid:0};
   GXValidFnc[203]={ id:203 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERDATA",fmt:0,gxz:"ZV83ClientAllowGetUserData",gxold:"OV83ClientAllowGetUserData",gxvar:"AV83ClientAllowGetUserData",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV83ClientAllowGetUserData=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV83ClientAllowGetUserData=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERDATA",gx.O.AV83ClientAllowGetUserData,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV83ClientAllowGetUserData=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERDATA")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 203 , function() {
   });
   GXValidFnc[204]={ id: 204, fld:"",grid:0};
   GXValidFnc[205]={ id: 205, fld:"",grid:0};
   GXValidFnc[206]={ id: 206, fld:"",grid:0};
   GXValidFnc[207]={ id:207 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERADDDATA",fmt:0,gxz:"ZV9ClientAllowGetUserAddData",gxold:"OV9ClientAllowGetUserAddData",gxvar:"AV9ClientAllowGetUserAddData",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV9ClientAllowGetUserAddData=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV9ClientAllowGetUserAddData=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERADDDATA",gx.O.AV9ClientAllowGetUserAddData,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV9ClientAllowGetUserAddData=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERADDDATA")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 207 , function() {
   });
   GXValidFnc[208]={ id: 208, fld:"",grid:0};
   GXValidFnc[209]={ id: 209, fld:"",grid:0};
   GXValidFnc[210]={ id: 210, fld:"",grid:0};
   GXValidFnc[211]={ id:211 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERROLES",fmt:0,gxz:"ZV10ClientAllowGetUserRoles",gxold:"OV10ClientAllowGetUserRoles",gxvar:"AV10ClientAllowGetUserRoles",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV10ClientAllowGetUserRoles=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10ClientAllowGetUserRoles=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERROLES",gx.O.AV10ClientAllowGetUserRoles,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10ClientAllowGetUserRoles=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERROLES")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 211 , function() {
   });
   GXValidFnc[212]={ id: 212, fld:"",grid:0};
   GXValidFnc[213]={ id: 213, fld:"",grid:0};
   GXValidFnc[214]={ id: 214, fld:"",grid:0};
   GXValidFnc[215]={ id: 215, fld:"TABLE8",grid:0};
   GXValidFnc[216]={ id: 216, fld:"",grid:0};
   GXValidFnc[217]={ id: 217, fld:"",grid:0};
   GXValidFnc[218]={ id: 218, fld:"",grid:0};
   GXValidFnc[219]={ id:219 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONINIPROP",fmt:0,gxz:"ZV57ClientAllowGetSessionIniProp",gxold:"OV57ClientAllowGetSessionIniProp",gxvar:"AV57ClientAllowGetSessionIniProp",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV57ClientAllowGetSessionIniProp=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV57ClientAllowGetSessionIniProp=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONINIPROP",gx.O.AV57ClientAllowGetSessionIniProp,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV57ClientAllowGetSessionIniProp=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONINIPROP")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 219 , function() {
   });
   GXValidFnc[220]={ id: 220, fld:"",grid:0};
   GXValidFnc[221]={ id: 221, fld:"",grid:0};
   GXValidFnc[222]={ id: 222, fld:"",grid:0};
   GXValidFnc[223]={ id:223 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONAPPDATA",fmt:0,gxz:"ZV81ClientAllowGetSessionAppData",gxold:"OV81ClientAllowGetSessionAppData",gxvar:"AV81ClientAllowGetSessionAppData",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV81ClientAllowGetSessionAppData=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV81ClientAllowGetSessionAppData=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONAPPDATA",gx.O.AV81ClientAllowGetSessionAppData,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV81ClientAllowGetSessionAppData=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONAPPDATA")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 223 , function() {
   });
   GXValidFnc[224]={ id: 224, fld:"",grid:0};
   GXValidFnc[225]={ id: 225, fld:"",grid:0};
   GXValidFnc[226]={ id: 226, fld:"",grid:0};
   GXValidFnc[227]={ id: 227, fld:"",grid:0};
   GXValidFnc[228]={ id:228 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWADDITIONALSCOPE",fmt:0,gxz:"ZV79ClientAllowAdditionalScope",gxold:"OV79ClientAllowAdditionalScope",gxvar:"AV79ClientAllowAdditionalScope",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV79ClientAllowAdditionalScope=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV79ClientAllowAdditionalScope=Value},v2c:function(){gx.fn.setControlValue("vCLIENTALLOWADDITIONALSCOPE",gx.O.AV79ClientAllowAdditionalScope,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV79ClientAllowAdditionalScope=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTALLOWADDITIONALSCOPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 228 , function() {
   });
   GXValidFnc[229]={ id: 229, fld:"",grid:0};
   GXValidFnc[230]={ id: 230, fld:"",grid:0};
   GXValidFnc[231]={ id: 231, fld:"",grid:0};
   GXValidFnc[232]={ id: 232, fld:"",grid:0};
   GXValidFnc[233]={ id:233 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTIMAGEURL",fmt:0,gxz:"ZV15ClientImageURL",gxold:"OV15ClientImageURL",gxvar:"AV15ClientImageURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15ClientImageURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15ClientImageURL=Value},v2c:function(){gx.fn.setControlValue("vCLIENTIMAGEURL",gx.O.AV15ClientImageURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15ClientImageURL=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTIMAGEURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 233 , function() {
   });
   GXValidFnc[234]={ id: 234, fld:"",grid:0};
   GXValidFnc[235]={ id: 235, fld:"",grid:0};
   GXValidFnc[236]={ id: 236, fld:"",grid:0};
   GXValidFnc[237]={ id: 237, fld:"",grid:0};
   GXValidFnc[238]={ id:238 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTLOCALLOGINURL",fmt:0,gxz:"ZV16ClientLocalLoginURL",gxold:"OV16ClientLocalLoginURL",gxvar:"AV16ClientLocalLoginURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16ClientLocalLoginURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16ClientLocalLoginURL=Value},v2c:function(){gx.fn.setControlValue("vCLIENTLOCALLOGINURL",gx.O.AV16ClientLocalLoginURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16ClientLocalLoginURL=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTLOCALLOGINURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 238 , function() {
   });
   GXValidFnc[239]={ id: 239, fld:"",grid:0};
   GXValidFnc[240]={ id: 240, fld:"",grid:0};
   GXValidFnc[241]={ id: 241, fld:"",grid:0};
   GXValidFnc[242]={ id: 242, fld:"",grid:0};
   GXValidFnc[243]={ id:243 ,lvl:0,type:"vchar",len:32768,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTCALLBACKURL",fmt:0,gxz:"ZV12ClientCallbackURL",gxold:"OV12ClientCallbackURL",gxvar:"AV12ClientCallbackURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12ClientCallbackURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12ClientCallbackURL=Value},v2c:function(){gx.fn.setControlValue("vCLIENTCALLBACKURL",gx.O.AV12ClientCallbackURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12ClientCallbackURL=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTCALLBACKURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 243 , function() {
   });
   GXValidFnc[244]={ id: 244, fld:"",grid:0};
   GXValidFnc[245]={ id: 245, fld:"",grid:0};
   GXValidFnc[246]={ id: 246, fld:"",grid:0};
   GXValidFnc[247]={ id: 247, fld:"",grid:0};
   GXValidFnc[248]={ id:248 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTCALLBACKURLISCUSTOM",fmt:0,gxz:"ZV66ClientCallbackURLisCustom",gxold:"OV66ClientCallbackURLisCustom",gxvar:"AV66ClientCallbackURLisCustom",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV66ClientCallbackURLisCustom=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV66ClientCallbackURLisCustom=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTCALLBACKURLISCUSTOM",gx.O.AV66ClientCallbackURLisCustom,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV66ClientCallbackURLisCustom=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTCALLBACKURLISCUSTOM")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 248 , function() {
   });
   GXValidFnc[249]={ id: 249, fld:"",grid:0};
   GXValidFnc[250]={ id: 250, fld:"",grid:0};
   GXValidFnc[251]={ id: 251, fld:"",grid:0};
   GXValidFnc[252]={ id: 252, fld:"",grid:0};
   GXValidFnc[253]={ id:253 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTCALLBACKURLSTATENAME",fmt:0,gxz:"ZV67ClientCallbackURLStateName",gxold:"OV67ClientCallbackURLStateName",gxvar:"AV67ClientCallbackURLStateName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV67ClientCallbackURLStateName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV67ClientCallbackURLStateName=Value},v2c:function(){gx.fn.setControlValue("vCLIENTCALLBACKURLSTATENAME",gx.O.AV67ClientCallbackURLStateName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV67ClientCallbackURLStateName=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTCALLBACKURLSTATENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 253 , function() {
   });
   GXValidFnc[254]={ id: 254, fld:"",grid:0};
   GXValidFnc[255]={ id: 255, fld:"",grid:0};
   GXValidFnc[256]={ id: 256, fld:"GRPRESTAUTHENTICATION",grid:0};
   GXValidFnc[257]={ id: 257, fld:"GROUP2TABLE1",grid:0};
   GXValidFnc[258]={ id: 258, fld:"",grid:0};
   GXValidFnc[259]={ id: 259, fld:"",grid:0};
   GXValidFnc[260]={ id: 260, fld:"",grid:0};
   GXValidFnc[261]={ id: 261, fld:"",grid:0};
   GXValidFnc[262]={ id:262 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e31101_client',evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWREMOTERESTAUTH",fmt:0,gxz:"ZV61ClientAllowRemoteRESTAuth",gxold:"OV61ClientAllowRemoteRESTAuth",gxvar:"AV61ClientAllowRemoteRESTAuth",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV61ClientAllowRemoteRESTAuth=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV61ClientAllowRemoteRESTAuth=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWREMOTERESTAUTH",gx.O.AV61ClientAllowRemoteRESTAuth,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV61ClientAllowRemoteRESTAuth=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWREMOTERESTAUTH")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 262 , function() {
   });
   GXValidFnc[263]={ id: 263, fld:"",grid:0};
   GXValidFnc[264]={ id: 264, fld:"",grid:0};
   GXValidFnc[265]={ id: 265, fld:"TBLRESTAUTH",grid:0};
   GXValidFnc[266]={ id: 266, fld:"",grid:0};
   GXValidFnc[267]={ id: 267, fld:"",grid:0};
   GXValidFnc[268]={ id: 268, fld:"TABLE4",grid:0};
   GXValidFnc[269]={ id: 269, fld:"",grid:0};
   GXValidFnc[270]={ id: 270, fld:"",grid:0};
   GXValidFnc[271]={ id: 271, fld:"TBALLOWEDRESTSCOPES", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[272]={ id: 272, fld:"",grid:0};
   GXValidFnc[273]={ id: 273, fld:"TABLE2",grid:0};
   GXValidFnc[274]={ id: 274, fld:"",grid:0};
   GXValidFnc[275]={ id: 275, fld:"",grid:0};
   GXValidFnc[276]={ id: 276, fld:"",grid:0};
   GXValidFnc[277]={ id:277 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERDATAREST",fmt:0,gxz:"ZV84ClientAllowGetUserDataREST",gxold:"OV84ClientAllowGetUserDataREST",gxvar:"AV84ClientAllowGetUserDataREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV84ClientAllowGetUserDataREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV84ClientAllowGetUserDataREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERDATAREST",gx.O.AV84ClientAllowGetUserDataREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV84ClientAllowGetUserDataREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERDATAREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 277 , function() {
   });
   GXValidFnc[278]={ id: 278, fld:"",grid:0};
   GXValidFnc[279]={ id: 279, fld:"",grid:0};
   GXValidFnc[280]={ id: 280, fld:"",grid:0};
   GXValidFnc[281]={ id:281 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERADDDATAREST",fmt:0,gxz:"ZV59ClientAllowGetUserAddDataREST",gxold:"OV59ClientAllowGetUserAddDataREST",gxvar:"AV59ClientAllowGetUserAddDataREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV59ClientAllowGetUserAddDataREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV59ClientAllowGetUserAddDataREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERADDDATAREST",gx.O.AV59ClientAllowGetUserAddDataREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV59ClientAllowGetUserAddDataREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERADDDATAREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 281 , function() {
   });
   GXValidFnc[282]={ id: 282, fld:"",grid:0};
   GXValidFnc[283]={ id: 283, fld:"",grid:0};
   GXValidFnc[284]={ id: 284, fld:"",grid:0};
   GXValidFnc[285]={ id:285 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERROLESREST",fmt:0,gxz:"ZV60ClientAllowGetUserRolesRest",gxold:"OV60ClientAllowGetUserRolesRest",gxvar:"AV60ClientAllowGetUserRolesRest",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV60ClientAllowGetUserRolesRest=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV60ClientAllowGetUserRolesRest=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERROLESREST",gx.O.AV60ClientAllowGetUserRolesRest,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV60ClientAllowGetUserRolesRest=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERROLESREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 285 , function() {
   });
   GXValidFnc[286]={ id: 286, fld:"",grid:0};
   GXValidFnc[287]={ id: 287, fld:"",grid:0};
   GXValidFnc[288]={ id: 288, fld:"",grid:0};
   GXValidFnc[289]={ id: 289, fld:"TABLE5",grid:0};
   GXValidFnc[290]={ id: 290, fld:"",grid:0};
   GXValidFnc[291]={ id: 291, fld:"",grid:0};
   GXValidFnc[292]={ id: 292, fld:"",grid:0};
   GXValidFnc[293]={ id:293 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONINIPROPREST",fmt:0,gxz:"ZV58ClientAllowGetSessionIniPropREST",gxold:"OV58ClientAllowGetSessionIniPropREST",gxvar:"AV58ClientAllowGetSessionIniPropREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV58ClientAllowGetSessionIniPropREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV58ClientAllowGetSessionIniPropREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONINIPROPREST",gx.O.AV58ClientAllowGetSessionIniPropREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV58ClientAllowGetSessionIniPropREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONINIPROPREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 293 , function() {
   });
   GXValidFnc[294]={ id: 294, fld:"",grid:0};
   GXValidFnc[295]={ id: 295, fld:"",grid:0};
   GXValidFnc[296]={ id: 296, fld:"",grid:0};
   GXValidFnc[297]={ id:297 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONAPPDATAREST",fmt:0,gxz:"ZV82ClientAllowGetSessionAppDataREST",gxold:"OV82ClientAllowGetSessionAppDataREST",gxvar:"AV82ClientAllowGetSessionAppDataREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV82ClientAllowGetSessionAppDataREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV82ClientAllowGetSessionAppDataREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONAPPDATAREST",gx.O.AV82ClientAllowGetSessionAppDataREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV82ClientAllowGetSessionAppDataREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONAPPDATAREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 297 , function() {
   });
   GXValidFnc[298]={ id: 298, fld:"",grid:0};
   GXValidFnc[299]={ id: 299, fld:"",grid:0};
   GXValidFnc[300]={ id: 300, fld:"",grid:0};
   GXValidFnc[301]={ id: 301, fld:"",grid:0};
   GXValidFnc[302]={ id:302 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWADDITIONALSCOPEREST",fmt:0,gxz:"ZV80ClientAllowAdditionalScopeREST",gxold:"OV80ClientAllowAdditionalScopeREST",gxvar:"AV80ClientAllowAdditionalScopeREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV80ClientAllowAdditionalScopeREST=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV80ClientAllowAdditionalScopeREST=Value},v2c:function(){gx.fn.setControlValue("vCLIENTALLOWADDITIONALSCOPEREST",gx.O.AV80ClientAllowAdditionalScopeREST,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV80ClientAllowAdditionalScopeREST=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTALLOWADDITIONALSCOPEREST")},nac:gx.falseFn};
   this.declareDomainHdlr( 302 , function() {
   });
   GXValidFnc[303]={ id: 303, fld:"",grid:0};
   GXValidFnc[304]={ id: 304, fld:"",grid:0};
   GXValidFnc[305]={ id: 305, fld:"TBLGENERALAUTH",grid:0};
   GXValidFnc[306]={ id: 306, fld:"",grid:0};
   GXValidFnc[307]={ id: 307, fld:"",grid:0};
   GXValidFnc[308]={ id: 308, fld:"GROUP3",grid:0};
   GXValidFnc[309]={ id: 309, fld:"GROUP3TABLE1",grid:0};
   GXValidFnc[310]={ id: 310, fld:"",grid:0};
   GXValidFnc[311]={ id: 311, fld:"",grid:0};
   GXValidFnc[312]={ id: 312, fld:"",grid:0};
   GXValidFnc[313]={ id: 313, fld:"",grid:0};
   GXValidFnc[314]={ id:314 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTACCESSUNIQUEBYUSER",fmt:0,gxz:"ZV8ClientAccessUniqueByUser",gxold:"OV8ClientAccessUniqueByUser",gxvar:"AV8ClientAccessUniqueByUser",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV8ClientAccessUniqueByUser=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV8ClientAccessUniqueByUser=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTACCESSUNIQUEBYUSER",gx.O.AV8ClientAccessUniqueByUser,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV8ClientAccessUniqueByUser=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTACCESSUNIQUEBYUSER")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[315]={ id: 315, fld:"",grid:0};
   GXValidFnc[316]={ id: 316, fld:"TBHELPSIGLEUSERACCESS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[317]={ id: 317, fld:"",grid:0};
   GXValidFnc[318]={ id: 318, fld:"",grid:0};
   GXValidFnc[319]={ id: 319, fld:"",grid:0};
   GXValidFnc[320]={ id: 320, fld:"",grid:0};
   GXValidFnc[321]={ id:321 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTENCRYPTIONKEY",fmt:0,gxz:"ZV13ClientEncryptionKey",gxold:"OV13ClientEncryptionKey",gxvar:"AV13ClientEncryptionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13ClientEncryptionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13ClientEncryptionKey=Value},v2c:function(){gx.fn.setControlValue("vCLIENTENCRYPTIONKEY",gx.O.AV13ClientEncryptionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13ClientEncryptionKey=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTENCRYPTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 321 , function() {
   });
   GXValidFnc[322]={ id: 322, fld:"",grid:0};
   GXValidFnc[323]={ id: 323, fld:"GENERATEKEYGAMREMOTE",grid:0,evt:"e18102_client"};
   GXValidFnc[324]={ id: 324, fld:"",grid:0};
   GXValidFnc[325]={ id: 325, fld:"",grid:0};
   GXValidFnc[326]={ id: 326, fld:"",grid:0};
   GXValidFnc[327]={ id: 327, fld:"",grid:0};
   GXValidFnc[328]={ id:328 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTREPOSITORYGUID",fmt:0,gxz:"ZV17ClientRepositoryGUID",gxold:"OV17ClientRepositoryGUID",gxvar:"AV17ClientRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV17ClientRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17ClientRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vCLIENTREPOSITORYGUID",gx.O.AV17ClientRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17ClientRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 328 , function() {
   });
   GXValidFnc[330]={ id: 330, fld:"AUTHORIZATION_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[331]={ id: 331, fld:"",grid:0};
   GXValidFnc[333]={ id: 333, fld:"TABPAGE1TABLE1",grid:0};
   GXValidFnc[334]={ id: 334, fld:"",grid:0};
   GXValidFnc[335]={ id: 335, fld:"",grid:0};
   GXValidFnc[336]={ id: 336, fld:"",grid:0};
   GXValidFnc[337]={ id: 337, fld:"",grid:0};
   GXValidFnc[338]={ id:338 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:'e32101_client',evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESSREQUIRESPERMISSION",fmt:0,gxz:"ZV5AccessRequiresPermission",gxold:"OV5AccessRequiresPermission",gxvar:"AV5AccessRequiresPermission",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV5AccessRequiresPermission=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AccessRequiresPermission=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vACCESSREQUIRESPERMISSION",gx.O.AV5AccessRequiresPermission,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5AccessRequiresPermission=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vACCESSREQUIRESPERMISSION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 338 , function() {
   });
   GXValidFnc[339]={ id: 339, fld:"",grid:0};
   GXValidFnc[340]={ id: 340, fld:"",grid:0};
   GXValidFnc[341]={ id: 341, fld:"TBLDELEGATEAUTHORIZATION",grid:0};
   GXValidFnc[342]={ id: 342, fld:"",grid:0};
   GXValidFnc[343]={ id: 343, fld:"",grid:0};
   GXValidFnc[344]={ id: 344, fld:"",grid:0};
   GXValidFnc[345]={ id: 345, fld:"",grid:0};
   GXValidFnc[346]={ id:346 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:'e33101_client',evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISAUTHORIZATIONDELEGATED",fmt:0,gxz:"ZV94IsAuthorizationDelegated",gxold:"OV94IsAuthorizationDelegated",gxvar:"AV94IsAuthorizationDelegated",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV94IsAuthorizationDelegated=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV94IsAuthorizationDelegated=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vISAUTHORIZATIONDELEGATED",gx.O.AV94IsAuthorizationDelegated,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV94IsAuthorizationDelegated=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vISAUTHORIZATIONDELEGATED")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 346 , function() {
   });
   GXValidFnc[347]={ id: 347, fld:"",grid:0};
   GXValidFnc[348]={ id: 348, fld:"",grid:0};
   GXValidFnc[349]={ id: 349, fld:"TBLDELEGATEAUTHORIZATIONPROP",grid:0};
   GXValidFnc[350]={ id: 350, fld:"",grid:0};
   GXValidFnc[351]={ id: 351, fld:"",grid:0};
   GXValidFnc[352]={ id: 352, fld:"",grid:0};
   GXValidFnc[353]={ id: 353, fld:"",grid:0};
   GXValidFnc[354]={ id:354 ,lvl:0,type:"char",len:3,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Delegateauthorizationversion,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDELEGATEAUTHORIZATIONVERSION",fmt:0,gxz:"ZV91DelegateAuthorizationVersion",gxold:"OV91DelegateAuthorizationVersion",gxvar:"AV91DelegateAuthorizationVersion",ucs:[],op:[354],ip:[354],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV91DelegateAuthorizationVersion=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV91DelegateAuthorizationVersion=Value},v2c:function(){gx.fn.setComboBoxValue("vDELEGATEAUTHORIZATIONVERSION",gx.O.AV91DelegateAuthorizationVersion);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV91DelegateAuthorizationVersion=this.val()},val:function(){return gx.fn.getControlValue("vDELEGATEAUTHORIZATIONVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 354 , function() {
   });
   GXValidFnc[355]={ id: 355, fld:"",grid:0};
   GXValidFnc[356]={ id: 356, fld:"",grid:0};
   GXValidFnc[357]={ id: 357, fld:"",grid:0};
   GXValidFnc[358]={ id: 358, fld:"",grid:0};
   GXValidFnc[359]={ id:359 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDELEGATEAUTHORIZATIONFILENAME",fmt:0,gxz:"ZV88DelegateAuthorizationFileName",gxold:"OV88DelegateAuthorizationFileName",gxvar:"AV88DelegateAuthorizationFileName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV88DelegateAuthorizationFileName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV88DelegateAuthorizationFileName=Value},v2c:function(){gx.fn.setControlValue("vDELEGATEAUTHORIZATIONFILENAME",gx.O.AV88DelegateAuthorizationFileName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV88DelegateAuthorizationFileName=this.val()},val:function(){return gx.fn.getControlValue("vDELEGATEAUTHORIZATIONFILENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 359 , function() {
   });
   GXValidFnc[360]={ id: 360, fld:"",grid:0};
   GXValidFnc[361]={ id: 361, fld:"",grid:0};
   GXValidFnc[362]={ id: 362, fld:"",grid:0};
   GXValidFnc[363]={ id: 363, fld:"",grid:0};
   GXValidFnc[364]={ id:364 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDELEGATEAUTHORIZATIONPACKAGE",fmt:0,gxz:"ZV90DelegateAuthorizationPackage",gxold:"OV90DelegateAuthorizationPackage",gxvar:"AV90DelegateAuthorizationPackage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV90DelegateAuthorizationPackage=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV90DelegateAuthorizationPackage=Value},v2c:function(){gx.fn.setControlValue("vDELEGATEAUTHORIZATIONPACKAGE",gx.O.AV90DelegateAuthorizationPackage,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV90DelegateAuthorizationPackage=this.val()},val:function(){return gx.fn.getControlValue("vDELEGATEAUTHORIZATIONPACKAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 364 , function() {
   });
   GXValidFnc[365]={ id: 365, fld:"",grid:0};
   GXValidFnc[366]={ id: 366, fld:"",grid:0};
   GXValidFnc[367]={ id: 367, fld:"",grid:0};
   GXValidFnc[368]={ id: 368, fld:"",grid:0};
   GXValidFnc[369]={ id:369 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDELEGATEAUTHORIZATIONCLASSNAME",fmt:0,gxz:"ZV87DelegateAuthorizationClassName",gxold:"OV87DelegateAuthorizationClassName",gxvar:"AV87DelegateAuthorizationClassName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV87DelegateAuthorizationClassName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV87DelegateAuthorizationClassName=Value},v2c:function(){gx.fn.setControlValue("vDELEGATEAUTHORIZATIONCLASSNAME",gx.O.AV87DelegateAuthorizationClassName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV87DelegateAuthorizationClassName=this.val()},val:function(){return gx.fn.getControlValue("vDELEGATEAUTHORIZATIONCLASSNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 369 , function() {
   });
   GXValidFnc[370]={ id: 370, fld:"",grid:0};
   GXValidFnc[371]={ id: 371, fld:"",grid:0};
   GXValidFnc[372]={ id: 372, fld:"",grid:0};
   GXValidFnc[373]={ id: 373, fld:"",grid:0};
   GXValidFnc[374]={ id:374 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDELEGATEAUTHORIZATIONMETHOD",fmt:0,gxz:"ZV89DelegateAuthorizationMethod",gxold:"OV89DelegateAuthorizationMethod",gxvar:"AV89DelegateAuthorizationMethod",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV89DelegateAuthorizationMethod=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV89DelegateAuthorizationMethod=Value},v2c:function(){gx.fn.setControlValue("vDELEGATEAUTHORIZATIONMETHOD",gx.O.AV89DelegateAuthorizationMethod,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV89DelegateAuthorizationMethod=this.val()},val:function(){return gx.fn.getControlValue("vDELEGATEAUTHORIZATIONMETHOD")},nac:gx.falseFn};
   this.declareDomainHdlr( 374 , function() {
   });
   GXValidFnc[376]={ id: 376, fld:"SSOREST_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[377]={ id: 377, fld:"",grid:0};
   GXValidFnc[379]={ id: 379, fld:"SSORESTTABLE1",grid:0};
   GXValidFnc[380]={ id: 380, fld:"",grid:0};
   GXValidFnc[381]={ id: 381, fld:"",grid:0};
   GXValidFnc[382]={ id: 382, fld:"",grid:0};
   GXValidFnc[383]={ id: 383, fld:"",grid:0};
   GXValidFnc[384]={ id:384 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e22102_client',evt_cvcing:null,rgrid:[],fld:"vSSORESTENABLE",fmt:0,gxz:"ZV62SSORestEnable",gxold:"OV62SSORestEnable",gxvar:"AV62SSORestEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV62SSORestEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV62SSORestEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSSORESTENABLE",gx.O.AV62SSORestEnable,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV62SSORestEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSSORESTENABLE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 384 , function() {
   });
   GXValidFnc[385]={ id: 385, fld:"",grid:0};
   GXValidFnc[386]={ id: 386, fld:"",grid:0};
   GXValidFnc[387]={ id: 387, fld:"TABLESSOREST",grid:0};
   GXValidFnc[388]={ id: 388, fld:"",grid:0};
   GXValidFnc[389]={ id: 389, fld:"",grid:0};
   GXValidFnc[390]={ id: 390, fld:"",grid:0};
   GXValidFnc[391]={ id: 391, fld:"",grid:0};
   GXValidFnc[392]={ id:392 ,lvl:0,type:"char",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Ssorestmode,isvalid:null,evt_cvc:'e23102_client',evt_cvcing:null,rgrid:[],fld:"vSSORESTMODE",fmt:0,gxz:"ZV63SSORestMode",gxold:"OV63SSORestMode",gxvar:"AV63SSORestMode",ucs:[],op:[392],ip:[392],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV63SSORestMode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV63SSORestMode=Value},v2c:function(){gx.fn.setComboBoxValue("vSSORESTMODE",gx.O.AV63SSORestMode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV63SSORestMode=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTMODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 392 , function() {
   });
   GXValidFnc[393]={ id: 393, fld:"",grid:0};
   GXValidFnc[394]={ id: 394, fld:"",grid:0};
   GXValidFnc[395]={ id: 395, fld:"TBLSSORESTMODECLIENT",grid:0};
   GXValidFnc[396]={ id: 396, fld:"",grid:0};
   GXValidFnc[397]={ id: 397, fld:"",grid:0};
   GXValidFnc[398]={ id: 398, fld:"",grid:0};
   GXValidFnc[399]={ id: 399, fld:"",grid:0};
   GXValidFnc[400]={ id:400 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTUSERAUTHTYPENAME",fmt:0,gxz:"ZV65SSORestUserAuthTypeName",gxold:"OV65SSORestUserAuthTypeName",gxvar:"AV65SSORestUserAuthTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV65SSORestUserAuthTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV65SSORestUserAuthTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vSSORESTUSERAUTHTYPENAME",gx.O.AV65SSORestUserAuthTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV65SSORestUserAuthTypeName=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTUSERAUTHTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 400 , function() {
   });
   GXValidFnc[401]={ id: 401, fld:"",grid:0};
   GXValidFnc[402]={ id: 402, fld:"",grid:0};
   GXValidFnc[403]={ id: 403, fld:"",grid:0};
   GXValidFnc[404]={ id: 404, fld:"",grid:0};
   GXValidFnc[405]={ id:405 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTSERVERURL",fmt:0,gxz:"ZV64SSORestServerURL",gxold:"OV64SSORestServerURL",gxvar:"AV64SSORestServerURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV64SSORestServerURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV64SSORestServerURL=Value},v2c:function(){gx.fn.setControlValue("vSSORESTSERVERURL",gx.O.AV64SSORestServerURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV64SSORestServerURL=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTSERVERURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 405 , function() {
   });
   GXValidFnc[406]={ id: 406, fld:"",grid:0};
   GXValidFnc[407]={ id: 407, fld:"",grid:0};
   GXValidFnc[408]={ id: 408, fld:"",grid:0};
   GXValidFnc[409]={ id: 409, fld:"",grid:0};
   GXValidFnc[410]={ id:410 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTSERVERURL_ISCUSTOM",fmt:0,gxz:"ZV73SSORestServerURL_isCustom",gxold:"OV73SSORestServerURL_isCustom",gxvar:"AV73SSORestServerURL_isCustom",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV73SSORestServerURL_isCustom=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV73SSORestServerURL_isCustom=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSSORESTSERVERURL_ISCUSTOM",gx.O.AV73SSORestServerURL_isCustom,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV73SSORestServerURL_isCustom=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSSORESTSERVERURL_ISCUSTOM")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 410 , function() {
   });
   GXValidFnc[411]={ id: 411, fld:"",grid:0};
   GXValidFnc[412]={ id: 412, fld:"",grid:0};
   GXValidFnc[413]={ id: 413, fld:"",grid:0};
   GXValidFnc[414]={ id: 414, fld:"",grid:0};
   GXValidFnc[415]={ id:415 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTSERVERURL_SLO",fmt:0,gxz:"ZV74SSORestServerURL_SLO",gxold:"OV74SSORestServerURL_SLO",gxvar:"AV74SSORestServerURL_SLO",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV74SSORestServerURL_SLO=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV74SSORestServerURL_SLO=Value},v2c:function(){gx.fn.setControlValue("vSSORESTSERVERURL_SLO",gx.O.AV74SSORestServerURL_SLO,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV74SSORestServerURL_SLO=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTSERVERURL_SLO")},nac:gx.falseFn};
   this.declareDomainHdlr( 415 , function() {
   });
   GXValidFnc[416]={ id: 416, fld:"",grid:0};
   GXValidFnc[417]={ id: 417, fld:"",grid:0};
   GXValidFnc[418]={ id: 418, fld:"",grid:0};
   GXValidFnc[419]={ id: 419, fld:"",grid:0};
   GXValidFnc[420]={ id:420 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTSERVERREPOSITORYGUID",fmt:0,gxz:"ZV72SSORestServerRepositoryGUID",gxold:"OV72SSORestServerRepositoryGUID",gxvar:"AV72SSORestServerRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV72SSORestServerRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV72SSORestServerRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vSSORESTSERVERREPOSITORYGUID",gx.O.AV72SSORestServerRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV72SSORestServerRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTSERVERREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 420 , function() {
   });
   GXValidFnc[421]={ id: 421, fld:"",grid:0};
   GXValidFnc[422]={ id: 422, fld:"",grid:0};
   GXValidFnc[423]={ id: 423, fld:"",grid:0};
   GXValidFnc[424]={ id: 424, fld:"",grid:0};
   GXValidFnc[425]={ id:425 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSSORESTSERVERKEY",fmt:0,gxz:"ZV71SSORestServerKey",gxold:"OV71SSORestServerKey",gxvar:"AV71SSORestServerKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV71SSORestServerKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV71SSORestServerKey=Value},v2c:function(){gx.fn.setControlValue("vSSORESTSERVERKEY",gx.O.AV71SSORestServerKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV71SSORestServerKey=this.val()},val:function(){return gx.fn.getControlValue("vSSORESTSERVERKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 425 , function() {
   });
   GXValidFnc[427]={ id: 427, fld:"STS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[428]={ id: 428, fld:"",grid:0};
   GXValidFnc[430]={ id: 430, fld:"STSTABLE1",grid:0};
   GXValidFnc[431]={ id: 431, fld:"",grid:0};
   GXValidFnc[432]={ id: 432, fld:"",grid:0};
   GXValidFnc[433]={ id: 433, fld:"",grid:0};
   GXValidFnc[434]={ id: 434, fld:"",grid:0};
   GXValidFnc[435]={ id:435 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e35101_client',evt_cvcing:null,rgrid:[],fld:"vSTSPROTOCOLENABLE",fmt:0,gxz:"ZV46STSProtocolEnable",gxold:"OV46STSProtocolEnable",gxvar:"AV46STSProtocolEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV46STSProtocolEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV46STSProtocolEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSTSPROTOCOLENABLE",gx.O.AV46STSProtocolEnable,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV46STSProtocolEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSTSPROTOCOLENABLE")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[436]={ id: 436, fld:"",grid:0};
   GXValidFnc[437]={ id: 437, fld:"",grid:0};
   GXValidFnc[438]={ id: 438, fld:"TABLESTS",grid:0};
   GXValidFnc[439]={ id: 439, fld:"",grid:0};
   GXValidFnc[440]={ id: 440, fld:"",grid:0};
   GXValidFnc[441]={ id: 441, fld:"",grid:0};
   GXValidFnc[442]={ id: 442, fld:"",grid:0};
   GXValidFnc[443]={ id:443 ,lvl:0,type:"char",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Stsmode,isvalid:null,evt_cvc:'e34101_client',evt_cvcing:null,rgrid:[],fld:"vSTSMODE",fmt:0,gxz:"ZV48STSMode",gxold:"OV48STSMode",gxvar:"AV48STSMode",ucs:[],op:[443],ip:[443],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV48STSMode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV48STSMode=Value},v2c:function(){gx.fn.setComboBoxValue("vSTSMODE",gx.O.AV48STSMode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV48STSMode=this.val()},val:function(){return gx.fn.getControlValue("vSTSMODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 443 , function() {
   });
   GXValidFnc[444]={ id: 444, fld:"",grid:0};
   GXValidFnc[445]={ id: 445, fld:"",grid:0};
   GXValidFnc[446]={ id: 446, fld:"TABLESTSSERVERCHECKTOKEN",grid:0};
   GXValidFnc[447]={ id: 447, fld:"",grid:0};
   GXValidFnc[448]={ id: 448, fld:"",grid:0};
   GXValidFnc[449]={ id: 449, fld:"",grid:0};
   GXValidFnc[450]={ id: 450, fld:"",grid:0};
   GXValidFnc[451]={ id:451 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSAUTHORIZATIONUSERNAME",fmt:0,gxz:"ZV45STSAuthorizationUserName",gxold:"OV45STSAuthorizationUserName",gxvar:"AV45STSAuthorizationUserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV45STSAuthorizationUserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV45STSAuthorizationUserName=Value},v2c:function(){gx.fn.setControlValue("vSTSAUTHORIZATIONUSERNAME",gx.O.AV45STSAuthorizationUserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV45STSAuthorizationUserName=this.val()},val:function(){return gx.fn.getControlValue("vSTSAUTHORIZATIONUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 451 , function() {
   });
   GXValidFnc[452]={ id: 452, fld:"",grid:0};
   GXValidFnc[453]={ id: 453, fld:"",grid:0};
   GXValidFnc[454]={ id: 454, fld:"",grid:0};
   GXValidFnc[455]={ id:455 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSAUTHORIZATIONUSERGUID",fmt:0,gxz:"ZV44STSAuthorizationUserGUID",gxold:"OV44STSAuthorizationUserGUID",gxvar:"AV44STSAuthorizationUserGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV44STSAuthorizationUserGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV44STSAuthorizationUserGUID=Value},v2c:function(){gx.fn.setControlValue("vSTSAUTHORIZATIONUSERGUID",gx.O.AV44STSAuthorizationUserGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV44STSAuthorizationUserGUID=this.val()},val:function(){return gx.fn.getControlValue("vSTSAUTHORIZATIONUSERGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 455 , function() {
   });
   GXValidFnc[456]={ id: 456, fld:"",grid:0};
   GXValidFnc[457]={ id: 457, fld:"",grid:0};
   GXValidFnc[458]={ id: 458, fld:"TABLESTSCLIENTGETTOKEN",grid:0};
   GXValidFnc[459]={ id: 459, fld:"",grid:0};
   GXValidFnc[460]={ id: 460, fld:"",grid:0};
   GXValidFnc[461]={ id: 461, fld:"",grid:0};
   GXValidFnc[462]={ id: 462, fld:"",grid:0};
   GXValidFnc[463]={ id:463 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSSERVERCLIENTPASSWORD",fmt:0,gxz:"ZV47STSServerClientPassword",gxold:"OV47STSServerClientPassword",gxvar:"AV47STSServerClientPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV47STSServerClientPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV47STSServerClientPassword=Value},v2c:function(){gx.fn.setControlValue("vSTSSERVERCLIENTPASSWORD",gx.O.AV47STSServerClientPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV47STSServerClientPassword=this.val()},val:function(){return gx.fn.getControlValue("vSTSSERVERCLIENTPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 463 , function() {
   });
   GXValidFnc[464]={ id: 464, fld:"",grid:0};
   GXValidFnc[465]={ id: 465, fld:"",grid:0};
   GXValidFnc[466]={ id: 466, fld:"TABLESTSCLIENT",grid:0};
   GXValidFnc[467]={ id: 467, fld:"",grid:0};
   GXValidFnc[468]={ id: 468, fld:"",grid:0};
   GXValidFnc[469]={ id: 469, fld:"",grid:0};
   GXValidFnc[470]={ id: 470, fld:"",grid:0};
   GXValidFnc[471]={ id:471 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSSERVERURL",fmt:0,gxz:"ZV50STSServerURL",gxold:"OV50STSServerURL",gxvar:"AV50STSServerURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV50STSServerURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV50STSServerURL=Value},v2c:function(){gx.fn.setControlValue("vSTSSERVERURL",gx.O.AV50STSServerURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV50STSServerURL=this.val()},val:function(){return gx.fn.getControlValue("vSTSSERVERURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 471 , function() {
   });
   GXValidFnc[472]={ id: 472, fld:"",grid:0};
   GXValidFnc[473]={ id: 473, fld:"",grid:0};
   GXValidFnc[474]={ id: 474, fld:"",grid:0};
   GXValidFnc[475]={ id: 475, fld:"",grid:0};
   GXValidFnc[476]={ id:476 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTSSERVERREPOSITORYGUID",fmt:0,gxz:"ZV49STSServerRepositoryGUID",gxold:"OV49STSServerRepositoryGUID",gxvar:"AV49STSServerRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV49STSServerRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV49STSServerRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vSTSSERVERREPOSITORYGUID",gx.O.AV49STSServerRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV49STSServerRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vSTSSERVERREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 476 , function() {
   });
   GXValidFnc[478]={ id: 478, fld:"MINIAPP_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[479]={ id: 479, fld:"",grid:0};
   GXValidFnc[481]={ id: 481, fld:"TABPAGE1TABLE",grid:0};
   GXValidFnc[482]={ id: 482, fld:"",grid:0};
   GXValidFnc[483]={ id: 483, fld:"",grid:0};
   GXValidFnc[484]={ id: 484, fld:"",grid:0};
   GXValidFnc[485]={ id: 485, fld:"",grid:0};
   GXValidFnc[486]={ id:486 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e24102_client',evt_cvcing:null,rgrid:[],fld:"vMINIAPPENABLE",fmt:0,gxz:"ZV98MiniAppEnable",gxold:"OV98MiniAppEnable",gxvar:"AV98MiniAppEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV98MiniAppEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV98MiniAppEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vMINIAPPENABLE",gx.O.AV98MiniAppEnable,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV98MiniAppEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vMINIAPPENABLE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 486 , function() {
   });
   GXValidFnc[487]={ id: 487, fld:"",grid:0};
   GXValidFnc[488]={ id: 488, fld:"",grid:0};
   GXValidFnc[489]={ id: 489, fld:"TBLMINIAPP",grid:0};
   GXValidFnc[490]={ id: 490, fld:"",grid:0};
   GXValidFnc[491]={ id: 491, fld:"",grid:0};
   GXValidFnc[492]={ id: 492, fld:"",grid:0};
   GXValidFnc[493]={ id: 493, fld:"",grid:0};
   GXValidFnc[494]={ id:494 ,lvl:0,type:"char",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Miniappmode,isvalid:null,evt_cvc:'e25102_client',evt_cvcing:null,rgrid:[],fld:"vMINIAPPMODE",fmt:0,gxz:"ZV99MiniAppMode",gxold:"OV99MiniAppMode",gxvar:"AV99MiniAppMode",ucs:[],op:[494],ip:[494],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV99MiniAppMode=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV99MiniAppMode=Value},v2c:function(){gx.fn.setComboBoxValue("vMINIAPPMODE",gx.O.AV99MiniAppMode);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV99MiniAppMode=this.val()},val:function(){return gx.fn.getControlValue("vMINIAPPMODE")},nac:gx.falseFn};
   this.declareDomainHdlr( 494 , function() {
   });
   GXValidFnc[495]={ id: 495, fld:"",grid:0};
   GXValidFnc[496]={ id: 496, fld:"",grid:0};
   GXValidFnc[497]={ id: 497, fld:"TBLMINIAPPSERVER",grid:0};
   GXValidFnc[498]={ id: 498, fld:"",grid:0};
   GXValidFnc[499]={ id: 499, fld:"",grid:0};
   GXValidFnc[500]={ id: 500, fld:"",grid:0};
   GXValidFnc[501]={ id: 501, fld:"",grid:0};
   GXValidFnc[502]={ id:502 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIAPPCLIENTURL",fmt:0,gxz:"ZV96MiniAppClientURL",gxold:"OV96MiniAppClientURL",gxvar:"AV96MiniAppClientURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV96MiniAppClientURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV96MiniAppClientURL=Value},v2c:function(){gx.fn.setControlValue("vMINIAPPCLIENTURL",gx.O.AV96MiniAppClientURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV96MiniAppClientURL=this.val()},val:function(){return gx.fn.getControlValue("vMINIAPPCLIENTURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 502 , function() {
   });
   GXValidFnc[503]={ id: 503, fld:"",grid:0};
   GXValidFnc[504]={ id: 504, fld:"",grid:0};
   GXValidFnc[505]={ id: 505, fld:"",grid:0};
   GXValidFnc[506]={ id: 506, fld:"",grid:0};
   GXValidFnc[507]={ id:507 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIAPPCLIENTURL_ISCUSTOM",fmt:0,gxz:"ZV97MiniAppClientURL_isCustom",gxold:"OV97MiniAppClientURL_isCustom",gxvar:"AV97MiniAppClientURL_isCustom",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV97MiniAppClientURL_isCustom=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV97MiniAppClientURL_isCustom=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vMINIAPPCLIENTURL_ISCUSTOM",gx.O.AV97MiniAppClientURL_isCustom,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV97MiniAppClientURL_isCustom=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vMINIAPPCLIENTURL_ISCUSTOM")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 507 , function() {
   });
   GXValidFnc[508]={ id: 508, fld:"",grid:0};
   GXValidFnc[509]={ id: 509, fld:"",grid:0};
   GXValidFnc[510]={ id: 510, fld:"",grid:0};
   GXValidFnc[511]={ id: 511, fld:"",grid:0};
   GXValidFnc[512]={ id:512 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIAPPCLIENTREPOSITORYGUID",fmt:0,gxz:"ZV95MiniAppClientRepositoryGUID",gxold:"OV95MiniAppClientRepositoryGUID",gxvar:"AV95MiniAppClientRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV95MiniAppClientRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV95MiniAppClientRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vMINIAPPCLIENTREPOSITORYGUID",gx.O.AV95MiniAppClientRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV95MiniAppClientRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vMINIAPPCLIENTREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 512 , function() {
   });
   GXValidFnc[513]={ id: 513, fld:"",grid:0};
   GXValidFnc[514]={ id: 514, fld:"",grid:0};
   GXValidFnc[515]={ id: 515, fld:"TBLMINIAPPCLIENT",grid:0};
   GXValidFnc[516]={ id: 516, fld:"",grid:0};
   GXValidFnc[517]={ id: 517, fld:"",grid:0};
   GXValidFnc[518]={ id: 518, fld:"",grid:0};
   GXValidFnc[519]={ id: 519, fld:"",grid:0};
   GXValidFnc[520]={ id:520 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIAPPUSERAUTHENTICATIONTYPENAME",fmt:0,gxz:"ZV103MiniAppUserAuthenticationTypeName",gxold:"OV103MiniAppUserAuthenticationTypeName",gxvar:"AV103MiniAppUserAuthenticationTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV103MiniAppUserAuthenticationTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV103MiniAppUserAuthenticationTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vMINIAPPUSERAUTHENTICATIONTYPENAME",gx.O.AV103MiniAppUserAuthenticationTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV103MiniAppUserAuthenticationTypeName=this.val()},val:function(){return gx.fn.getControlValue("vMINIAPPUSERAUTHENTICATIONTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 520 , function() {
   });
   GXValidFnc[521]={ id: 521, fld:"",grid:0};
   GXValidFnc[522]={ id: 522, fld:"",grid:0};
   GXValidFnc[523]={ id: 523, fld:"",grid:0};
   GXValidFnc[524]={ id: 524, fld:"",grid:0};
   GXValidFnc[525]={ id:525 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIAPPSERVERURL",fmt:0,gxz:"ZV101MiniAppServerURL",gxold:"OV101MiniAppServerURL",gxvar:"AV101MiniAppServerURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV101MiniAppServerURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV101MiniAppServerURL=Value},v2c:function(){gx.fn.setControlValue("vMINIAPPSERVERURL",gx.O.AV101MiniAppServerURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV101MiniAppServerURL=this.val()},val:function(){return gx.fn.getControlValue("vMINIAPPSERVERURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 525 , function() {
   });
   GXValidFnc[526]={ id: 526, fld:"",grid:0};
   GXValidFnc[527]={ id: 527, fld:"",grid:0};
   GXValidFnc[528]={ id: 528, fld:"",grid:0};
   GXValidFnc[529]={ id: 529, fld:"",grid:0};
   GXValidFnc[530]={ id:530 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIAPPSERVERURL_ISCUSTOM",fmt:0,gxz:"ZV102MiniAppServerURL_isCustom",gxold:"OV102MiniAppServerURL_isCustom",gxvar:"AV102MiniAppServerURL_isCustom",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV102MiniAppServerURL_isCustom=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV102MiniAppServerURL_isCustom=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vMINIAPPSERVERURL_ISCUSTOM",gx.O.AV102MiniAppServerURL_isCustom,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV102MiniAppServerURL_isCustom=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vMINIAPPSERVERURL_ISCUSTOM")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 530 , function() {
   });
   GXValidFnc[531]={ id: 531, fld:"",grid:0};
   GXValidFnc[532]={ id: 532, fld:"",grid:0};
   GXValidFnc[533]={ id: 533, fld:"",grid:0};
   GXValidFnc[534]={ id: 534, fld:"",grid:0};
   GXValidFnc[535]={ id:535 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIAPPSERVERREPOSITORYGUID",fmt:0,gxz:"ZV100MiniAppServerRepositoryGUID",gxold:"OV100MiniAppServerRepositoryGUID",gxvar:"AV100MiniAppServerRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV100MiniAppServerRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV100MiniAppServerRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vMINIAPPSERVERREPOSITORYGUID",gx.O.AV100MiniAppServerRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV100MiniAppServerRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vMINIAPPSERVERREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 535 , function() {
   });
   GXValidFnc[537]={ id: 537, fld:"APIKEY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[538]={ id: 538, fld:"",grid:0};
   GXValidFnc[540]={ id: 540, fld:"TABPAGE1TABLE2",grid:0};
   GXValidFnc[541]={ id: 541, fld:"",grid:0};
   GXValidFnc[542]={ id: 542, fld:"",grid:0};
   GXValidFnc[543]={ id: 543, fld:"",grid:0};
   GXValidFnc[544]={ id: 544, fld:"",grid:0};
   GXValidFnc[545]={ id:545 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e26102_client',evt_cvcing:null,rgrid:[],fld:"vAPIKEYENABLE",fmt:0,gxz:"ZV76APIKeyEnable",gxold:"OV76APIKeyEnable",gxvar:"AV76APIKeyEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV76APIKeyEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV76APIKeyEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vAPIKEYENABLE",gx.O.AV76APIKeyEnable,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV76APIKeyEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vAPIKEYENABLE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 545 , function() {
   });
   GXValidFnc[546]={ id: 546, fld:"",grid:0};
   GXValidFnc[547]={ id: 547, fld:"",grid:0};
   GXValidFnc[548]={ id: 548, fld:"TBLAPIKEY",grid:0};
   GXValidFnc[549]={ id: 549, fld:"",grid:0};
   GXValidFnc[550]={ id: 550, fld:"",grid:0};
   GXValidFnc[551]={ id: 551, fld:"",grid:0};
   GXValidFnc[552]={ id: 552, fld:"",grid:0};
   GXValidFnc[553]={ id:553 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAPIKEYTIMEOUT",fmt:0,gxz:"ZV77APIKeyTimeout",gxold:"OV77APIKeyTimeout",gxvar:"AV77APIKeyTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV77APIKeyTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV77APIKeyTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vAPIKEYTIMEOUT",gx.O.AV77APIKeyTimeout,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV77APIKeyTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vAPIKEYTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 553 , function() {
   });
   GXValidFnc[554]={ id: 554, fld:"",grid:0};
   GXValidFnc[555]={ id: 555, fld:"",grid:0};
   GXValidFnc[556]={ id: 556, fld:"",grid:0};
   GXValidFnc[557]={ id: 557, fld:"",grid:0};
   GXValidFnc[558]={ id:558 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME",fmt:0,gxz:"ZV75APIKeyAllowOnlyAuthenticationTypeName",gxold:"OV75APIKeyAllowOnlyAuthenticationTypeName",gxvar:"AV75APIKeyAllowOnlyAuthenticationTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV75APIKeyAllowOnlyAuthenticationTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV75APIKeyAllowOnlyAuthenticationTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME",gx.O.AV75APIKeyAllowOnlyAuthenticationTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV75APIKeyAllowOnlyAuthenticationTypeName=this.val()},val:function(){return gx.fn.getControlValue("vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 558 , function() {
   });
   GXValidFnc[559]={ id: 559, fld:"",grid:0};
   GXValidFnc[560]={ id: 560, fld:"",grid:0};
   GXValidFnc[561]={ id: 561, fld:"",grid:0};
   GXValidFnc[562]={ id: 562, fld:"",grid:0};
   GXValidFnc[563]={ id:563 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAPIKEYALLOWSCOPECUSTOMIZATION",fmt:0,gxz:"ZV115APIKeyAllowScopeCustomization",gxold:"OV115APIKeyAllowScopeCustomization",gxvar:"AV115APIKeyAllowScopeCustomization",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV115APIKeyAllowScopeCustomization=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV115APIKeyAllowScopeCustomization=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vAPIKEYALLOWSCOPECUSTOMIZATION",gx.O.AV115APIKeyAllowScopeCustomization,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV115APIKeyAllowScopeCustomization=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vAPIKEYALLOWSCOPECUSTOMIZATION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 563 , function() {
   });
   GXValidFnc[565]={ id: 565, fld:"ENVIRONMENT_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[566]={ id: 566, fld:"",grid:0};
   GXValidFnc[568]={ id: 568, fld:"ENVIRONMENTTABLE1",grid:0};
   GXValidFnc[569]={ id: 569, fld:"",grid:0};
   GXValidFnc[570]={ id: 570, fld:"",grid:0};
   GXValidFnc[571]={ id: 571, fld:"",grid:0};
   GXValidFnc[572]={ id: 572, fld:"",grid:0};
   GXValidFnc[573]={ id:573 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTNAME",fmt:0,gxz:"ZV26EnvironmentName",gxold:"OV26EnvironmentName",gxvar:"AV26EnvironmentName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26EnvironmentName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV26EnvironmentName=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTNAME",gx.O.AV26EnvironmentName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV26EnvironmentName=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 573 , function() {
   });
   GXValidFnc[574]={ id: 574, fld:"",grid:0};
   GXValidFnc[575]={ id: 575, fld:"",grid:0};
   GXValidFnc[576]={ id: 576, fld:"",grid:0};
   GXValidFnc[577]={ id: 577, fld:"",grid:0};
   GXValidFnc[578]={ id:578 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTSECUREPROTOCOL",fmt:0,gxz:"ZV30EnvironmentSecureProtocol",gxold:"OV30EnvironmentSecureProtocol",gxvar:"AV30EnvironmentSecureProtocol",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV30EnvironmentSecureProtocol=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV30EnvironmentSecureProtocol=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vENVIRONMENTSECUREPROTOCOL",gx.O.AV30EnvironmentSecureProtocol,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV30EnvironmentSecureProtocol=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vENVIRONMENTSECUREPROTOCOL")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[579]={ id: 579, fld:"",grid:0};
   GXValidFnc[580]={ id: 580, fld:"",grid:0};
   GXValidFnc[581]={ id: 581, fld:"",grid:0};
   GXValidFnc[582]={ id: 582, fld:"",grid:0};
   GXValidFnc[583]={ id:583 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTHOST",fmt:0,gxz:"ZV25EnvironmentHost",gxold:"OV25EnvironmentHost",gxvar:"AV25EnvironmentHost",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25EnvironmentHost=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25EnvironmentHost=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTHOST",gx.O.AV25EnvironmentHost,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25EnvironmentHost=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTHOST")},nac:gx.falseFn};
   this.declareDomainHdlr( 583 , function() {
   });
   GXValidFnc[584]={ id: 584, fld:"",grid:0};
   GXValidFnc[585]={ id: 585, fld:"",grid:0};
   GXValidFnc[586]={ id: 586, fld:"",grid:0};
   GXValidFnc[587]={ id: 587, fld:"",grid:0};
   GXValidFnc[588]={ id:588 ,lvl:0,type:"int",len:5,dec:0,sign:false,pic:"ZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTPORT",fmt:0,gxz:"ZV27EnvironmentPort",gxold:"OV27EnvironmentPort",gxvar:"AV27EnvironmentPort",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV27EnvironmentPort=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV27EnvironmentPort=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vENVIRONMENTPORT",gx.O.AV27EnvironmentPort,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV27EnvironmentPort=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vENVIRONMENTPORT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[589]={ id: 589, fld:"",grid:0};
   GXValidFnc[590]={ id: 590, fld:"",grid:0};
   GXValidFnc[591]={ id: 591, fld:"",grid:0};
   GXValidFnc[592]={ id: 592, fld:"",grid:0};
   GXValidFnc[593]={ id:593 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTVIRTUALDIRECTORY",fmt:0,gxz:"ZV31EnvironmentVirtualDirectory",gxold:"OV31EnvironmentVirtualDirectory",gxvar:"AV31EnvironmentVirtualDirectory",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV31EnvironmentVirtualDirectory=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31EnvironmentVirtualDirectory=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTVIRTUALDIRECTORY",gx.O.AV31EnvironmentVirtualDirectory,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV31EnvironmentVirtualDirectory=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTVIRTUALDIRECTORY")},nac:gx.falseFn};
   this.declareDomainHdlr( 593 , function() {
   });
   GXValidFnc[594]={ id: 594, fld:"",grid:0};
   GXValidFnc[595]={ id: 595, fld:"",grid:0};
   GXValidFnc[596]={ id: 596, fld:"",grid:0};
   GXValidFnc[597]={ id: 597, fld:"",grid:0};
   GXValidFnc[598]={ id:598 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTPROGRAMPACKAGE",fmt:0,gxz:"ZV29EnvironmentProgramPackage",gxold:"OV29EnvironmentProgramPackage",gxvar:"AV29EnvironmentProgramPackage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29EnvironmentProgramPackage=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29EnvironmentProgramPackage=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTPROGRAMPACKAGE",gx.O.AV29EnvironmentProgramPackage,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29EnvironmentProgramPackage=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTPROGRAMPACKAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 598 , function() {
   });
   GXValidFnc[599]={ id: 599, fld:"",grid:0};
   GXValidFnc[600]={ id: 600, fld:"",grid:0};
   GXValidFnc[601]={ id: 601, fld:"",grid:0};
   GXValidFnc[602]={ id: 602, fld:"",grid:0};
   GXValidFnc[603]={ id:603 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENVIRONMENTPROGRAMEXTENSION",fmt:0,gxz:"ZV28EnvironmentProgramExtension",gxold:"OV28EnvironmentProgramExtension",gxvar:"AV28EnvironmentProgramExtension",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28EnvironmentProgramExtension=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28EnvironmentProgramExtension=Value},v2c:function(){gx.fn.setControlValue("vENVIRONMENTPROGRAMEXTENSION",gx.O.AV28EnvironmentProgramExtension,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV28EnvironmentProgramExtension=this.val()},val:function(){return gx.fn.getControlValue("vENVIRONMENTPROGRAMEXTENSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 603 , function() {
   });
   GXValidFnc[605]={ id: 605, fld:"LANGUAGES_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[606]={ id: 606, fld:"",grid:0};
   GXValidFnc[608]={ id: 608, fld:"TABPAGE1TABLE3",grid:0};
   GXValidFnc[609]={ id: 609, fld:"",grid:0};
   GXValidFnc[610]={ id: 610, fld:"",grid:0};
   GXValidFnc[612]={ id:612 ,lvl:2,type:"boolean",len:1,dec:0,sign:false,ro:0,isacc:0,grid:611,gxgrid:this.GridapplanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vONLINE",fmt:0,gxz:"ZV110Online",gxold:"OV110Online",gxvar:"AV110Online",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV110Online=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV110Online=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vONLINE",row || gx.fn.currentGridRowImpl(611),gx.O.AV110Online,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV110Online=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vONLINE",row || gx.fn.currentGridRowImpl(611))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[613]={ id:613 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:611,gxgrid:this.GridapplanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLANGUAGE",fmt:0,gxz:"ZV107Language",gxold:"OV107Language",gxvar:"AV107Language",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV107Language=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV107Language=Value},v2c:function(row){gx.fn.setGridControlValue("vLANGUAGE",row || gx.fn.currentGridRowImpl(611),gx.O.AV107Language,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV107Language=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vLANGUAGE",row || gx.fn.currentGridRowImpl(611))},nac:gx.falseFn};
   GXValidFnc[614]={ id:614 ,lvl:2,type:"char",len:60,dec:0,sign:false,ro:0,isacc:0,grid:611,gxgrid:this.GridapplanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLANGUAGEDESC",fmt:0,gxz:"ZV117LanguageDesc",gxold:"OV117LanguageDesc",gxvar:"AV117LanguageDesc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV117LanguageDesc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV117LanguageDesc=Value},v2c:function(row){gx.fn.setGridControlValue("vLANGUAGEDESC",row || gx.fn.currentGridRowImpl(611),gx.O.AV117LanguageDesc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV117LanguageDesc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vLANGUAGEDESC",row || gx.fn.currentGridRowImpl(611))},nac:gx.falseFn};
   GXValidFnc[615]={ id: 615, fld:"",grid:0};
   GXValidFnc[616]={ id: 616, fld:"",grid:0};
   GXValidFnc[618]={ id: 618, fld:"",grid:0};
   GXValidFnc[619]={ id: 619, fld:"",grid:0};
   GXValidFnc[620]={ id: 620, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[621]={ id: 621, fld:"",grid:0};
   GXValidFnc[622]={ id: 622, fld:"",grid:0};
   GXValidFnc[623]={ id: 623, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[624]={ id: 624, fld:"",grid:0};
   GXValidFnc[625]={ id: 625, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e17102_client"};
   GXValidFnc[626]={ id: 626, fld:"",grid:0};
   GXValidFnc[627]={ id: 627, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e16102_client"};
   this.AV37Id = 0 ;
   this.ZV37Id = 0 ;
   this.OV37Id = 0 ;
   this.AV35GUID = "" ;
   this.ZV35GUID = "" ;
   this.OV35GUID = "" ;
   this.AV43Name = "" ;
   this.ZV43Name = "" ;
   this.OV43Name = "" ;
   this.AV22Dsc = "" ;
   this.ZV22Dsc = "" ;
   this.OV22Dsc = "" ;
   this.AV54Version = "" ;
   this.ZV54Version = "" ;
   this.OV54Version = "" ;
   this.AV20Company = "" ;
   this.ZV20Company = "" ;
   this.OV20Company = "" ;
   this.AV21Copyright = "" ;
   this.ZV21Copyright = "" ;
   this.OV21Copyright = "" ;
   this.AV104ReturnMenuOptionsWithoutPermission = false ;
   this.ZV104ReturnMenuOptionsWithoutPermission = false ;
   this.OV104ReturnMenuOptionsWithoutPermission = false ;
   this.AV40MainMenu = 0 ;
   this.ZV40MainMenu = 0 ;
   this.OV40MainMenu = 0 ;
   this.AV51UseAbsoluteUrlByEnvironment = false ;
   this.ZV51UseAbsoluteUrlByEnvironment = false ;
   this.OV51UseAbsoluteUrlByEnvironment = false ;
   this.AV36HomeObject = "" ;
   this.ZV36HomeObject = "" ;
   this.OV36HomeObject = "" ;
   this.AV68AccountActivationObject = "" ;
   this.ZV68AccountActivationObject = "" ;
   this.OV68AccountActivationObject = "" ;
   this.AV39LogoutObject = "" ;
   this.ZV39LogoutObject = "" ;
   this.OV39LogoutObject = "" ;
   this.AV78ClientAccessStatus = "" ;
   this.ZV78ClientAccessStatus = "" ;
   this.OV78ClientAccessStatus = "" ;
   this.AV18ClientRevoked = gx.date.nullDate() ;
   this.ZV18ClientRevoked = gx.date.nullDate() ;
   this.OV18ClientRevoked = gx.date.nullDate() ;
   this.AV14ClientId = "" ;
   this.ZV14ClientId = "" ;
   this.OV14ClientId = "" ;
   this.AV19ClientSecret = "" ;
   this.ZV19ClientSecret = "" ;
   this.OV19ClientSecret = "" ;
   this.AV85ClientAuthRequestMustIncludeUserScopes = false ;
   this.ZV85ClientAuthRequestMustIncludeUserScopes = false ;
   this.OV85ClientAuthRequestMustIncludeUserScopes = false ;
   this.AV86ClientDoNotShareUserIDs = false ;
   this.ZV86ClientDoNotShareUserIDs = false ;
   this.OV86ClientDoNotShareUserIDs = false ;
   this.AV11ClientAllowRemoteAuth = false ;
   this.ZV11ClientAllowRemoteAuth = false ;
   this.OV11ClientAllowRemoteAuth = false ;
   this.AV83ClientAllowGetUserData = false ;
   this.ZV83ClientAllowGetUserData = false ;
   this.OV83ClientAllowGetUserData = false ;
   this.AV9ClientAllowGetUserAddData = false ;
   this.ZV9ClientAllowGetUserAddData = false ;
   this.OV9ClientAllowGetUserAddData = false ;
   this.AV10ClientAllowGetUserRoles = false ;
   this.ZV10ClientAllowGetUserRoles = false ;
   this.OV10ClientAllowGetUserRoles = false ;
   this.AV57ClientAllowGetSessionIniProp = false ;
   this.ZV57ClientAllowGetSessionIniProp = false ;
   this.OV57ClientAllowGetSessionIniProp = false ;
   this.AV81ClientAllowGetSessionAppData = false ;
   this.ZV81ClientAllowGetSessionAppData = false ;
   this.OV81ClientAllowGetSessionAppData = false ;
   this.AV79ClientAllowAdditionalScope = "" ;
   this.ZV79ClientAllowAdditionalScope = "" ;
   this.OV79ClientAllowAdditionalScope = "" ;
   this.AV15ClientImageURL = "" ;
   this.ZV15ClientImageURL = "" ;
   this.OV15ClientImageURL = "" ;
   this.AV16ClientLocalLoginURL = "" ;
   this.ZV16ClientLocalLoginURL = "" ;
   this.OV16ClientLocalLoginURL = "" ;
   this.AV12ClientCallbackURL = "" ;
   this.ZV12ClientCallbackURL = "" ;
   this.OV12ClientCallbackURL = "" ;
   this.AV66ClientCallbackURLisCustom = false ;
   this.ZV66ClientCallbackURLisCustom = false ;
   this.OV66ClientCallbackURLisCustom = false ;
   this.AV67ClientCallbackURLStateName = "" ;
   this.ZV67ClientCallbackURLStateName = "" ;
   this.OV67ClientCallbackURLStateName = "" ;
   this.AV61ClientAllowRemoteRESTAuth = false ;
   this.ZV61ClientAllowRemoteRESTAuth = false ;
   this.OV61ClientAllowRemoteRESTAuth = false ;
   this.AV84ClientAllowGetUserDataREST = false ;
   this.ZV84ClientAllowGetUserDataREST = false ;
   this.OV84ClientAllowGetUserDataREST = false ;
   this.AV59ClientAllowGetUserAddDataREST = false ;
   this.ZV59ClientAllowGetUserAddDataREST = false ;
   this.OV59ClientAllowGetUserAddDataREST = false ;
   this.AV60ClientAllowGetUserRolesRest = false ;
   this.ZV60ClientAllowGetUserRolesRest = false ;
   this.OV60ClientAllowGetUserRolesRest = false ;
   this.AV58ClientAllowGetSessionIniPropREST = false ;
   this.ZV58ClientAllowGetSessionIniPropREST = false ;
   this.OV58ClientAllowGetSessionIniPropREST = false ;
   this.AV82ClientAllowGetSessionAppDataREST = false ;
   this.ZV82ClientAllowGetSessionAppDataREST = false ;
   this.OV82ClientAllowGetSessionAppDataREST = false ;
   this.AV80ClientAllowAdditionalScopeREST = "" ;
   this.ZV80ClientAllowAdditionalScopeREST = "" ;
   this.OV80ClientAllowAdditionalScopeREST = "" ;
   this.AV8ClientAccessUniqueByUser = false ;
   this.ZV8ClientAccessUniqueByUser = false ;
   this.OV8ClientAccessUniqueByUser = false ;
   this.AV13ClientEncryptionKey = "" ;
   this.ZV13ClientEncryptionKey = "" ;
   this.OV13ClientEncryptionKey = "" ;
   this.AV17ClientRepositoryGUID = "" ;
   this.ZV17ClientRepositoryGUID = "" ;
   this.OV17ClientRepositoryGUID = "" ;
   this.AV5AccessRequiresPermission = false ;
   this.ZV5AccessRequiresPermission = false ;
   this.OV5AccessRequiresPermission = false ;
   this.AV94IsAuthorizationDelegated = false ;
   this.ZV94IsAuthorizationDelegated = false ;
   this.OV94IsAuthorizationDelegated = false ;
   this.AV91DelegateAuthorizationVersion = "" ;
   this.ZV91DelegateAuthorizationVersion = "" ;
   this.OV91DelegateAuthorizationVersion = "" ;
   this.AV88DelegateAuthorizationFileName = "" ;
   this.ZV88DelegateAuthorizationFileName = "" ;
   this.OV88DelegateAuthorizationFileName = "" ;
   this.AV90DelegateAuthorizationPackage = "" ;
   this.ZV90DelegateAuthorizationPackage = "" ;
   this.OV90DelegateAuthorizationPackage = "" ;
   this.AV87DelegateAuthorizationClassName = "" ;
   this.ZV87DelegateAuthorizationClassName = "" ;
   this.OV87DelegateAuthorizationClassName = "" ;
   this.AV89DelegateAuthorizationMethod = "" ;
   this.ZV89DelegateAuthorizationMethod = "" ;
   this.OV89DelegateAuthorizationMethod = "" ;
   this.AV62SSORestEnable = false ;
   this.ZV62SSORestEnable = false ;
   this.OV62SSORestEnable = false ;
   this.AV63SSORestMode = "" ;
   this.ZV63SSORestMode = "" ;
   this.OV63SSORestMode = "" ;
   this.AV65SSORestUserAuthTypeName = "" ;
   this.ZV65SSORestUserAuthTypeName = "" ;
   this.OV65SSORestUserAuthTypeName = "" ;
   this.AV64SSORestServerURL = "" ;
   this.ZV64SSORestServerURL = "" ;
   this.OV64SSORestServerURL = "" ;
   this.AV73SSORestServerURL_isCustom = false ;
   this.ZV73SSORestServerURL_isCustom = false ;
   this.OV73SSORestServerURL_isCustom = false ;
   this.AV74SSORestServerURL_SLO = "" ;
   this.ZV74SSORestServerURL_SLO = "" ;
   this.OV74SSORestServerURL_SLO = "" ;
   this.AV72SSORestServerRepositoryGUID = "" ;
   this.ZV72SSORestServerRepositoryGUID = "" ;
   this.OV72SSORestServerRepositoryGUID = "" ;
   this.AV71SSORestServerKey = "" ;
   this.ZV71SSORestServerKey = "" ;
   this.OV71SSORestServerKey = "" ;
   this.AV46STSProtocolEnable = false ;
   this.ZV46STSProtocolEnable = false ;
   this.OV46STSProtocolEnable = false ;
   this.AV48STSMode = "" ;
   this.ZV48STSMode = "" ;
   this.OV48STSMode = "" ;
   this.AV45STSAuthorizationUserName = "" ;
   this.ZV45STSAuthorizationUserName = "" ;
   this.OV45STSAuthorizationUserName = "" ;
   this.AV44STSAuthorizationUserGUID = "" ;
   this.ZV44STSAuthorizationUserGUID = "" ;
   this.OV44STSAuthorizationUserGUID = "" ;
   this.AV47STSServerClientPassword = "" ;
   this.ZV47STSServerClientPassword = "" ;
   this.OV47STSServerClientPassword = "" ;
   this.AV50STSServerURL = "" ;
   this.ZV50STSServerURL = "" ;
   this.OV50STSServerURL = "" ;
   this.AV49STSServerRepositoryGUID = "" ;
   this.ZV49STSServerRepositoryGUID = "" ;
   this.OV49STSServerRepositoryGUID = "" ;
   this.AV98MiniAppEnable = false ;
   this.ZV98MiniAppEnable = false ;
   this.OV98MiniAppEnable = false ;
   this.AV99MiniAppMode = "" ;
   this.ZV99MiniAppMode = "" ;
   this.OV99MiniAppMode = "" ;
   this.AV96MiniAppClientURL = "" ;
   this.ZV96MiniAppClientURL = "" ;
   this.OV96MiniAppClientURL = "" ;
   this.AV97MiniAppClientURL_isCustom = false ;
   this.ZV97MiniAppClientURL_isCustom = false ;
   this.OV97MiniAppClientURL_isCustom = false ;
   this.AV95MiniAppClientRepositoryGUID = "" ;
   this.ZV95MiniAppClientRepositoryGUID = "" ;
   this.OV95MiniAppClientRepositoryGUID = "" ;
   this.AV103MiniAppUserAuthenticationTypeName = "" ;
   this.ZV103MiniAppUserAuthenticationTypeName = "" ;
   this.OV103MiniAppUserAuthenticationTypeName = "" ;
   this.AV101MiniAppServerURL = "" ;
   this.ZV101MiniAppServerURL = "" ;
   this.OV101MiniAppServerURL = "" ;
   this.AV102MiniAppServerURL_isCustom = false ;
   this.ZV102MiniAppServerURL_isCustom = false ;
   this.OV102MiniAppServerURL_isCustom = false ;
   this.AV100MiniAppServerRepositoryGUID = "" ;
   this.ZV100MiniAppServerRepositoryGUID = "" ;
   this.OV100MiniAppServerRepositoryGUID = "" ;
   this.AV76APIKeyEnable = false ;
   this.ZV76APIKeyEnable = false ;
   this.OV76APIKeyEnable = false ;
   this.AV77APIKeyTimeout = 0 ;
   this.ZV77APIKeyTimeout = 0 ;
   this.OV77APIKeyTimeout = 0 ;
   this.AV75APIKeyAllowOnlyAuthenticationTypeName = "" ;
   this.ZV75APIKeyAllowOnlyAuthenticationTypeName = "" ;
   this.OV75APIKeyAllowOnlyAuthenticationTypeName = "" ;
   this.AV115APIKeyAllowScopeCustomization = false ;
   this.ZV115APIKeyAllowScopeCustomization = false ;
   this.OV115APIKeyAllowScopeCustomization = false ;
   this.AV26EnvironmentName = "" ;
   this.ZV26EnvironmentName = "" ;
   this.OV26EnvironmentName = "" ;
   this.AV30EnvironmentSecureProtocol = false ;
   this.ZV30EnvironmentSecureProtocol = false ;
   this.OV30EnvironmentSecureProtocol = false ;
   this.AV25EnvironmentHost = "" ;
   this.ZV25EnvironmentHost = "" ;
   this.OV25EnvironmentHost = "" ;
   this.AV27EnvironmentPort = 0 ;
   this.ZV27EnvironmentPort = 0 ;
   this.OV27EnvironmentPort = 0 ;
   this.AV31EnvironmentVirtualDirectory = "" ;
   this.ZV31EnvironmentVirtualDirectory = "" ;
   this.OV31EnvironmentVirtualDirectory = "" ;
   this.AV29EnvironmentProgramPackage = "" ;
   this.ZV29EnvironmentProgramPackage = "" ;
   this.OV29EnvironmentProgramPackage = "" ;
   this.AV28EnvironmentProgramExtension = "" ;
   this.ZV28EnvironmentProgramExtension = "" ;
   this.OV28EnvironmentProgramExtension = "" ;
   this.ZV110Online = false ;
   this.OV110Online = false ;
   this.ZV107Language = "" ;
   this.OV107Language = "" ;
   this.ZV117LanguageDesc = "" ;
   this.OV117LanguageDesc = "" ;
   this.AV37Id = 0 ;
   this.AV35GUID = "" ;
   this.AV43Name = "" ;
   this.AV22Dsc = "" ;
   this.AV54Version = "" ;
   this.AV20Company = "" ;
   this.AV21Copyright = "" ;
   this.AV104ReturnMenuOptionsWithoutPermission = false ;
   this.AV40MainMenu = 0 ;
   this.AV51UseAbsoluteUrlByEnvironment = false ;
   this.AV36HomeObject = "" ;
   this.AV68AccountActivationObject = "" ;
   this.AV39LogoutObject = "" ;
   this.AV78ClientAccessStatus = "" ;
   this.AV18ClientRevoked = gx.date.nullDate() ;
   this.AV14ClientId = "" ;
   this.AV19ClientSecret = "" ;
   this.AV85ClientAuthRequestMustIncludeUserScopes = false ;
   this.AV86ClientDoNotShareUserIDs = false ;
   this.AV11ClientAllowRemoteAuth = false ;
   this.AV83ClientAllowGetUserData = false ;
   this.AV9ClientAllowGetUserAddData = false ;
   this.AV10ClientAllowGetUserRoles = false ;
   this.AV57ClientAllowGetSessionIniProp = false ;
   this.AV81ClientAllowGetSessionAppData = false ;
   this.AV79ClientAllowAdditionalScope = "" ;
   this.AV15ClientImageURL = "" ;
   this.AV16ClientLocalLoginURL = "" ;
   this.AV12ClientCallbackURL = "" ;
   this.AV66ClientCallbackURLisCustom = false ;
   this.AV67ClientCallbackURLStateName = "" ;
   this.AV61ClientAllowRemoteRESTAuth = false ;
   this.AV84ClientAllowGetUserDataREST = false ;
   this.AV59ClientAllowGetUserAddDataREST = false ;
   this.AV60ClientAllowGetUserRolesRest = false ;
   this.AV58ClientAllowGetSessionIniPropREST = false ;
   this.AV82ClientAllowGetSessionAppDataREST = false ;
   this.AV80ClientAllowAdditionalScopeREST = "" ;
   this.AV8ClientAccessUniqueByUser = false ;
   this.AV13ClientEncryptionKey = "" ;
   this.AV17ClientRepositoryGUID = "" ;
   this.AV5AccessRequiresPermission = false ;
   this.AV94IsAuthorizationDelegated = false ;
   this.AV91DelegateAuthorizationVersion = "" ;
   this.AV88DelegateAuthorizationFileName = "" ;
   this.AV90DelegateAuthorizationPackage = "" ;
   this.AV87DelegateAuthorizationClassName = "" ;
   this.AV89DelegateAuthorizationMethod = "" ;
   this.AV62SSORestEnable = false ;
   this.AV63SSORestMode = "" ;
   this.AV65SSORestUserAuthTypeName = "" ;
   this.AV64SSORestServerURL = "" ;
   this.AV73SSORestServerURL_isCustom = false ;
   this.AV74SSORestServerURL_SLO = "" ;
   this.AV72SSORestServerRepositoryGUID = "" ;
   this.AV71SSORestServerKey = "" ;
   this.AV46STSProtocolEnable = false ;
   this.AV48STSMode = "" ;
   this.AV45STSAuthorizationUserName = "" ;
   this.AV44STSAuthorizationUserGUID = "" ;
   this.AV47STSServerClientPassword = "" ;
   this.AV50STSServerURL = "" ;
   this.AV49STSServerRepositoryGUID = "" ;
   this.AV98MiniAppEnable = false ;
   this.AV99MiniAppMode = "" ;
   this.AV96MiniAppClientURL = "" ;
   this.AV97MiniAppClientURL_isCustom = false ;
   this.AV95MiniAppClientRepositoryGUID = "" ;
   this.AV103MiniAppUserAuthenticationTypeName = "" ;
   this.AV101MiniAppServerURL = "" ;
   this.AV102MiniAppServerURL_isCustom = false ;
   this.AV100MiniAppServerRepositoryGUID = "" ;
   this.AV76APIKeyEnable = false ;
   this.AV77APIKeyTimeout = 0 ;
   this.AV75APIKeyAllowOnlyAuthenticationTypeName = "" ;
   this.AV115APIKeyAllowScopeCustomization = false ;
   this.AV26EnvironmentName = "" ;
   this.AV30EnvironmentSecureProtocol = false ;
   this.AV25EnvironmentHost = "" ;
   this.AV27EnvironmentPort = 0 ;
   this.AV31EnvironmentVirtualDirectory = "" ;
   this.AV29EnvironmentProgramPackage = "" ;
   this.AV28EnvironmentProgramExtension = "" ;
   this.AV110Online = false ;
   this.AV107Language = "" ;
   this.AV117LanguageDesc = "" ;
   this.Gx_mode = "" ;
   this.AV105Window = {} ;
   this.Events = {"e16102_client": ["'CONFIRM'", true] ,"e17102_client": ["'CANCEL'", true] ,"e18102_client": ["'GENERATEKEYGAMREMOTE'", true] ,"e19102_client": ["'REVOKE-AUTHORIZE'", true] ,"e20102_client": ["'TRANSLATIONS'", true] ,"e21102_client": ["'CUSTOMPROPERTIES'", true] ,"e22102_client": ["VSSORESTENABLE.CONTROLVALUECHANGED", true] ,"e23102_client": ["VSSORESTMODE.CONTROLVALUECHANGED", true] ,"e24102_client": ["VMINIAPPENABLE.CONTROLVALUECHANGED", true] ,"e25102_client": ["VMINIAPPMODE.CONTROLVALUECHANGED", true] ,"e26102_client": ["VAPIKEYENABLE.CONTROLVALUECHANGED", true] ,"e36102_client": ["ENTER", true] ,"e37102_client": ["CANCEL", true] ,"e29101_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false] ,"e30101_client": ["VCLIENTALLOWREMOTEAUTH.CONTROLVALUECHANGED", false] ,"e31101_client": ["VCLIENTALLOWREMOTERESTAUTH.CONTROLVALUECHANGED", false] ,"e32101_client": ["VACCESSREQUIRESPERMISSION.ISVALID", false] ,"e33101_client": ["VISAUTHORIZATIONDELEGATED.ISVALID", false] ,"e15101_client": ["'CHANGECLIENTSECRET'", false] ,"e12101_client": ["'DELETE'", false] ,"e13101_client": ["'PERMISSIONS'", false] ,"e14101_client": ["'MENUS'", false] ,"e11101_client": ["'EDIT'", false] ,"e34101_client": ["VSTSMODE.CONTROLVALUECHANGED", false] ,"e35101_client": ["VSTSPROTOCOLENABLE.CONTROLVALUECHANGED", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDAPPLANGUAGES_nFirstRecordOnPage"},{"av":"GRIDAPPLANGUAGES_nEOF"},{"av":"gx.fn.getCtrlProperty(\u0027vONLINE\u0027,\u0027Enabled\u0027)","ctrl":"vONLINE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vLANGUAGEDESC\u0027,\u0027Enabled\u0027)","ctrl":"vLANGUAGEDESC","prop":"Enabled"},{"av":"AV104ReturnMenuOptionsWithoutPermission","fld":"vRETURNMENUOPTIONSWITHOUTPERMISSION"},{"av":"AV51UseAbsoluteUrlByEnvironment","fld":"vUSEABSOLUTEURLBYENVIRONMENT"},{"av":"AV85ClientAuthRequestMustIncludeUserScopes","fld":"vCLIENTAUTHREQUESTMUSTINCLUDEUSERSCOPES"},{"av":"AV86ClientDoNotShareUserIDs","fld":"vCLIENTDONOTSHAREUSERIDS"},{"av":"AV11ClientAllowRemoteAuth","fld":"vCLIENTALLOWREMOTEAUTH"},{"av":"AV83ClientAllowGetUserData","fld":"vCLIENTALLOWGETUSERDATA"},{"av":"AV9ClientAllowGetUserAddData","fld":"vCLIENTALLOWGETUSERADDDATA"},{"av":"AV10ClientAllowGetUserRoles","fld":"vCLIENTALLOWGETUSERROLES"},{"av":"AV57ClientAllowGetSessionIniProp","fld":"vCLIENTALLOWGETSESSIONINIPROP"},{"av":"AV81ClientAllowGetSessionAppData","fld":"vCLIENTALLOWGETSESSIONAPPDATA"},{"av":"AV66ClientCallbackURLisCustom","fld":"vCLIENTCALLBACKURLISCUSTOM"},{"av":"AV61ClientAllowRemoteRESTAuth","fld":"vCLIENTALLOWREMOTERESTAUTH"},{"av":"AV84ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"AV59ClientAllowGetUserAddDataREST","fld":"vCLIENTALLOWGETUSERADDDATAREST"},{"av":"AV60ClientAllowGetUserRolesRest","fld":"vCLIENTALLOWGETUSERROLESREST"},{"av":"AV58ClientAllowGetSessionIniPropREST","fld":"vCLIENTALLOWGETSESSIONINIPROPREST"},{"av":"AV82ClientAllowGetSessionAppDataREST","fld":"vCLIENTALLOWGETSESSIONAPPDATAREST"},{"av":"AV8ClientAccessUniqueByUser","fld":"vCLIENTACCESSUNIQUEBYUSER"},{"av":"AV5AccessRequiresPermission","fld":"vACCESSREQUIRESPERMISSION"},{"av":"AV94IsAuthorizationDelegated","fld":"vISAUTHORIZATIONDELEGATED"},{"av":"AV62SSORestEnable","fld":"vSSORESTENABLE"},{"av":"AV73SSORestServerURL_isCustom","fld":"vSSORESTSERVERURL_ISCUSTOM"},{"av":"AV46STSProtocolEnable","fld":"vSTSPROTOCOLENABLE"},{"av":"AV98MiniAppEnable","fld":"vMINIAPPENABLE"},{"av":"AV97MiniAppClientURL_isCustom","fld":"vMINIAPPCLIENTURL_ISCUSTOM"},{"av":"AV102MiniAppServerURL_isCustom","fld":"vMINIAPPSERVERURL_ISCUSTOM"},{"av":"AV76APIKeyEnable","fld":"vAPIKEYENABLE"},{"av":"AV115APIKeyAllowScopeCustomization","fld":"vAPIKEYALLOWSCOPECUSTOMIZATION"},{"av":"AV30EnvironmentSecureProtocol","fld":"vENVIRONMENTSECUREPROTOCOL"},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"},{"av":"AV43Name","fld":"vNAME"},{"av":"AV22Dsc","fld":"vDSC"},{"av":"AV54Version","fld":"vVERSION"},{"av":"AV21Copyright","fld":"vCOPYRIGHT"},{"av":"AV20Company","fld":"vCOMPANY"},{"av":"AV104ReturnMenuOptionsWithoutPermission","fld":"vRETURNMENUOPTIONSWITHOUTPERMISSION"},{"ctrl":"vMAINMENU"},{"av":"AV40MainMenu","fld":"vMAINMENU","pic":"ZZZZZZZZZZZ9"},{"av":"AV51UseAbsoluteUrlByEnvironment","fld":"vUSEABSOLUTEURLBYENVIRONMENT"},{"av":"AV36HomeObject","fld":"vHOMEOBJECT"},{"av":"AV68AccountActivationObject","fld":"vACCOUNTACTIVATIONOBJECT"},{"av":"AV39LogoutObject","fld":"vLOGOUTOBJECT"},{"av":"AV14ClientId","fld":"vCLIENTID"},{"av":"AV19ClientSecret","fld":"vCLIENTSECRET"},{"av":"AV85ClientAuthRequestMustIncludeUserScopes","fld":"vCLIENTAUTHREQUESTMUSTINCLUDEUSERSCOPES"},{"av":"AV86ClientDoNotShareUserIDs","fld":"vCLIENTDONOTSHAREUSERIDS"},{"av":"AV8ClientAccessUniqueByUser","fld":"vCLIENTACCESSUNIQUEBYUSER"},{"av":"AV11ClientAllowRemoteAuth","fld":"vCLIENTALLOWREMOTEAUTH"},{"av":"AV83ClientAllowGetUserData","fld":"vCLIENTALLOWGETUSERDATA"},{"av":"AV9ClientAllowGetUserAddData","fld":"vCLIENTALLOWGETUSERADDDATA"},{"av":"AV10ClientAllowGetUserRoles","fld":"vCLIENTALLOWGETUSERROLES"},{"av":"AV57ClientAllowGetSessionIniProp","fld":"vCLIENTALLOWGETSESSIONINIPROP"},{"av":"AV81ClientAllowGetSessionAppData","fld":"vCLIENTALLOWGETSESSIONAPPDATA"},{"av":"AV79ClientAllowAdditionalScope","fld":"vCLIENTALLOWADDITIONALSCOPE"},{"av":"AV16ClientLocalLoginURL","fld":"vCLIENTLOCALLOGINURL"},{"av":"AV12ClientCallbackURL","fld":"vCLIENTCALLBACKURL"},{"av":"AV66ClientCallbackURLisCustom","fld":"vCLIENTCALLBACKURLISCUSTOM"},{"av":"AV67ClientCallbackURLStateName","fld":"vCLIENTCALLBACKURLSTATENAME"},{"av":"AV15ClientImageURL","fld":"vCLIENTIMAGEURL"},{"av":"AV61ClientAllowRemoteRESTAuth","fld":"vCLIENTALLOWREMOTERESTAUTH"},{"av":"AV84ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"AV59ClientAllowGetUserAddDataREST","fld":"vCLIENTALLOWGETUSERADDDATAREST"},{"av":"AV60ClientAllowGetUserRolesRest","fld":"vCLIENTALLOWGETUSERROLESREST"},{"av":"AV58ClientAllowGetSessionIniPropREST","fld":"vCLIENTALLOWGETSESSIONINIPROPREST"},{"av":"AV82ClientAllowGetSessionAppDataREST","fld":"vCLIENTALLOWGETSESSIONAPPDATAREST"},{"av":"AV80ClientAllowAdditionalScopeREST","fld":"vCLIENTALLOWADDITIONALSCOPEREST"},{"av":"AV13ClientEncryptionKey","fld":"vCLIENTENCRYPTIONKEY"},{"av":"AV17ClientRepositoryGUID","fld":"vCLIENTREPOSITORYGUID"},{"av":"AV5AccessRequiresPermission","fld":"vACCESSREQUIRESPERMISSION"},{"av":"AV94IsAuthorizationDelegated","fld":"vISAUTHORIZATIONDELEGATED"},{"ctrl":"vDELEGATEAUTHORIZATIONVERSION"},{"av":"AV91DelegateAuthorizationVersion","fld":"vDELEGATEAUTHORIZATIONVERSION"},{"av":"AV88DelegateAuthorizationFileName","fld":"vDELEGATEAUTHORIZATIONFILENAME"},{"av":"AV90DelegateAuthorizationPackage","fld":"vDELEGATEAUTHORIZATIONPACKAGE"},{"av":"AV87DelegateAuthorizationClassName","fld":"vDELEGATEAUTHORIZATIONCLASSNAME"},{"av":"AV89DelegateAuthorizationMethod","fld":"vDELEGATEAUTHORIZATIONMETHOD"},{"av":"AV62SSORestEnable","fld":"vSSORESTENABLE"},{"ctrl":"vSSORESTMODE"},{"av":"AV63SSORestMode","fld":"vSSORESTMODE"},{"ctrl":"vSSORESTUSERAUTHTYPENAME"},{"av":"AV65SSORestUserAuthTypeName","fld":"vSSORESTUSERAUTHTYPENAME"},{"av":"AV64SSORestServerURL","fld":"vSSORESTSERVERURL"},{"av":"AV73SSORestServerURL_isCustom","fld":"vSSORESTSERVERURL_ISCUSTOM"},{"av":"AV74SSORestServerURL_SLO","fld":"vSSORESTSERVERURL_SLO"},{"av":"AV72SSORestServerRepositoryGUID","fld":"vSSORESTSERVERREPOSITORYGUID"},{"av":"AV71SSORestServerKey","fld":"vSSORESTSERVERKEY"},{"av":"AV46STSProtocolEnable","fld":"vSTSPROTOCOLENABLE"},{"av":"AV45STSAuthorizationUserName","fld":"vSTSAUTHORIZATIONUSERNAME"},{"av":"AV44STSAuthorizationUserGUID","fld":"vSTSAUTHORIZATIONUSERGUID"},{"ctrl":"vSTSMODE"},{"av":"AV48STSMode","fld":"vSTSMODE"},{"av":"AV50STSServerURL","fld":"vSTSSERVERURL"},{"av":"AV47STSServerClientPassword","fld":"vSTSSERVERCLIENTPASSWORD"},{"av":"AV49STSServerRepositoryGUID","fld":"vSTSSERVERREPOSITORYGUID"},{"av":"AV98MiniAppEnable","fld":"vMINIAPPENABLE"},{"ctrl":"vMINIAPPMODE"},{"av":"AV99MiniAppMode","fld":"vMINIAPPMODE"},{"av":"AV96MiniAppClientURL","fld":"vMINIAPPCLIENTURL"},{"av":"AV97MiniAppClientURL_isCustom","fld":"vMINIAPPCLIENTURL_ISCUSTOM"},{"av":"AV95MiniAppClientRepositoryGUID","fld":"vMINIAPPCLIENTREPOSITORYGUID"},{"ctrl":"vMINIAPPUSERAUTHENTICATIONTYPENAME"},{"av":"AV103MiniAppUserAuthenticationTypeName","fld":"vMINIAPPUSERAUTHENTICATIONTYPENAME"},{"av":"AV101MiniAppServerURL","fld":"vMINIAPPSERVERURL"},{"av":"AV102MiniAppServerURL_isCustom","fld":"vMINIAPPSERVERURL_ISCUSTOM"},{"av":"AV100MiniAppServerRepositoryGUID","fld":"vMINIAPPSERVERREPOSITORYGUID"},{"av":"AV76APIKeyEnable","fld":"vAPIKEYENABLE"},{"av":"AV77APIKeyTimeout","fld":"vAPIKEYTIMEOUT","pic":"ZZZZZZZZ9"},{"ctrl":"vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME"},{"av":"AV75APIKeyAllowOnlyAuthenticationTypeName","fld":"vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME"},{"av":"AV115APIKeyAllowScopeCustomization","fld":"vAPIKEYALLOWSCOPECUSTOMIZATION"},{"av":"AV26EnvironmentName","fld":"vENVIRONMENTNAME"},{"av":"AV30EnvironmentSecureProtocol","fld":"vENVIRONMENTSECUREPROTOCOL"},{"av":"AV25EnvironmentHost","fld":"vENVIRONMENTHOST"},{"av":"AV27EnvironmentPort","fld":"vENVIRONMENTPORT","pic":"ZZZZ9"},{"av":"AV31EnvironmentVirtualDirectory","fld":"vENVIRONMENTVIRTUALDIRECTORY"},{"av":"AV29EnvironmentProgramPackage","fld":"vENVIRONMENTPROGRAMPACKAGE"},{"av":"AV28EnvironmentProgramExtension","fld":"vENVIRONMENTPROGRAMEXTENSION"},{"av":"AV107Language","fld":"vLANGUAGE","grid":611,"hsh":true},{"av":"GRIDAPPLANGUAGES_nFirstRecordOnPage"},{"av":"nRC_GXsfl_611","ctrl":"GRIDAPPLANGUAGES","grid":611,"prop":"GridRC","grid":611},{"av":"AV110Online","fld":"vONLINE","grid":611},{"av":"AV117LanguageDesc","fld":"vLANGUAGEDESC","grid":611}],[{"av":"AV44STSAuthorizationUserGUID","fld":"vSTSAUTHORIZATIONUSERGUID"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'CANCEL'"] = [[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[],[]];
   this.EvtParms["VCLIENTALLOWREMOTEAUTH.CONTROLVALUECHANGED"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV11ClientAllowRemoteAuth","fld":"vCLIENTALLOWREMOTEAUTH"},{"av":"AV61ClientAllowRemoteRESTAuth","fld":"vCLIENTALLOWREMOTERESTAUTH"}],[{"av":"AV83ClientAllowGetUserData","fld":"vCLIENTALLOWGETUSERDATA"},{"av":"gx.fn.getCtrlProperty(\u0027TBLGENERALAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLGENERALAUTH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLWEBAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLWEBAUTH","prop":"Visible"}]];
   this.EvtParms["VCLIENTALLOWREMOTERESTAUTH.CONTROLVALUECHANGED"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV61ClientAllowRemoteRESTAuth","fld":"vCLIENTALLOWREMOTERESTAUTH"},{"av":"AV11ClientAllowRemoteAuth","fld":"vCLIENTALLOWREMOTEAUTH"}],[{"av":"AV84ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"gx.fn.getCtrlProperty(\u0027TBLGENERALAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLGENERALAUTH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLRESTAUTH\u0027,\u0027Visible\u0027)","ctrl":"TBLRESTAUTH","prop":"Visible"}]];
   this.EvtParms["VACCESSREQUIRESPERMISSION.ISVALID"] = [[{"av":"AV5AccessRequiresPermission","fld":"vACCESSREQUIRESPERMISSION"},{"av":"AV94IsAuthorizationDelegated","fld":"vISAUTHORIZATIONDELEGATED"}],[{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATIONPROP\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATIONPROP","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATION\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATION","prop":"Visible"}]];
   this.EvtParms["VISAUTHORIZATIONDELEGATED.ISVALID"] = [[{"av":"AV5AccessRequiresPermission","fld":"vACCESSREQUIRESPERMISSION"},{"av":"AV94IsAuthorizationDelegated","fld":"vISAUTHORIZATIONDELEGATED"}],[{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATIONPROP\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATIONPROP","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLDELEGATEAUTHORIZATION\u0027,\u0027Visible\u0027)","ctrl":"TBLDELEGATEAUTHORIZATION","prop":"Visible"}]];
   this.EvtParms["'CHANGECLIENTSECRET'"] = [[{"av":"AV14ClientId","fld":"vCLIENTID"},{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["'GENERATEKEYGAMREMOTE'"] = [[],[{"av":"AV13ClientEncryptionKey","fld":"vCLIENTENCRYPTIONKEY"}]];
   this.EvtParms["'REVOKE-AUTHORIZE'"] = [[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV18ClientRevoked","fld":"vCLIENTREVOKED","pic":"99/99/9999 99:99"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERENTRY_TXTSTATUS\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERENTRY_TXTSTATUS","prop":"Caption"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERENTRY_TXTSTATUS\u0027,\u0027Class\u0027)","ctrl":"GAM_HEADERENTRY_TXTSTATUS","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027BUTTONREVOKE\u0027,\u0027Caption\u0027)","ctrl":"BUTTONREVOKE","prop":"Caption"},{"ctrl":"vCLIENTACCESSSTATUS"},{"av":"AV78ClientAccessStatus","fld":"vCLIENTACCESSSTATUS"},{"av":"gx.fn.getCtrlProperty(\u0027vCLIENTREVOKED\u0027,\u0027Visible\u0027)","ctrl":"vCLIENTREVOKED","prop":"Visible"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'DELETE'"] = [[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["'PERMISSIONS'"] = [[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["'MENUS'"] = [[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["'EDIT'"] = [[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["'TRANSLATIONS'"] = [[{"av":"GRIDAPPLANGUAGES_nFirstRecordOnPage"},{"av":"GRIDAPPLANGUAGES_nEOF"},{"av":"gx.fn.getCtrlProperty(\u0027vONLINE\u0027,\u0027Enabled\u0027)","ctrl":"vONLINE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vLANGUAGEDESC\u0027,\u0027Enabled\u0027)","ctrl":"vLANGUAGEDESC","prop":"Enabled"},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV104ReturnMenuOptionsWithoutPermission","fld":"vRETURNMENUOPTIONSWITHOUTPERMISSION"},{"av":"AV51UseAbsoluteUrlByEnvironment","fld":"vUSEABSOLUTEURLBYENVIRONMENT"},{"av":"AV85ClientAuthRequestMustIncludeUserScopes","fld":"vCLIENTAUTHREQUESTMUSTINCLUDEUSERSCOPES"},{"av":"AV86ClientDoNotShareUserIDs","fld":"vCLIENTDONOTSHAREUSERIDS"},{"av":"AV11ClientAllowRemoteAuth","fld":"vCLIENTALLOWREMOTEAUTH"},{"av":"AV83ClientAllowGetUserData","fld":"vCLIENTALLOWGETUSERDATA"},{"av":"AV9ClientAllowGetUserAddData","fld":"vCLIENTALLOWGETUSERADDDATA"},{"av":"AV10ClientAllowGetUserRoles","fld":"vCLIENTALLOWGETUSERROLES"},{"av":"AV57ClientAllowGetSessionIniProp","fld":"vCLIENTALLOWGETSESSIONINIPROP"},{"av":"AV81ClientAllowGetSessionAppData","fld":"vCLIENTALLOWGETSESSIONAPPDATA"},{"av":"AV66ClientCallbackURLisCustom","fld":"vCLIENTCALLBACKURLISCUSTOM"},{"av":"AV61ClientAllowRemoteRESTAuth","fld":"vCLIENTALLOWREMOTERESTAUTH"},{"av":"AV84ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"AV59ClientAllowGetUserAddDataREST","fld":"vCLIENTALLOWGETUSERADDDATAREST"},{"av":"AV60ClientAllowGetUserRolesRest","fld":"vCLIENTALLOWGETUSERROLESREST"},{"av":"AV58ClientAllowGetSessionIniPropREST","fld":"vCLIENTALLOWGETSESSIONINIPROPREST"},{"av":"AV82ClientAllowGetSessionAppDataREST","fld":"vCLIENTALLOWGETSESSIONAPPDATAREST"},{"av":"AV8ClientAccessUniqueByUser","fld":"vCLIENTACCESSUNIQUEBYUSER"},{"av":"AV5AccessRequiresPermission","fld":"vACCESSREQUIRESPERMISSION"},{"av":"AV94IsAuthorizationDelegated","fld":"vISAUTHORIZATIONDELEGATED"},{"av":"AV62SSORestEnable","fld":"vSSORESTENABLE"},{"av":"AV73SSORestServerURL_isCustom","fld":"vSSORESTSERVERURL_ISCUSTOM"},{"av":"AV46STSProtocolEnable","fld":"vSTSPROTOCOLENABLE"},{"av":"AV98MiniAppEnable","fld":"vMINIAPPENABLE"},{"av":"AV97MiniAppClientURL_isCustom","fld":"vMINIAPPCLIENTURL_ISCUSTOM"},{"av":"AV102MiniAppServerURL_isCustom","fld":"vMINIAPPSERVERURL_ISCUSTOM"},{"av":"AV76APIKeyEnable","fld":"vAPIKEYENABLE"},{"av":"AV115APIKeyAllowScopeCustomization","fld":"vAPIKEYALLOWSCOPECUSTOMIZATION"},{"av":"AV30EnvironmentSecureProtocol","fld":"vENVIRONMENTSECUREPROTOCOL"},{"av":"AV43Name","fld":"vNAME"},{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[]];
   this.EvtParms["'CUSTOMPROPERTIES'"] = [[{"av":"GRIDAPPLANGUAGES_nFirstRecordOnPage"},{"av":"GRIDAPPLANGUAGES_nEOF"},{"av":"gx.fn.getCtrlProperty(\u0027vONLINE\u0027,\u0027Enabled\u0027)","ctrl":"vONLINE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vLANGUAGEDESC\u0027,\u0027Enabled\u0027)","ctrl":"vLANGUAGEDESC","prop":"Enabled"},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV104ReturnMenuOptionsWithoutPermission","fld":"vRETURNMENUOPTIONSWITHOUTPERMISSION"},{"av":"AV51UseAbsoluteUrlByEnvironment","fld":"vUSEABSOLUTEURLBYENVIRONMENT"},{"av":"AV85ClientAuthRequestMustIncludeUserScopes","fld":"vCLIENTAUTHREQUESTMUSTINCLUDEUSERSCOPES"},{"av":"AV86ClientDoNotShareUserIDs","fld":"vCLIENTDONOTSHAREUSERIDS"},{"av":"AV11ClientAllowRemoteAuth","fld":"vCLIENTALLOWREMOTEAUTH"},{"av":"AV83ClientAllowGetUserData","fld":"vCLIENTALLOWGETUSERDATA"},{"av":"AV9ClientAllowGetUserAddData","fld":"vCLIENTALLOWGETUSERADDDATA"},{"av":"AV10ClientAllowGetUserRoles","fld":"vCLIENTALLOWGETUSERROLES"},{"av":"AV57ClientAllowGetSessionIniProp","fld":"vCLIENTALLOWGETSESSIONINIPROP"},{"av":"AV81ClientAllowGetSessionAppData","fld":"vCLIENTALLOWGETSESSIONAPPDATA"},{"av":"AV66ClientCallbackURLisCustom","fld":"vCLIENTCALLBACKURLISCUSTOM"},{"av":"AV61ClientAllowRemoteRESTAuth","fld":"vCLIENTALLOWREMOTERESTAUTH"},{"av":"AV84ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"AV59ClientAllowGetUserAddDataREST","fld":"vCLIENTALLOWGETUSERADDDATAREST"},{"av":"AV60ClientAllowGetUserRolesRest","fld":"vCLIENTALLOWGETUSERROLESREST"},{"av":"AV58ClientAllowGetSessionIniPropREST","fld":"vCLIENTALLOWGETSESSIONINIPROPREST"},{"av":"AV82ClientAllowGetSessionAppDataREST","fld":"vCLIENTALLOWGETSESSIONAPPDATAREST"},{"av":"AV8ClientAccessUniqueByUser","fld":"vCLIENTACCESSUNIQUEBYUSER"},{"av":"AV5AccessRequiresPermission","fld":"vACCESSREQUIRESPERMISSION"},{"av":"AV94IsAuthorizationDelegated","fld":"vISAUTHORIZATIONDELEGATED"},{"av":"AV62SSORestEnable","fld":"vSSORESTENABLE"},{"av":"AV73SSORestServerURL_isCustom","fld":"vSSORESTSERVERURL_ISCUSTOM"},{"av":"AV46STSProtocolEnable","fld":"vSTSPROTOCOLENABLE"},{"av":"AV98MiniAppEnable","fld":"vMINIAPPENABLE"},{"av":"AV97MiniAppClientURL_isCustom","fld":"vMINIAPPCLIENTURL_ISCUSTOM"},{"av":"AV102MiniAppServerURL_isCustom","fld":"vMINIAPPSERVERURL_ISCUSTOM"},{"av":"AV76APIKeyEnable","fld":"vAPIKEYENABLE"},{"av":"AV115APIKeyAllowScopeCustomization","fld":"vAPIKEYALLOWSCOPECUSTOMIZATION"},{"av":"AV30EnvironmentSecureProtocol","fld":"vENVIRONMENTSECUREPROTOCOL"},{"av":"AV43Name","fld":"vNAME"},{"av":"AV37Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[]];
   this.EvtParms["GRIDAPPLANGUAGES.LOAD"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[{"av":"AV110Online","fld":"vONLINE"},{"av":"AV107Language","fld":"vLANGUAGE","hsh":true},{"av":"AV117LanguageDesc","fld":"vLANGUAGEDESC"}]];
   this.EvtParms["VSSORESTENABLE.CONTROLVALUECHANGED"] = [[{"av":"AV62SSORestEnable","fld":"vSSORESTENABLE"},{"ctrl":"vSSORESTMODE"},{"av":"AV63SSORestMode","fld":"vSSORESTMODE"},{"ctrl":"vSSORESTUSERAUTHTYPENAME"},{"av":"AV65SSORestUserAuthTypeName","fld":"vSSORESTUSERAUTHTYPENAME"}],[{"av":"gx.fn.getCtrlProperty(\u0027TBLSSORESTMODECLIENT\u0027,\u0027Visible\u0027)","ctrl":"TBLSSORESTMODECLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESSOREST\u0027,\u0027Visible\u0027)","ctrl":"TABLESSOREST","prop":"Visible"},{"ctrl":"vSSORESTUSERAUTHTYPENAME"},{"av":"AV65SSORestUserAuthTypeName","fld":"vSSORESTUSERAUTHTYPENAME"}]];
   this.EvtParms["VSSORESTMODE.CONTROLVALUECHANGED"] = [[{"av":"AV62SSORestEnable","fld":"vSSORESTENABLE"},{"ctrl":"vSSORESTMODE"},{"av":"AV63SSORestMode","fld":"vSSORESTMODE"},{"ctrl":"vSSORESTUSERAUTHTYPENAME"},{"av":"AV65SSORestUserAuthTypeName","fld":"vSSORESTUSERAUTHTYPENAME"}],[{"av":"gx.fn.getCtrlProperty(\u0027TBLSSORESTMODECLIENT\u0027,\u0027Visible\u0027)","ctrl":"TBLSSORESTMODECLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESSOREST\u0027,\u0027Visible\u0027)","ctrl":"TABLESSOREST","prop":"Visible"},{"ctrl":"vSSORESTUSERAUTHTYPENAME"},{"av":"AV65SSORestUserAuthTypeName","fld":"vSSORESTUSERAUTHTYPENAME"}]];
   this.EvtParms["VSTSMODE.CONTROLVALUECHANGED"] = [[{"av":"AV46STSProtocolEnable","fld":"vSTSPROTOCOLENABLE"},{"ctrl":"vSTSMODE"},{"av":"AV48STSMode","fld":"vSTSMODE"}],[{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSSERVERCHECKTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSSERVERCHECKTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENTGETTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENTGETTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENT\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTS\u0027,\u0027Visible\u0027)","ctrl":"TABLESTS","prop":"Visible"}]];
   this.EvtParms["VSTSPROTOCOLENABLE.CONTROLVALUECHANGED"] = [[{"av":"AV46STSProtocolEnable","fld":"vSTSPROTOCOLENABLE"},{"ctrl":"vSTSMODE"},{"av":"AV48STSMode","fld":"vSTSMODE"}],[{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSSERVERCHECKTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSSERVERCHECKTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENTGETTOKEN\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENTGETTOKEN","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTSCLIENT\u0027,\u0027Visible\u0027)","ctrl":"TABLESTSCLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLESTS\u0027,\u0027Visible\u0027)","ctrl":"TABLESTS","prop":"Visible"}]];
   this.EvtParms["VMINIAPPENABLE.CONTROLVALUECHANGED"] = [[{"av":"AV98MiniAppEnable","fld":"vMINIAPPENABLE"},{"ctrl":"vMINIAPPMODE"},{"av":"AV99MiniAppMode","fld":"vMINIAPPMODE"},{"ctrl":"vMINIAPPUSERAUTHENTICATIONTYPENAME"},{"av":"AV103MiniAppUserAuthenticationTypeName","fld":"vMINIAPPUSERAUTHENTICATIONTYPENAME"}],[{"av":"gx.fn.getCtrlProperty(\u0027TBLMINIAPPSERVER\u0027,\u0027Visible\u0027)","ctrl":"TBLMINIAPPSERVER","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLMINIAPPCLIENT\u0027,\u0027Visible\u0027)","ctrl":"TBLMINIAPPCLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLMINIAPP\u0027,\u0027Visible\u0027)","ctrl":"TBLMINIAPP","prop":"Visible"},{"ctrl":"vMINIAPPUSERAUTHENTICATIONTYPENAME"},{"av":"AV103MiniAppUserAuthenticationTypeName","fld":"vMINIAPPUSERAUTHENTICATIONTYPENAME"}]];
   this.EvtParms["VMINIAPPMODE.CONTROLVALUECHANGED"] = [[{"av":"AV98MiniAppEnable","fld":"vMINIAPPENABLE"},{"ctrl":"vMINIAPPMODE"},{"av":"AV99MiniAppMode","fld":"vMINIAPPMODE"},{"ctrl":"vMINIAPPUSERAUTHENTICATIONTYPENAME"},{"av":"AV103MiniAppUserAuthenticationTypeName","fld":"vMINIAPPUSERAUTHENTICATIONTYPENAME"}],[{"av":"gx.fn.getCtrlProperty(\u0027TBLMINIAPPSERVER\u0027,\u0027Visible\u0027)","ctrl":"TBLMINIAPPSERVER","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLMINIAPPCLIENT\u0027,\u0027Visible\u0027)","ctrl":"TBLMINIAPPCLIENT","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TBLMINIAPP\u0027,\u0027Visible\u0027)","ctrl":"TBLMINIAPP","prop":"Visible"},{"ctrl":"vMINIAPPUSERAUTHENTICATIONTYPENAME"},{"av":"AV103MiniAppUserAuthenticationTypeName","fld":"vMINIAPPUSERAUTHENTICATIONTYPENAME"}]];
   this.EvtParms["VAPIKEYENABLE.CONTROLVALUECHANGED"] = [[{"av":"AV76APIKeyEnable","fld":"vAPIKEYENABLE"},{"ctrl":"vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME"},{"av":"AV75APIKeyAllowOnlyAuthenticationTypeName","fld":"vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME"}],[{"av":"gx.fn.getCtrlProperty(\u0027TBLAPIKEY\u0027,\u0027Visible\u0027)","ctrl":"TBLAPIKEY","prop":"Visible"},{"ctrl":"vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME"},{"av":"AV75APIKeyAllowOnlyAuthenticationTypeName","fld":"vAPIKEYALLOWONLYAUTHENTICATIONTYPENAME"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_CLIENTACCESSSTATUS"] = [[],[]];
   this.EvtParms["VALIDV_CLIENTREVOKED"] = [[],[]];
   this.EvtParms["VALIDV_DELEGATEAUTHORIZATIONVERSION"] = [[],[]];
   this.EvtParms["VALIDV_SSORESTMODE"] = [[],[]];
   this.EvtParms["VALIDV_STSMODE"] = [[],[]];
   this.EvtParms["VALIDV_MINIAPPMODE"] = [[],[]];
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   GridapplanguagesContainer.addRefreshingVar({rfrVar:"AV110Online", rfrProp:"Enabled", gxAttId:"Online"});
   GridapplanguagesContainer.addRefreshingVar({rfrVar:"AV117LanguageDesc", rfrProp:"Enabled", gxAttId:"Languagedesc"});
   GridapplanguagesContainer.addRefreshingVar({rfrVar:"Gx_mode"});
   GridapplanguagesContainer.addRefreshingParm({rfrVar:"AV110Online", rfrProp:"Enabled", gxAttId:"Online"});
   GridapplanguagesContainer.addRefreshingParm({rfrVar:"AV117LanguageDesc", rfrProp:"Enabled", gxAttId:"Languagedesc"});
   GridapplanguagesContainer.addRefreshingParm({rfrVar:"Gx_mode"});
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[96]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[106]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[175]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[179]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[188]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[203]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[207]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[211]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[219]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[223]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[248]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[262]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[277]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[281]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[285]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[293]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[297]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[314]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[338]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[346]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[384]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[410]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[435]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[486]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[507]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[530]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[545]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[563]);
   GridapplanguagesContainer.addRefreshingParm(this.GXValidFnc[578]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0617" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_applicationentry);});
