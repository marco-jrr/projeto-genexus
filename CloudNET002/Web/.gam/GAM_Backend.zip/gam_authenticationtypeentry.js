/*
               File: GAM_AuthenticationTypeEntry
        Description: GAM_AuthenticationType
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:31:46.78
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_authenticationtypeentry', false, function () {
   this.ServerClass =  "gam_authenticationtypeentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_authenticationtypeentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV5Name=gx.fn.getControlValue("vNAME") ;
      this.AV6TypeId=gx.fn.getControlValue("vTYPEID") ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
   };
   this.e120f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Delete' Routine */
         this.clearMessages();
         this.call("gam_authenticationtypeentry.aspx", ["DLT", this.AV5Name, this.AV6TypeId], null, ["Mode","Name","TypeId"]);
         this.refreshOutputs([{"av":"AV6TypeId","fld":"vTYPEID"},{"av":"AV5Name","fld":"vNAME"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e110f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Edit' Routine */
         this.clearMessages();
         this.call("gam_authenticationtypeentry.aspx", ["UPD", this.AV5Name, this.AV6TypeId], null, ["Mode","Name","TypeId"]);
         this.refreshOutputs([{"av":"AV6TypeId","fld":"vTYPEID"},{"av":"AV5Name","fld":"vNAME"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e160f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Gam_headerentry_tableback_Click Routine */
         this.clearMessages();
         this.call("gam_wwauthtypes.aspx", [], null, []);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e140f2_client=function()
   {
      /* 'Translations' Routine */
      return this.executeServerEvent("'TRANSLATIONS'", true, null, false, false);
   };
   this.e170f2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e180f2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42];
   this.GXLastCtrlId =42;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e160f1_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[30]={ id: 30, fld:"BUTTONEDIT", format:0,grid:0,evt:"e110f1_client", ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"BUTTONDELETE", format:0,grid:0,evt:"e120f1_client", ctrltype: "textblock"};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[38]={ id: 38, fld:"GAM_HEADERENTRY_MENUTOOLBAR_INNER",grid:0};
   GXValidFnc[39]={ id: 39, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[40]={ id: 40, fld:"BUTTONTRANSLATIONS", format:0,grid:0,evt:"e140f2_client", ctrltype: "textblock"};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   this.AV5Name = "" ;
   this.AV6TypeId = "" ;
   this.Gx_mode = "" ;
   this.Events = {"e140f2_client": ["'TRANSLATIONS'", true] ,"e170f2_client": ["ENTER", true] ,"e180f2_client": ["CANCEL", true] ,"e120f1_client": ["'DELETE'", false] ,"e110f1_client": ["'EDIT'", false] ,"e160f1_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[]];
   this.EvtParms["'DELETE'"] = [[{"av":"AV5Name","fld":"vNAME"},{"av":"AV6TypeId","fld":"vTYPEID"}],[{"av":"AV6TypeId","fld":"vTYPEID"},{"av":"AV5Name","fld":"vNAME"}]];
   this.EvtParms["'EDIT'"] = [[{"av":"AV5Name","fld":"vNAME"},{"av":"AV6TypeId","fld":"vTYPEID"}],[{"av":"AV6TypeId","fld":"vTYPEID"},{"av":"AV5Name","fld":"vNAME"}]];
   this.EvtParms["'TRANSLATIONS'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV5Name","fld":"vNAME"}],[]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV5Name", "vNAME", 0, "char", 254, 0);
   this.setVCMap("AV6TypeId", "vTYPEID", 0, "char", 30, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV6TypeId", "vTYPEID", 0, "char", 30, 0);
   this.setVCMap("AV5Name", "vNAME", 0, "char", 254, 0);
   this.Initialize( );
   this.setComponent({id: "WCENTRYPANEL" ,GXClass: null , Prefix: "W0043" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_authenticationtypeentry);});
