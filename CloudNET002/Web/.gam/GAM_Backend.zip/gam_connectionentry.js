/*
               File: GAM_ConnectionEntry
        Description: GAM_Connection
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:32:14.53
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_connectionentry', false, function () {
   this.ServerClass =  "gam_connectionentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_connectionentry.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV13pConnectionName=gx.fn.getControlValue("vPCONNECTIONNAME") ;
   };
   this.s122_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e110m1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Edit' Routine */
         this.clearMessages();
         this.call("gam_connectionentry.aspx", ["UPD", this.AV13pConnectionName], null, ["Mode","pConnectionName"]);
         this.refreshOutputs([{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e130m1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'WWKeys' Routine */
         this.clearMessages();
         this.call("gam_connectionkeys.aspx", [this.AV13pConnectionName], null, ["pConnectionName"]);
         this.refreshOutputs([{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e120m1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Delete' Routine */
         this.clearMessages();
         this.call("gam_connectionentry.aspx", ["DLT", this.AV13pConnectionName], null, ["Mode","pConnectionName"]);
         this.refreshOutputs([{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e190m1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Gam_headerentry_tableback_Click Routine */
         this.clearMessages();
         this.call("gam_wwconnections.aspx", [], null, []);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e150m2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e160m2_client=function()
   {
      /* 'GenerateKey' Routine */
      return this.executeServerEvent("'GENERATEKEY'", false, null, false, false);
   };
   this.e170m2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e200m2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e210m2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,76,77,78,79,80,81,82,83,84,85];
   this.GXLastCtrlId =85;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e190m1_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[30]={ id: 30, fld:"BUTTONEDIT", format:0,grid:0,evt:"e110m1_client", ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"BUTTONDELETE", format:0,grid:0,evt:"e120m1_client", ctrltype: "textblock"};
   GXValidFnc[32]={ id: 32, fld:"BUTTONKEYS", format:0,grid:0,evt:"e130m1_client", ctrltype: "textblock"};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"GAM_DATACARD_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id:52 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONNECTIONNAME",fmt:0,gxz:"ZV8ConnectionName",gxold:"OV8ConnectionName",gxvar:"AV8ConnectionName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8ConnectionName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8ConnectionName=Value},v2c:function(){gx.fn.setControlValue("vCONNECTIONNAME",gx.O.AV8ConnectionName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8ConnectionName=this.val()},val:function(){return gx.fn.getControlValue("vCONNECTIONNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 52 , function() {
   });
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id:57 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",fmt:0,gxz:"ZV14UserName",gxold:"OV14UserName",gxvar:"AV14UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV14UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 57 , function() {
   });
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"CELLPWD",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id:62 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",fmt:0,gxz:"ZV15UserPassword",gxold:"OV15UserPassword",gxvar:"AV15UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV15UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 62 , function() {
   });
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"TBLENCRYPTIONKEY",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id:70 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENCRYPTIONKEY",fmt:0,gxz:"ZV18EncryptionKey",gxold:"OV18EncryptionKey",gxvar:"AV18EncryptionKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18EncryptionKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18EncryptionKey=Value},v2c:function(){gx.fn.setControlValue("vENCRYPTIONKEY",gx.O.AV18EncryptionKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18EncryptionKey=this.val()},val:function(){return gx.fn.getControlValue("vENCRYPTIONKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 70 , function() {
   });
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"BTNGENKEY",grid:0,evt:"e160m2_client"};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e170m2_client"};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e150m2_client"};
   this.AV8ConnectionName = "" ;
   this.ZV8ConnectionName = "" ;
   this.OV8ConnectionName = "" ;
   this.AV14UserName = "" ;
   this.ZV14UserName = "" ;
   this.OV14UserName = "" ;
   this.AV15UserPassword = "" ;
   this.ZV15UserPassword = "" ;
   this.OV15UserPassword = "" ;
   this.AV18EncryptionKey = "" ;
   this.ZV18EncryptionKey = "" ;
   this.OV18EncryptionKey = "" ;
   this.AV8ConnectionName = "" ;
   this.AV14UserName = "" ;
   this.AV15UserPassword = "" ;
   this.AV18EncryptionKey = "" ;
   this.AV13pConnectionName = "" ;
   this.Gx_mode = "" ;
   this.Events = {"e150m2_client": ["'CONFIRM'", true] ,"e160m2_client": ["'GENERATEKEY'", true] ,"e170m2_client": ["'CANCEL'", true] ,"e200m2_client": ["ENTER", true] ,"e210m2_client": ["CANCEL", true] ,"e110m1_client": ["'EDIT'", false] ,"e130m1_client": ["'WWKEYS'", false] ,"e120m1_client": ["'DELETE'", false] ,"e190m1_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"},{"av":"AV8ConnectionName","fld":"vCONNECTIONNAME"},{"av":"AV14UserName","fld":"vUSERNAME"},{"av":"AV15UserPassword","fld":"vUSERPASSWORD"},{"av":"AV18EncryptionKey","fld":"vENCRYPTIONKEY"}],[{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'GENERATEKEY'"] = [[],[{"av":"AV18EncryptionKey","fld":"vENCRYPTIONKEY"}]];
   this.EvtParms["'EDIT'"] = [[{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}],[{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}]];
   this.EvtParms["'WWKEYS'"] = [[{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}],[{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}]];
   this.EvtParms["'DELETE'"] = [[{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}],[{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"}]];
   this.EvtParms["'CANCEL'"] = [[{"av":"AV13pConnectionName","fld":"vPCONNECTIONNAME"},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV13pConnectionName", "vPCONNECTIONNAME", 0, "char", 254, 0);
   this.setVCMap("AV13pConnectionName", "vPCONNECTIONNAME", 0, "char", 254, 0);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0075" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_connectionentry);});
