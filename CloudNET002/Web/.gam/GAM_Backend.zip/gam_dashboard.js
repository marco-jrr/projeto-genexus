/*
               File: GAM_Dashboard
        Description: GAM_Dashboard
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:34:24.90
       Program type: Main program
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_dashboard', false, function () {
   this.ServerClass =  "gam_dashboard" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_dashboard.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
   };
   this.e132u2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e142u2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8];
   this.GXLastCtrlId =8;
   this.DASHBOARDVIEWERContainer = gx.uc.getNew(this, 9, 0, "DashboardViewer", "DASHBOARDVIEWERContainer", "Dashboardviewer", "DASHBOARDVIEWER");
   var DASHBOARDVIEWERContainer = this.DASHBOARDVIEWERContainer;
   DASHBOARDVIEWERContainer.setProp("Enabled", "Enabled", true, "boolean");
   DASHBOARDVIEWERContainer.setProp("Width", "Width", "100%", "str");
   DASHBOARDVIEWERContainer.setProp("Height", "Height", "100%", "str");
   DASHBOARDVIEWERContainer.setDynProp("Object", "Objectcall", "", "str");
   DASHBOARDVIEWERContainer.setProp("Class", "Class", "DashboardViewer", "str");
   DASHBOARDVIEWERContainer.setProp("DashboardSpec", "Dashboardspec", "", "char");
   DASHBOARDVIEWERContainer.setProp("WidgetsExpanded", "Widgetsexpanded", true, "bool");
   DASHBOARDVIEWERContainer.setProp("CSSRules", "Cssrules", "", "char");
   DASHBOARDVIEWERContainer.setProp("DefaultStyle", "Defaultstyle", "", "char");
   DASHBOARDVIEWERContainer.setProp("TranslationType", "Translationtype", "RunTime", "str");
   DASHBOARDVIEWERContainer.setProp("ApplicationNamespace", "Applicationnamespace", "GeneXus.Security.Backend", "str");
   DASHBOARDVIEWERContainer.addV2CFunction('AV7ItemClickData', "vITEMCLICKDATA", 'SetItemClickData');
   DASHBOARDVIEWERContainer.addC2VFunction(function(UC) { UC.ParentObject.AV7ItemClickData=UC.GetItemClickData();gx.fn.setControlValue("vITEMCLICKDATA",UC.ParentObject.AV7ItemClickData); });
   DASHBOARDVIEWERContainer.addV2CFunction('AV5FiltersChangedData', "vFILTERSCHANGEDDATA", 'SetFiltersChangedData');
   DASHBOARDVIEWERContainer.addC2VFunction(function(UC) { UC.ParentObject.AV5FiltersChangedData=UC.GetFiltersChangedData();gx.fn.setControlValue("vFILTERSCHANGEDDATA",UC.ParentObject.AV5FiltersChangedData); });
   DASHBOARDVIEWERContainer.addV2CFunction('AV9ValuesHighlightedData', "vVALUESHIGHLIGHTEDDATA", 'SetValuesHighlightedData');
   DASHBOARDVIEWERContainer.addC2VFunction(function(UC) { UC.ParentObject.AV9ValuesHighlightedData=UC.GetValuesHighlightedData();gx.fn.setControlValue("vVALUESHIGHLIGHTEDDATA",UC.ParentObject.AV9ValuesHighlightedData); });
   DASHBOARDVIEWERContainer.setProp("Visible", "Visible", true, "bool");
   DASHBOARDVIEWERContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(DASHBOARDVIEWERContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TBLTITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   this.AV7ItemClickData = {Object:"",Element:"",Value:"",Context:[],AllFilters:[]} ;
   this.Events = {"e132u2_client": ["ENTER", true] ,"e142u2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_dashboard);});
