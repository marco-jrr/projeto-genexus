/*
               File: GAM_MyAccount
        Description: GAM_Myaccount
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:35:51.78
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_myaccount', false, function () {
   this.ServerClass =  "gam_myaccount" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_myaccount.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV30URLProfile=gx.fn.getControlValue("vURLPROFILE") ;
   };
   this.Validv_Datelastauthentication=function()
   {
      return this.validCliEvt("Validv_Datelastauthentication", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vDATELASTAUTHENTICATION");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV12DateLastAuthentication)===0) || new gx.date.gxdate( this.AV12DateLastAuthentication ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Date Last Authentication"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Birthday=function()
   {
      return this.validCliEvt("Validv_Birthday", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vBIRTHDAY");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV10Birthday)===0) || new gx.date.gxdate( this.AV10Birthday ).compare( gx.date.ymdtod( 1753, 1, 1) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Birthday"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Gender=function()
   {
      return this.validCliEvt("Validv_Gender", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vGENDER");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV21Gender , "N" ) == 0 || gx.text.compare( this.AV21Gender , "F" ) == 0 || gx.text.compare( this.AV21Gender , "M" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Gender"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Theme=function()
   {
      return this.validCliEvt("Validv_Theme", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vTHEME");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV32Theme , "light" ) == 0 || gx.text.compare( this.AV32Theme , "dark" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Theme"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e11391_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Edit' Routine */
         this.clearMessages();
         this.call("gam_myaccount.aspx", ["UPD"], null, ["Mode"]);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e12391_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ChangeName' Routine */
         this.clearMessages();
         this.AV31Window.Url =  gx.http.formatLink("gam_userchangeidentification.aspx",["Name"])  ;
         this.AV31Window.ReturnParms =  [""]  ;
         this.popupOpen(this.AV31Window) ;
         this.call("gam_myaccount.aspx", ["DSP"], null, ["Mode"]);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e13391_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ChangeEmail' Routine */
         this.clearMessages();
         this.AV31Window.Url =  gx.http.formatLink("gam_userchangeidentification.aspx",["Email"])  ;
         this.AV31Window.ReturnParms =  [""]  ;
         this.popupOpen(this.AV31Window) ;
         this.call("gam_myaccount.aspx", ["DSP"], null, ["Mode"]);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e15392_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e16392_client=function()
   {
      /* 'AuthenticatorApp' Routine */
      return this.executeServerEvent("'AUTHENTICATORAPP'", true, null, false, false);
   };
   this.e18392_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e19391_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,144,145,146,147,148,149,150,151,152,153];
   this.GXLastCtrlId =153;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TBLHEADER",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TXTUSER", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[14]={ id: 14, fld:"TOOLBAR_INNER",grid:0};
   GXValidFnc[15]={ id: 15, fld:"BTNEDIT", format:0,grid:0,evt:"e11391_client", ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"BTNTOTPAUTHENTICATOR", format:0,grid:0,evt:"e16392_client", ctrltype: "textblock"};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"GAM_DATACARD",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_DATACARD_TABLEGENERALTITLE",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"GAM_DATACARD_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"GAM_DATACARD_TABLEDATAGENERAL",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id:32 ,lvl:0,type:"bits",len:1024,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vIMAGE",fmt:0,gxz:"ZV22Image",gxold:"OV22Image",gxvar:"AV22Image",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV22Image=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Image=Value},v2c:function(){gx.fn.setMultimediaValue("vIMAGE",gx.O.AV22Image,gx.O.AV40Image_GXI)},c2v:function(){gx.O.AV40Image_GXI=this.val_GXI();if(this.val()!==undefined)gx.O.AV22Image=this.val()},val:function(){return gx.fn.getBlobValue("vIMAGE")},val_GXI:function(){return gx.fn.getControlValue("vIMAGE_GXI")}, gxvar_GXI:'AV40Image_GXI',nac:gx.falseFn};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id:37 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAUTHENTICATIONTYPENAME",fmt:0,gxz:"ZV7AuthenticationTypeName",gxold:"OV7AuthenticationTypeName",gxvar:"AV7AuthenticationTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV7AuthenticationTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7AuthenticationTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vAUTHENTICATIONTYPENAME",gx.O.AV7AuthenticationTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV7AuthenticationTypeName=this.val()},val:function(){return gx.fn.getControlValue("vAUTHENTICATIONTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 37 , function() {
   });
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id:42 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV25Name",gxold:"OV25Name",gxvar:"AV25Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV25Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 42 , function() {
   });
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"BTNCHANGENAME",grid:0,evt:"e12391_client"};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id:49 ,lvl:0,type:"svchar",len:100,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAIL",fmt:0,gxz:"ZV14EMail",gxold:"OV14EMail",gxvar:"AV14EMail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14EMail=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14EMail=Value},v2c:function(){gx.fn.setControlValue("vEMAIL",gx.O.AV14EMail,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14EMail=this.val()},val:function(){return gx.fn.getControlValue("vEMAIL")},nac:gx.falseFn};
   this.declareDomainHdlr( 49 , function() {
   });
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"BTNCHANGEEMAIL",grid:0,evt:"e13391_client"};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id:56 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFIRSTNAME",fmt:0,gxz:"ZV18FirstName",gxold:"OV18FirstName",gxvar:"AV18FirstName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18FirstName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18FirstName=Value},v2c:function(){gx.fn.setControlValue("vFIRSTNAME",gx.O.AV18FirstName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18FirstName=this.val()},val:function(){return gx.fn.getControlValue("vFIRSTNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 56 , function() {
   });
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id:61 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLASTNAME",fmt:0,gxz:"ZV24LastName",gxold:"OV24LastName",gxvar:"AV24LastName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV24LastName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV24LastName=Value},v2c:function(){gx.fn.setControlValue("vLASTNAME",gx.O.AV24LastName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV24LastName=this.val()},val:function(){return gx.fn.getControlValue("vLASTNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 61 , function() {
   });
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id:66 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDONTRECEIVEINFORMATION",fmt:0,gxz:"ZV13DontReceiveInformation",gxold:"OV13DontReceiveInformation",gxvar:"AV13DontReceiveInformation",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV13DontReceiveInformation=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV13DontReceiveInformation=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vDONTRECEIVEINFORMATION",gx.O.AV13DontReceiveInformation,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13DontReceiveInformation=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vDONTRECEIVEINFORMATION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 66 , function() {
   });
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id:71 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENABLETWOFACTORAUTHENTICATION",fmt:0,gxz:"ZV15EnableTwoFactorAuthentication",gxold:"OV15EnableTwoFactorAuthentication",gxvar:"AV15EnableTwoFactorAuthentication",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV15EnableTwoFactorAuthentication=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV15EnableTwoFactorAuthentication=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vENABLETWOFACTORAUTHENTICATION",gx.O.AV15EnableTwoFactorAuthentication,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15EnableTwoFactorAuthentication=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vENABLETWOFACTORAUTHENTICATION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 71 , function() {
   });
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"LASTAUTHCELL",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id:76 ,lvl:0,type:"dtime",len:8,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Datelastauthentication,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDATELASTAUTHENTICATION",fmt:0,gxz:"ZV12DateLastAuthentication",gxold:"OV12DateLastAuthentication",gxvar:"AV12DateLastAuthentication",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/99 99:99",dec:5},ucs:[],op:[76],ip:[76],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12DateLastAuthentication=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV12DateLastAuthentication=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vDATELASTAUTHENTICATION",gx.O.AV12DateLastAuthentication,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV12DateLastAuthentication=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vDATELASTAUTHENTICATION")},nac:gx.falseFn};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"RIGHTTABLE",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"STENCIL1",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"STENCIL1_TABLEGENERALTITLE",grid:0};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[87]={ id: 87, fld:"STENCIL1_TBTITLEGENERAL", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"STENCIL1_TABLEDATAGENERAL",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id: 94, fld:"",grid:0};
   GXValidFnc[95]={ id:95 ,lvl:0,type:"date",len:10,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Birthday,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBIRTHDAY",fmt:0,gxz:"ZV10Birthday",gxold:"OV10Birthday",gxvar:"AV10Birthday",dp:{f:0,st:false,wn:false,mf:false,pic:"99/99/9999",dec:0},ucs:[],op:[95],ip:[95],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10Birthday=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Birthday=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vBIRTHDAY",gx.O.AV10Birthday,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10Birthday=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getControlValue("vBIRTHDAY")},nac:gx.falseFn};
   this.declareDomainHdlr( 95 , function() {
   });
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id: 99, fld:"",grid:0};
   GXValidFnc[100]={ id:100 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Gender,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGENDER",fmt:0,gxz:"ZV21Gender",gxold:"OV21Gender",gxvar:"AV21Gender",ucs:[],op:[100],ip:[100],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV21Gender=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Gender=Value},v2c:function(){gx.fn.setComboBoxValue("vGENDER",gx.O.AV21Gender);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV21Gender=this.val()},val:function(){return gx.fn.getControlValue("vGENDER")},nac:gx.falseFn};
   this.declareDomainHdlr( 100 , function() {
   });
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id: 102, fld:"",grid:0};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id: 104, fld:"",grid:0};
   GXValidFnc[105]={ id:105 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPHONE",fmt:0,gxz:"ZV26Phone",gxold:"OV26Phone",gxvar:"AV26Phone",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26Phone=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV26Phone=Value},v2c:function(){gx.fn.setControlValue("vPHONE",gx.O.AV26Phone,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV26Phone=this.val()},val:function(){return gx.fn.getControlValue("vPHONE")},nac:gx.falseFn};
   this.declareDomainHdlr( 105 , function() {
   });
   GXValidFnc[106]={ id: 106, fld:"",grid:0};
   GXValidFnc[107]={ id: 107, fld:"",grid:0};
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id: 109, fld:"",grid:0};
   GXValidFnc[110]={ id:110 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDRESS",fmt:0,gxz:"ZV5Address",gxold:"OV5Address",gxvar:"AV5Address",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV5Address=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5Address=Value},v2c:function(){gx.fn.setControlValue("vADDRESS",gx.O.AV5Address,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5Address=this.val()},val:function(){return gx.fn.getControlValue("vADDRESS")},nac:gx.falseFn};
   this.declareDomainHdlr( 110 , function() {
   });
   GXValidFnc[111]={ id: 111, fld:"",grid:0};
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id: 114, fld:"",grid:0};
   GXValidFnc[115]={ id:115 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDRESS2",fmt:0,gxz:"ZV6Address2",gxold:"OV6Address2",gxvar:"AV6Address2",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV6Address2=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6Address2=Value},v2c:function(){gx.fn.setControlValue("vADDRESS2",gx.O.AV6Address2,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV6Address2=this.val()},val:function(){return gx.fn.getControlValue("vADDRESS2")},nac:gx.falseFn};
   this.declareDomainHdlr( 115 , function() {
   });
   GXValidFnc[116]={ id: 116, fld:"",grid:0};
   GXValidFnc[117]={ id: 117, fld:"",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id: 119, fld:"",grid:0};
   GXValidFnc[120]={ id:120 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCITY",fmt:0,gxz:"ZV11City",gxold:"OV11City",gxvar:"AV11City",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11City=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11City=Value},v2c:function(){gx.fn.setControlValue("vCITY",gx.O.AV11City,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11City=this.val()},val:function(){return gx.fn.getControlValue("vCITY")},nac:gx.falseFn};
   this.declareDomainHdlr( 120 , function() {
   });
   GXValidFnc[121]={ id: 121, fld:"",grid:0};
   GXValidFnc[122]={ id: 122, fld:"",grid:0};
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id: 124, fld:"",grid:0};
   GXValidFnc[125]={ id:125 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTATE",fmt:0,gxz:"ZV28State",gxold:"OV28State",gxvar:"AV28State",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28State=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28State=Value},v2c:function(){gx.fn.setControlValue("vSTATE",gx.O.AV28State,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV28State=this.val()},val:function(){return gx.fn.getControlValue("vSTATE")},nac:gx.falseFn};
   this.declareDomainHdlr( 125 , function() {
   });
   GXValidFnc[126]={ id: 126, fld:"",grid:0};
   GXValidFnc[127]={ id: 127, fld:"",grid:0};
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id: 129, fld:"",grid:0};
   GXValidFnc[130]={ id:130 ,lvl:0,type:"char",len:15,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLANGUAGE",fmt:0,gxz:"ZV23Language",gxold:"OV23Language",gxvar:"AV23Language",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV23Language=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV23Language=Value},v2c:function(){gx.fn.setComboBoxValue("vLANGUAGE",gx.O.AV23Language);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV23Language=this.val()},val:function(){return gx.fn.getControlValue("vLANGUAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 130 , function() {
   });
   GXValidFnc[131]={ id: 131, fld:"",grid:0};
   GXValidFnc[132]={ id: 132, fld:"",grid:0};
   GXValidFnc[133]={ id: 133, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"",grid:0};
   GXValidFnc[135]={ id:135 ,lvl:0,type:"svchar",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Theme,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTHEME",fmt:0,gxz:"ZV32Theme",gxold:"OV32Theme",gxvar:"AV32Theme",ucs:[],op:[135],ip:[135],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV32Theme=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32Theme=Value},v2c:function(){gx.fn.setComboBoxValue("vTHEME",gx.O.AV32Theme);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV32Theme=this.val()},val:function(){return gx.fn.getControlValue("vTHEME")},nac:gx.falseFn};
   this.declareDomainHdlr( 135 , function() {
   });
   GXValidFnc[136]={ id: 136, fld:"",grid:0};
   GXValidFnc[137]={ id: 137, fld:"",grid:0};
   GXValidFnc[138]={ id: 138, fld:"",grid:0};
   GXValidFnc[139]={ id: 139, fld:"",grid:0};
   GXValidFnc[140]={ id:140 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTIMEZONE",fmt:0,gxz:"ZV29Timezone",gxold:"OV29Timezone",gxvar:"AV29Timezone",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29Timezone=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29Timezone=Value},v2c:function(){gx.fn.setControlValue("vTIMEZONE",gx.O.AV29Timezone,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29Timezone=this.val()},val:function(){return gx.fn.getControlValue("vTIMEZONE")},nac:gx.falseFn};
   this.declareDomainHdlr( 140 , function() {
   });
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[142]={ id: 142, fld:"",grid:0};
   GXValidFnc[144]={ id: 144, fld:"",grid:0};
   GXValidFnc[145]={ id: 145, fld:"",grid:0};
   GXValidFnc[146]={ id: 146, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[147]={ id: 147, fld:"",grid:0};
   GXValidFnc[148]={ id: 148, fld:"",grid:0};
   GXValidFnc[149]={ id: 149, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[150]={ id: 150, fld:"",grid:0};
   GXValidFnc[151]={ id: 151, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e19391_client"};
   GXValidFnc[152]={ id: 152, fld:"",grid:0};
   GXValidFnc[153]={ id: 153, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e15392_client"};
   this.AV40Image_GXI = "" ;
   this.AV22Image = "" ;
   this.ZV22Image = "" ;
   this.OV22Image = "" ;
   this.AV7AuthenticationTypeName = "" ;
   this.ZV7AuthenticationTypeName = "" ;
   this.OV7AuthenticationTypeName = "" ;
   this.AV25Name = "" ;
   this.ZV25Name = "" ;
   this.OV25Name = "" ;
   this.AV14EMail = "" ;
   this.ZV14EMail = "" ;
   this.OV14EMail = "" ;
   this.AV18FirstName = "" ;
   this.ZV18FirstName = "" ;
   this.OV18FirstName = "" ;
   this.AV24LastName = "" ;
   this.ZV24LastName = "" ;
   this.OV24LastName = "" ;
   this.AV13DontReceiveInformation = false ;
   this.ZV13DontReceiveInformation = false ;
   this.OV13DontReceiveInformation = false ;
   this.AV15EnableTwoFactorAuthentication = false ;
   this.ZV15EnableTwoFactorAuthentication = false ;
   this.OV15EnableTwoFactorAuthentication = false ;
   this.AV12DateLastAuthentication = gx.date.nullDate() ;
   this.ZV12DateLastAuthentication = gx.date.nullDate() ;
   this.OV12DateLastAuthentication = gx.date.nullDate() ;
   this.AV10Birthday = gx.date.nullDate() ;
   this.ZV10Birthday = gx.date.nullDate() ;
   this.OV10Birthday = gx.date.nullDate() ;
   this.AV21Gender = "" ;
   this.ZV21Gender = "" ;
   this.OV21Gender = "" ;
   this.AV26Phone = "" ;
   this.ZV26Phone = "" ;
   this.OV26Phone = "" ;
   this.AV5Address = "" ;
   this.ZV5Address = "" ;
   this.OV5Address = "" ;
   this.AV6Address2 = "" ;
   this.ZV6Address2 = "" ;
   this.OV6Address2 = "" ;
   this.AV11City = "" ;
   this.ZV11City = "" ;
   this.OV11City = "" ;
   this.AV28State = "" ;
   this.ZV28State = "" ;
   this.OV28State = "" ;
   this.AV23Language = "" ;
   this.ZV23Language = "" ;
   this.OV23Language = "" ;
   this.AV32Theme = "" ;
   this.ZV32Theme = "" ;
   this.OV32Theme = "" ;
   this.AV29Timezone = "" ;
   this.ZV29Timezone = "" ;
   this.OV29Timezone = "" ;
   this.AV22Image = "" ;
   this.AV7AuthenticationTypeName = "" ;
   this.AV25Name = "" ;
   this.AV14EMail = "" ;
   this.AV18FirstName = "" ;
   this.AV24LastName = "" ;
   this.AV13DontReceiveInformation = false ;
   this.AV15EnableTwoFactorAuthentication = false ;
   this.AV12DateLastAuthentication = gx.date.nullDate() ;
   this.AV10Birthday = gx.date.nullDate() ;
   this.AV21Gender = "" ;
   this.AV26Phone = "" ;
   this.AV5Address = "" ;
   this.AV6Address2 = "" ;
   this.AV11City = "" ;
   this.AV28State = "" ;
   this.AV23Language = "" ;
   this.AV32Theme = "" ;
   this.AV29Timezone = "" ;
   this.Gx_mode = "" ;
   this.AV30URLProfile = "" ;
   this.AV31Window = {} ;
   this.Events = {"e15392_client": ["'CONFIRM'", true] ,"e16392_client": ["'AUTHENTICATORAPP'", true] ,"e18392_client": ["ENTER", true] ,"e19391_client": ["CANCEL", true] ,"e11391_client": ["'EDIT'", false] ,"e12391_client": ["'CHANGENAME'", false] ,"e13391_client": ["'CHANGEEMAIL'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"AV13DontReceiveInformation","fld":"vDONTRECEIVEINFORMATION"},{"av":"AV15EnableTwoFactorAuthentication","fld":"vENABLETWOFACTORAUTHENTICATION"},{"av":"AV30URLProfile","fld":"vURLPROFILE","hsh":true},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"ctrl":"vAUTHENTICATIONTYPENAME"},{"av":"AV7AuthenticationTypeName","fld":"vAUTHENTICATIONTYPENAME","hsh":true},{"av":"AV25Name","fld":"vNAME","hsh":true},{"av":"AV14EMail","fld":"vEMAIL","hsh":true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"ctrl":"vAUTHENTICATIONTYPENAME"},{"av":"AV7AuthenticationTypeName","fld":"vAUTHENTICATIONTYPENAME","hsh":true},{"av":"AV25Name","fld":"vNAME","hsh":true},{"av":"AV14EMail","fld":"vEMAIL","hsh":true},{"av":"AV18FirstName","fld":"vFIRSTNAME"},{"av":"AV24LastName","fld":"vLASTNAME"},{"av":"AV10Birthday","fld":"vBIRTHDAY"},{"ctrl":"vGENDER"},{"av":"AV21Gender","fld":"vGENDER"},{"av":"AV26Phone","fld":"vPHONE"},{"av":"AV5Address","fld":"vADDRESS"},{"av":"AV6Address2","fld":"vADDRESS2"},{"av":"AV11City","fld":"vCITY"},{"av":"AV28State","fld":"vSTATE"},{"ctrl":"vTHEME"},{"av":"AV32Theme","fld":"vTHEME"},{"av":"AV29Timezone","fld":"vTIMEZONE"},{"av":"AV30URLProfile","fld":"vURLPROFILE","hsh":true},{"av":"AV13DontReceiveInformation","fld":"vDONTRECEIVEINFORMATION"},{"av":"AV15EnableTwoFactorAuthentication","fld":"vENABLETWOFACTORAUTHENTICATION"},{"ctrl":"vLANGUAGE"},{"av":"AV23Language","fld":"vLANGUAGE"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"}]];
   this.EvtParms["'EDIT'"] = [[],[]];
   this.EvtParms["'CHANGENAME'"] = [[],[]];
   this.EvtParms["'CHANGEEMAIL'"] = [[],[]];
   this.EvtParms["'AUTHENTICATORAPP'"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_DATELASTAUTHENTICATION"] = [[],[]];
   this.EvtParms["VALIDV_BIRTHDAY"] = [[],[]];
   this.EvtParms["VALIDV_GENDER"] = [[],[]];
   this.EvtParms["VALIDV_THEME"] = [[],[]];
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV30URLProfile", "vURLPROFILE", 0, "svchar", 2048, 250);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0143" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_myaccount);});
