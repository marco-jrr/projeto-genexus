/*
               File: GAM_RolePermissionSelect
        Description: GAM_Selectpermissions
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:33:37.14
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_rolepermissionselect', false, function () {
   this.ServerClass =  "gam_rolepermissionselect" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_rolepermissionselect.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV24RoleId=gx.fn.getIntegerValue("vROLEID",gx.thousandSeparator) ;
      this.AV8ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.AV17isOK=gx.fn.getControlValue("vISOK") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Access=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(25);
      return this.validCliEvt("Validv_Access", 25, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESS");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV6Access , "A" ) == 0 || gx.text.compare( this.AV6Access , "D" ) == 0 || gx.text.compare( this.AV6Access , "R" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Access"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Permissionaccesstype=function()
   {
      return this.validCliEvt("Validv_Permissionaccesstype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vPERMISSIONACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV20PermissionAccessType , "A" ) == 0 || gx.text.compare( this.AV20PermissionAccessType , "D" ) == 0 || gx.text.compare( this.AV20PermissionAccessType , "R" ) == 0 || (gx.text.compare('',this.AV20PermissionAccessType)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Permission Access Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Boolenfilter=function()
   {
      return this.validCliEvt("Validv_Boolenfilter", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vBOOLENFILTER");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV9BoolenFilter , "A" ) == 0 || gx.text.compare( this.AV9BoolenFilter , "T" ) == 0 || gx.text.compare( this.AV9BoolenFilter , "F" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Boolen Filter"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e211g1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Search_Controlvaluechanged Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e131g1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Apply' Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e121g1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearFilters' Routine */
         this.clearMessages();
         this.AV20PermissionAccessType =  ''  ;
         this.AV9BoolenFilter =  ''  ;
         this.refreshOutputs([{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e111g1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Hide' Routine */
         this.clearMessages();
         if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
            gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
         }
         else
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
            gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWW_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWW_TOGGLEFILTERS","prop":"Tooltiptext"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e181g1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'First' Routine */
         this.clearMessages();
         this.AV11CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e191g1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Previous' Routine */
         this.clearMessages();
         this.AV11CurrentPage = gx.num.trunc( this.AV11CurrentPage - 1 ,0) ;
         this.refreshOutputs([{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e201g1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Next' Routine */
         this.clearMessages();
         this.AV11CurrentPage = gx.num.trunc( this.AV11CurrentPage + 1 ,0) ;
         this.refreshOutputs([{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e141g2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e151g2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e221g2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e231g2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,37,40,42,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,74,75,76,77,78,79,80,81,82,83];
   this.GXLastCtrlId =83;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",25,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_rolepermissionselect",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addCheckBox("Select",26,"vSELECT",gx.getMessage( "GAM_Select"),"","Select","boolean","true","false",null,true,false,60,"px","column");
   GridwwContainer.addSingleLineEdit("Name",27,"vNAME",gx.getMessage( "GAM_Permissionname"),"","Name","char",0,"px",254,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Dsc",28,"vDSC",gx.getMessage( "GAM_Description"),"","Dsc","char",0,"px",254,80,"start",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addComboBox("Access",29,"vACCESS",gx.getMessage( "GAM_Permissionsoptions"),"Access","char",null,0,true,false,130,"px","column column-optional");
   GridwwContainer.addSingleLineEdit("Appid",30,"vAPPID",gx.getMessage( "GAM_KeyNumericLong"),"","AppId","int",0,"px",12,12,"end",null,[],"Appid","AppId",false,0,false,false,"Attribute",0,"");
   GridwwContainer.addSingleLineEdit("Id",31,"vID",gx.getMessage( "GAM_GUID"),"","Id","char",0,"px",40,40,"start",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWW",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWW_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWW_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWW_ADDNEW",grid:0,evt:"e241g1_client"};
   GXValidFnc[14]={ id: 14, fld:"CELLSEARCH",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e211g1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV25Search",gxold:"OV25Search",gxvar:"AV25Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV25Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWW_TOGGLEFILTERS",grid:0,evt:"e111g1_client"};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"SECTIONGRID",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GRIDTABLE",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSELECT",fmt:0,gxz:"ZV27Select",gxold:"OV27Select",gxvar:"AV27Select",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV27Select=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV27Select=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vSELECT",row || gx.fn.currentGridRowImpl(25),gx.O.AV27Select,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV27Select=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vSELECT",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV18Name",gxold:"OV18Name",gxvar:"AV18Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV18Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV18Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV18Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV12Dsc",gxold:"OV12Dsc",gxvar:"AV12Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(25),gx.O.AV12Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[29]={ id:29 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:this.Validv_Access,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESS",fmt:0,gxz:"ZV6Access",gxold:"OV6Access",gxvar:"AV6Access",ucs:[],op:[29],ip:[29],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV6Access=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6Access=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vACCESS",row || gx.fn.currentGridRowImpl(25),gx.O.AV6Access);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6Access=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vACCESS",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[30]={ id:30 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAPPID",fmt:0,gxz:"ZV7AppId",gxold:"OV7AppId",gxvar:"AV7AppId",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV7AppId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV7AppId=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vAPPID",row || gx.fn.currentGridRowImpl(25),gx.O.AV7AppId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV7AppId=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vAPPID",row || gx.fn.currentGridRowImpl(25),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[31]={ id:31 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV16Id",gxold:"OV16Id",gxvar:"AV16Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV16Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(25),gx.O.AV16Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[40]={ id: 40, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e181g1_client"};
   GXValidFnc[42]={ id: 42, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e191g1_client"};
   GXValidFnc[44]={ id: 44, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e201g1_client"};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id:48 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV11CurrentPage",gxold:"OV11CurrentPage",gxvar:"AV11CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV11CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV11CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[49]={ id: 49, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e111g1_client"};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id:60 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Permissionaccesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPERMISSIONACCESSTYPE",fmt:0,gxz:"ZV20PermissionAccessType",gxold:"OV20PermissionAccessType",gxvar:"AV20PermissionAccessType",ucs:[],op:[60],ip:[60],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV20PermissionAccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20PermissionAccessType=Value},v2c:function(){gx.fn.setComboBoxValue("vPERMISSIONACCESSTYPE",gx.O.AV20PermissionAccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20PermissionAccessType=this.val()},val:function(){return gx.fn.getControlValue("vPERMISSIONACCESSTYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 60 , function() {
   });
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id:65 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Boolenfilter,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBOOLENFILTER",fmt:0,gxz:"ZV9BoolenFilter",gxold:"OV9BoolenFilter",gxvar:"AV9BoolenFilter",ucs:[],op:[65],ip:[65],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV9BoolenFilter=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9BoolenFilter=Value},v2c:function(){gx.fn.setComboBoxValue("vBOOLENFILTER",gx.O.AV9BoolenFilter);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV9BoolenFilter=this.val()},val:function(){return gx.fn.getControlValue("vBOOLENFILTER")},nac:gx.falseFn};
   this.declareDomainHdlr( 65 , function() {
   });
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e121g1_client"};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e131g1_client"};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"TABLEFOOTER",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"TABLEFOOTER_TABLEBUTTONS",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"TABLEFOOTER_BTNCANCEL",grid:0,evt:"e151g2_client"};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"TABLEFOOTER_BTNCONFIRM",grid:0,evt:"e141g2_client"};
   this.AV25Search = "" ;
   this.ZV25Search = "" ;
   this.OV25Search = "" ;
   this.ZV27Select = false ;
   this.OV27Select = false ;
   this.ZV18Name = "" ;
   this.OV18Name = "" ;
   this.ZV12Dsc = "" ;
   this.OV12Dsc = "" ;
   this.ZV6Access = "" ;
   this.OV6Access = "" ;
   this.ZV7AppId = 0 ;
   this.OV7AppId = 0 ;
   this.ZV16Id = "" ;
   this.OV16Id = "" ;
   this.AV11CurrentPage = 0 ;
   this.ZV11CurrentPage = 0 ;
   this.OV11CurrentPage = 0 ;
   this.AV20PermissionAccessType = "" ;
   this.ZV20PermissionAccessType = "" ;
   this.OV20PermissionAccessType = "" ;
   this.AV9BoolenFilter = "" ;
   this.ZV9BoolenFilter = "" ;
   this.OV9BoolenFilter = "" ;
   this.AV25Search = "" ;
   this.AV11CurrentPage = 0 ;
   this.AV20PermissionAccessType = "" ;
   this.AV9BoolenFilter = "" ;
   this.AV24RoleId = 0 ;
   this.AV8ApplicationId = 0 ;
   this.AV27Select = false ;
   this.AV18Name = "" ;
   this.AV12Dsc = "" ;
   this.AV6Access = "" ;
   this.AV7AppId = 0 ;
   this.AV16Id = "" ;
   this.AV17isOK = false ;
   this.Events = {"e141g2_client": ["'CONFIRM'", true] ,"e151g2_client": ["'CANCEL'", true] ,"e221g2_client": ["ENTER", true] ,"e231g2_client": ["CANCEL", true] ,"e211g1_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e131g1_client": ["'APPLY'", false] ,"e121g1_client": ["'CLEARFILTERS'", false] ,"e111g1_client": ["'HIDE'", false] ,"e181g1_client": ["'FIRST'", false] ,"e191g1_client": ["'PREVIOUS'", false] ,"e201g1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[{"ctrl":"FORM","prop":"Caption"},{"av":"AV16Id","fld":"vID","hsh":true},{"av":"AV18Name","fld":"vNAME"},{"av":"AV12Dsc","fld":"vDSC"},{"ctrl":"GAM_PAGINGWW_BTNNEXT","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNFIRST","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNPREVIOUS","prop":"Enabled"}]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV27Select","fld":"vSELECT","grid":25},{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"nRC_GXsfl_25","ctrl":"GRIDWW","grid":25,"prop":"GridRC","grid":25},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV16Id","fld":"vID","grid":25,"hsh":true},{"av":"AV6Access","fld":"vACCESS","grid":25},{"av":"AV17isOK","fld":"vISOK"}],[{"av":"AV17isOK","fld":"vISOK"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'CANCEL'"] = [[{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true}],[]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[]];
   this.EvtParms["'APPLY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"}]];
   this.EvtParms["'HIDE'"] = [[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWW_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWW_TOGGLEFILTERS","prop":"Tooltiptext"}]];
   this.EvtParms["'FIRST'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'PREVIOUS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'NEXT'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24RoleId","fld":"vROLEID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV25Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV20PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV11CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"subGridww_Recordcount"}],[]];
   this.EvtParms["VALIDV_PERMISSIONACCESSTYPE"] = [[],[]];
   this.EvtParms["VALIDV_BOOLENFILTER"] = [[],[]];
   this.EvtParms["VALIDV_ACCESS"] = [[{"ctrl":"vACCESS"},{"av":"AV6Access","fld":"vACCESS"}],[{"ctrl":"vACCESS"},{"av":"AV6Access","fld":"vACCESS"}]];
   this.setVCMap("AV24RoleId", "vROLEID", 0, "int", 12, 0);
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV17isOK", "vISOK", 0, "boolean", 4, 0);
   this.setVCMap("AV24RoleId", "vROLEID", 0, "int", 12, 0);
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV24RoleId", "vROLEID", 0, "int", 12, 0);
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV24RoleId"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV8ApplicationId"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[60]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[65]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[48]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV24RoleId"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV8ApplicationId"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[60]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[65]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[48]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0073" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_rolepermissionselect);});
