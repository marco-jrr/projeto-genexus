/*
               File: GAM_TestExternalLogin
        Description: GAM_TestExternalLogin
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:33:50.59
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_testexternallogin', false, function () {
   this.ServerClass =  "gam_testexternallogin" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_testexternallogin.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV9Name=gx.fn.getControlValue("vNAME") ;
      this.AV10TypeId=gx.fn.getControlValue("vTYPEID") ;
   };
   this.e111s2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e131s2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,9,10,11,14,15,16,19];
   this.GXLastCtrlId =19;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[9]={ id: 9, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id:11 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",fmt:0,gxz:"ZV11UserName",gxold:"OV11UserName",gxvar:"AV11UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV11UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 11 , function() {
   });
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"char",len:254,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",fmt:0,gxz:"ZV12UserPassword",gxold:"OV12UserPassword",gxvar:"AV12UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV12UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[19]={ id: 19, fld:"ENTER",grid:0,evt:"e111s2_client",std:"ENTER"};
   this.AV11UserName = "" ;
   this.ZV11UserName = "" ;
   this.OV11UserName = "" ;
   this.AV12UserPassword = "" ;
   this.ZV12UserPassword = "" ;
   this.OV12UserPassword = "" ;
   this.AV11UserName = "" ;
   this.AV12UserPassword = "" ;
   this.AV9Name = "" ;
   this.AV10TypeId = "" ;
   this.Events = {"e111s2_client": ["ENTER", true] ,"e131s2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{"av":"AV9Name","fld":"vNAME","hsh":true}],[]];
   this.EvtParms["ENTER"] = [[{"av":"AV9Name","fld":"vNAME","hsh":true},{"av":"AV11UserName","fld":"vUSERNAME"},{"av":"AV12UserPassword","fld":"vUSERPASSWORD"}],[{"ctrl":"WCMESSAGES"}]];
   this.EnterCtrl = ["ENTER"];
   this.setVCMap("AV9Name", "vNAME", 0, "char", 60, 0);
   this.setVCMap("AV10TypeId", "vTYPEID", 0, "char", 30, 0);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0022" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_testexternallogin);});
