/*
               File: GAM_Translations
        Description: GAM_Translations
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:35:46.34
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_translations', false, function () {
   this.ServerClass =  "gam_translations" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_translations.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV24Type=gx.fn.getControlValue("vTYPE") ;
      this.AV18PrimaryID=gx.fn.getIntegerValue("vPRIMARYID",gx.thousandSeparator) ;
      this.AV21TertiaryID=gx.fn.getIntegerValue("vTERTIARYID",gx.thousandSeparator) ;
      this.AV20SecondaryID=gx.fn.getIntegerValue("vSECONDARYID",gx.thousandSeparator) ;
      this.AV23Title=gx.fn.getControlValue("vTITLE") ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.subGridlanguages_Recordcount=gx.fn.getIntegerValue("subGridlanguages_Recordcount",gx.thousandSeparator) ;
   };
   this.s132_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.s142_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'LOADGRID' Routine */
         this.AV6Delete =  gx.getMessage( "GAM_Delete")  ;
         if ( gx.text.compare( this.Gx_mode , "DSP" ) == 0 || gx.text.compare( this.Gx_mode , "DLT" ) == 0 )
         {
            gx.fn.setCtrlProperty("vLANGUAGE","Enabled", false );
            gx.fn.setCtrlProperty("vNAME","Enabled", false );
            gx.fn.setCtrlProperty("vTEXT","Enabled", false );
            gx.fn.setCtrlProperty("vDELETE","Visible", false );
         }
         else
         {
            gx.fn.setCtrlProperty("vNAME","Enabled", true );
            gx.fn.setCtrlProperty("vTEXT","Enabled", true );
         }
      }, arguments);
   };
   this.e153e2_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'DeleteRow' Routine */
         this.clearMessages();
         this.AV17Name =  ''  ;
         this.AV22Text =  ''  ;
         this.refreshOutputs([{"av":"AV17Name","fld":"vNAME"},{"av":"AV22Text","fld":"vTEXT"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e113e2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e123e2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e163e2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e173e2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,28,29,30,31,32,33,34,36,37,38,39,40,41,42,43,44,45];
   this.GXLastCtrlId =45;
   this.GridlanguagesContainer = new gx.grid.grid(this, 2,"WbpLvl2",27,"Gridlanguages","Gridlanguages","GridlanguagesContainer",this.CmpContext,this.IsMasterPage,"gam_translations",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridlanguagesContainer = this.GridlanguagesContainer;
   GridlanguagesContainer.addSingleLineEdit("Lngid",28,"vLNGID","","","LngID","char",0,"px",15,15,"start",null,[],"Lngid","LngID",false,0,false,false,"Attribute",0,"");
   GridlanguagesContainer.addSingleLineEdit("Language",29,"vLANGUAGE",gx.getMessage( "GAM_Language"),"","Language","svchar",38,"%",40,40,"start",null,[],"Language","Language",true,0,false,false,"Attribute",0,"");
   GridlanguagesContainer.addSingleLineEdit("Name",30,"vNAME",gx.getMessage( "GAM_Name"),"","Name","char",40,"%",254,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"");
   GridlanguagesContainer.addSingleLineEdit("Text",31,"vTEXT",gx.getMessage( "GAM_Description"),"","Text","char",100,"%",254,80,"start",null,[],"Text","Text",true,0,false,false,"Attribute",0,"");
   GridlanguagesContainer.addSingleLineEdit("Delete",32,"vDELETE","","","Delete","char",0,"px",20,20,"start","e153e2_client",[],"Delete","Delete",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn");
   this.GridlanguagesContainer.emptyText = gx.getMessage( "GAM_Noresultsfound");
   this.setGrid(GridlanguagesContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWNOFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWNOFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWWNOFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWWNOFILTERS_ADDNEW",grid:0,evt:"e183e1_client"};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV19Search",gxold:"OV19Search",gxvar:"AV19Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV19Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV19Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"SECTION1",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GRIDTABLE",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"GROUPPROPERTIES",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GROUPPROPERTIESTABLE1",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"char",len:15,dec:0,sign:false,ro:0,isacc:0,grid:27,gxgrid:this.GridlanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLNGID",fmt:0,gxz:"ZV16LngID",gxold:"OV16LngID",gxvar:"AV16LngID",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV16LngID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16LngID=Value},v2c:function(row){gx.fn.setGridControlValue("vLNGID",row || gx.fn.currentGridRowImpl(27),gx.O.AV16LngID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16LngID=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vLNGID",row || gx.fn.currentGridRowImpl(27))},nac:gx.falseFn};
   GXValidFnc[29]={ id:29 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:27,gxgrid:this.GridlanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLANGUAGE",fmt:0,gxz:"ZV15Language",gxold:"OV15Language",gxvar:"AV15Language",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV15Language=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15Language=Value},v2c:function(row){gx.fn.setGridControlValue("vLANGUAGE",row || gx.fn.currentGridRowImpl(27),gx.O.AV15Language,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV15Language=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vLANGUAGE",row || gx.fn.currentGridRowImpl(27))},nac:gx.falseFn};
   GXValidFnc[30]={ id:30 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:27,gxgrid:this.GridlanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV17Name",gxold:"OV17Name",gxvar:"AV17Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV17Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(27),gx.O.AV17Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(27))},nac:gx.falseFn};
   GXValidFnc[31]={ id:31 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:27,gxgrid:this.GridlanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTEXT",fmt:0,gxz:"ZV22Text",gxold:"OV22Text",gxvar:"AV22Text",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV22Text=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Text=Value},v2c:function(row){gx.fn.setGridControlValue("vTEXT",row || gx.fn.currentGridRowImpl(27),gx.O.AV22Text,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV22Text=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vTEXT",row || gx.fn.currentGridRowImpl(27))},nac:gx.falseFn};
   GXValidFnc[32]={ id:32 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:27,gxgrid:this.GridlanguagesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDELETE",fmt:0,gxz:"ZV6Delete",gxold:"OV6Delete",gxvar:"AV6Delete",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6Delete=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6Delete=Value},v2c:function(row){gx.fn.setGridControlValue("vDELETE",row || gx.fn.currentGridRowImpl(27),gx.O.AV6Delete,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6Delete=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDELETE",row || gx.fn.currentGridRowImpl(27))},nac:gx.falseFn,evt:"e153e2_client"};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"GAM_FOOTERPOPUP",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"GAM_FOOTERPOPUP_TABLEBUTTONS",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"GAM_FOOTERPOPUP_BTNCANCEL",grid:0,evt:"e113e2_client"};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"GAM_FOOTERPOPUP_BTNCONFIRM",grid:0,evt:"e123e2_client"};
   this.AV19Search = "" ;
   this.ZV19Search = "" ;
   this.OV19Search = "" ;
   this.ZV16LngID = "" ;
   this.OV16LngID = "" ;
   this.ZV15Language = "" ;
   this.OV15Language = "" ;
   this.ZV17Name = "" ;
   this.OV17Name = "" ;
   this.ZV22Text = "" ;
   this.OV22Text = "" ;
   this.ZV6Delete = "" ;
   this.OV6Delete = "" ;
   this.AV19Search = "" ;
   this.AV24Type = "" ;
   this.AV23Title = "" ;
   this.AV18PrimaryID = 0 ;
   this.AV20SecondaryID = 0 ;
   this.AV21TertiaryID = 0 ;
   this.AV16LngID = "" ;
   this.AV15Language = "" ;
   this.AV17Name = "" ;
   this.AV22Text = "" ;
   this.AV6Delete = "" ;
   this.Gx_mode = "" ;
   this.Events = {"e113e2_client": ["'CANCEL'", true] ,"e123e2_client": ["'CONFIRM'", true] ,"e163e2_client": ["ENTER", true] ,"e173e2_client": ["CANCEL", true] ,"e153e2_client": ["'DELETEROW'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDLANGUAGES_nFirstRecordOnPage"},{"av":"GRIDLANGUAGES_nEOF"},{"av":"AV24Type","fld":"vTYPE","hsh":true},{"av":"AV18PrimaryID","fld":"vPRIMARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV21TertiaryID","fld":"vTERTIARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV20SecondaryID","fld":"vSECONDARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV23Title","fld":"vTITLE","hsh":true},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[]];
   this.EvtParms["GRIDLANGUAGES.LOAD"] = [[{"av":"AV24Type","fld":"vTYPE","hsh":true},{"av":"AV18PrimaryID","fld":"vPRIMARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV21TertiaryID","fld":"vTERTIARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV20SecondaryID","fld":"vSECONDARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV23Title","fld":"vTITLE","hsh":true},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[{"av":"AV16LngID","fld":"vLNGID","hsh":true},{"av":"AV15Language","fld":"vLANGUAGE"},{"av":"AV17Name","fld":"vNAME"},{"av":"AV22Text","fld":"vTEXT"},{"av":"gx.fn.getCtrlProperty(\u0027vNAME\u0027,\u0027Visible\u0027)","ctrl":"vNAME","prop":"Visible"},{"av":"AV6Delete","fld":"vDELETE"},{"av":"gx.fn.getCtrlProperty(\u0027vLANGUAGE\u0027,\u0027Enabled\u0027)","ctrl":"vLANGUAGE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vNAME\u0027,\u0027Enabled\u0027)","ctrl":"vNAME","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vTEXT\u0027,\u0027Enabled\u0027)","ctrl":"vTEXT","prop":"Enabled"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'DELETEROW'"] = [[],[{"av":"AV17Name","fld":"vNAME"},{"av":"AV22Text","fld":"vTEXT"}]];
   this.EvtParms["'CANCEL'"] = [[{"av":"AV21TertiaryID","fld":"vTERTIARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV20SecondaryID","fld":"vSECONDARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV18PrimaryID","fld":"vPRIMARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV23Title","fld":"vTITLE","hsh":true},{"av":"AV24Type","fld":"vTYPE","hsh":true},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV18PrimaryID","fld":"vPRIMARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV20SecondaryID","fld":"vSECONDARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV21TertiaryID","fld":"vTERTIARYID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV23Title","fld":"vTITLE","hsh":true},{"av":"AV16LngID","fld":"vLNGID","grid":27,"hsh":true},{"av":"GRIDLANGUAGES_nFirstRecordOnPage"},{"av":"nRC_GXsfl_27","ctrl":"GRIDLANGUAGES","grid":27,"prop":"GridRC","grid":27},{"av":"AV22Text","fld":"vTEXT","grid":27},{"av":"AV17Name","fld":"vNAME","grid":27},{"av":"AV24Type","fld":"vTYPE","hsh":true}],[{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV24Type", "vTYPE", 0, "svchar", 40, 0);
   this.setVCMap("AV18PrimaryID", "vPRIMARYID", 0, "int", 12, 0);
   this.setVCMap("AV21TertiaryID", "vTERTIARYID", 0, "int", 12, 0);
   this.setVCMap("AV20SecondaryID", "vSECONDARYID", 0, "int", 12, 0);
   this.setVCMap("AV23Title", "vTITLE", 0, "svchar", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV24Type", "vTYPE", 0, "svchar", 40, 0);
   this.setVCMap("AV18PrimaryID", "vPRIMARYID", 0, "int", 12, 0);
   this.setVCMap("AV21TertiaryID", "vTERTIARYID", 0, "int", 12, 0);
   this.setVCMap("AV20SecondaryID", "vSECONDARYID", 0, "int", 12, 0);
   this.setVCMap("AV23Title", "vTITLE", 0, "svchar", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV24Type", "vTYPE", 0, "svchar", 40, 0);
   this.setVCMap("AV18PrimaryID", "vPRIMARYID", 0, "int", 12, 0);
   this.setVCMap("AV21TertiaryID", "vTERTIARYID", 0, "int", 12, 0);
   this.setVCMap("AV20SecondaryID", "vSECONDARYID", 0, "int", 12, 0);
   this.setVCMap("AV23Title", "vTITLE", 0, "svchar", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   GridlanguagesContainer.addRefreshingVar({rfrVar:"AV24Type"});
   GridlanguagesContainer.addRefreshingVar({rfrVar:"AV18PrimaryID"});
   GridlanguagesContainer.addRefreshingVar({rfrVar:"AV21TertiaryID"});
   GridlanguagesContainer.addRefreshingVar({rfrVar:"AV20SecondaryID"});
   GridlanguagesContainer.addRefreshingVar({rfrVar:"AV23Title"});
   GridlanguagesContainer.addRefreshingVar({rfrVar:"Gx_mode"});
   GridlanguagesContainer.addRefreshingParm({rfrVar:"AV24Type"});
   GridlanguagesContainer.addRefreshingParm({rfrVar:"AV18PrimaryID"});
   GridlanguagesContainer.addRefreshingParm({rfrVar:"AV21TertiaryID"});
   GridlanguagesContainer.addRefreshingParm({rfrVar:"AV20SecondaryID"});
   GridlanguagesContainer.addRefreshingParm({rfrVar:"AV23Title"});
   GridlanguagesContainer.addRefreshingParm({rfrVar:"Gx_mode"});
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0035" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_translations);});
