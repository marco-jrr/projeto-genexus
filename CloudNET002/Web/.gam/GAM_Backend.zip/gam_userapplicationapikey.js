/*
               File: GAM_UserApplicationAPIkey
        Description: GAM_ApplicationAPIKey
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:36:0.3
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_userapplicationapikey', false, function () {
   this.ServerClass =  "gam_userapplicationapikey" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_userapplicationapikey.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV13UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.AV20DetailedScope=gx.fn.getControlValue("vDETAILEDSCOPE") ;
      this.AV22UserAPIkey=gx.fn.getControlValue("vUSERAPIKEY") ;
      this.AV23UserAPIkeyExpires=gx.fn.getDateTimeValue("vUSERAPIKEYEXPIRES") ;
   };
   this.Validv_Expires=function()
   {
      return this.validCliEvt("Validv_Expires", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vEXPIRES");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV8Expires)===0) || new gx.date.gxdate( this.AV8Expires ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Expires"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e123g2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e133g2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e153g2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e163g2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,76,77,78,79,80,81,82,83,84,85,86];
   this.GXLastCtrlId =86;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id:11 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMUSEREMAIL",fmt:0,gxz:"ZV12GAMUserEmail",gxold:"OV12GAMUserEmail",gxvar:"AV12GAMUserEmail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12GAMUserEmail=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12GAMUserEmail=Value},v2c:function(){gx.fn.setControlValue("vGAMUSEREMAIL",gx.O.AV12GAMUserEmail,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12GAMUserEmail=this.val()},val:function(){return gx.fn.getControlValue("vGAMUSEREMAIL")},nac:gx.falseFn};
   this.declareDomainHdlr( 11 , function() {
   });
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTID",fmt:0,gxz:"ZV6ClientID",gxold:"OV6ClientID",gxvar:"AV6ClientID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV6ClientID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6ClientID=Value},v2c:function(){gx.fn.setControlValue("vCLIENTID",gx.O.AV6ClientID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV6ClientID=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"TBLRESTSCOPES",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"TBLRESTPREDSCOPES",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"TBALLOWEDRESTSCOPES", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"TABLE2",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id:31 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERDATAREST",fmt:0,gxz:"ZV14ClientAllowGetUserDataREST",gxold:"OV14ClientAllowGetUserDataREST",gxvar:"AV14ClientAllowGetUserDataREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV14ClientAllowGetUserDataREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV14ClientAllowGetUserDataREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERDATAREST",gx.O.AV14ClientAllowGetUserDataREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14ClientAllowGetUserDataREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERDATAREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 31 , function() {
   });
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERADDDATAREST",fmt:0,gxz:"ZV15ClientAllowGetUserAddDataREST",gxold:"OV15ClientAllowGetUserAddDataREST",gxvar:"AV15ClientAllowGetUserAddDataREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV15ClientAllowGetUserAddDataREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV15ClientAllowGetUserAddDataREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERADDDATAREST",gx.O.AV15ClientAllowGetUserAddDataREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15ClientAllowGetUserAddDataREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERADDDATAREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 35 , function() {
   });
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id:39 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETUSERROLESREST",fmt:0,gxz:"ZV16ClientAllowGetUserRolesRest",gxold:"OV16ClientAllowGetUserRolesRest",gxvar:"AV16ClientAllowGetUserRolesRest",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV16ClientAllowGetUserRolesRest=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV16ClientAllowGetUserRolesRest=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETUSERROLESREST",gx.O.AV16ClientAllowGetUserRolesRest,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16ClientAllowGetUserRolesRest=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETUSERROLESREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 39 , function() {
   });
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"TABLE5",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id:47 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONINIPROPREST",fmt:0,gxz:"ZV17ClientAllowGetSessionIniPropREST",gxold:"OV17ClientAllowGetSessionIniPropREST",gxvar:"AV17ClientAllowGetSessionIniPropREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV17ClientAllowGetSessionIniPropREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV17ClientAllowGetSessionIniPropREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONINIPROPREST",gx.O.AV17ClientAllowGetSessionIniPropREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17ClientAllowGetSessionIniPropREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONINIPROPREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 47 , function() {
   });
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id:51 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWGETSESSIONAPPDATAREST",fmt:0,gxz:"ZV18ClientAllowGetSessionAppDataREST",gxold:"OV18ClientAllowGetSessionAppDataREST",gxvar:"AV18ClientAllowGetSessionAppDataREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV18ClientAllowGetSessionAppDataREST=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV18ClientAllowGetSessionAppDataREST=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vCLIENTALLOWGETSESSIONAPPDATAREST",gx.O.AV18ClientAllowGetSessionAppDataREST,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18ClientAllowGetSessionAppDataREST=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vCLIENTALLOWGETSESSIONAPPDATAREST")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 51 , function() {
   });
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id:56 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTALLOWADDITIONALSCOPEREST",fmt:0,gxz:"ZV19ClientAllowAdditionalScopeREST",gxold:"OV19ClientAllowAdditionalScopeREST",gxvar:"AV19ClientAllowAdditionalScopeREST",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV19ClientAllowAdditionalScopeREST=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19ClientAllowAdditionalScopeREST=Value},v2c:function(){gx.fn.setControlValue("vCLIENTALLOWADDITIONALSCOPEREST",gx.O.AV19ClientAllowAdditionalScopeREST,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19ClientAllowAdditionalScopeREST=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTALLOWADDITIONALSCOPEREST")},nac:gx.falseFn};
   this.declareDomainHdlr( 56 , function() {
   });
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id:62 ,lvl:0,type:"svchar",len:2048,dec:100,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAPIKEY",fmt:0,gxz:"ZV5APIkey",gxold:"OV5APIkey",gxvar:"AV5APIkey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV5APIkey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5APIkey=Value},v2c:function(){gx.fn.setControlValue("vAPIKEY",gx.O.AV5APIkey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5APIkey=this.val()},val:function(){return gx.fn.getControlValue("vAPIKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 62 , function() {
   });
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id:70 ,lvl:0,type:"dtime",len:10,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Expires,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEXPIRES",fmt:0,gxz:"ZV8Expires",gxold:"OV8Expires",gxvar:"AV8Expires",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/9999 99:99",dec:5},ucs:[],op:[70],ip:[70],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8Expires=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV8Expires=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vEXPIRES",gx.O.AV8Expires,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8Expires=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vEXPIRES")},nac:gx.falseFn};
   this.declareDomainHdlr( 70 , function() {
   });
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"GAM_FOOTERPOPUP",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"GAM_FOOTERPOPUP_TABLEBUTTONS",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"GAM_FOOTERPOPUP_BTNCANCEL",grid:0,evt:"e133g2_client"};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"GAM_FOOTERPOPUP_BTNCONFIRM",grid:0,evt:"e123g2_client"};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   this.AV12GAMUserEmail = "" ;
   this.ZV12GAMUserEmail = "" ;
   this.OV12GAMUserEmail = "" ;
   this.AV6ClientID = "" ;
   this.ZV6ClientID = "" ;
   this.OV6ClientID = "" ;
   this.AV14ClientAllowGetUserDataREST = false ;
   this.ZV14ClientAllowGetUserDataREST = false ;
   this.OV14ClientAllowGetUserDataREST = false ;
   this.AV15ClientAllowGetUserAddDataREST = false ;
   this.ZV15ClientAllowGetUserAddDataREST = false ;
   this.OV15ClientAllowGetUserAddDataREST = false ;
   this.AV16ClientAllowGetUserRolesRest = false ;
   this.ZV16ClientAllowGetUserRolesRest = false ;
   this.OV16ClientAllowGetUserRolesRest = false ;
   this.AV17ClientAllowGetSessionIniPropREST = false ;
   this.ZV17ClientAllowGetSessionIniPropREST = false ;
   this.OV17ClientAllowGetSessionIniPropREST = false ;
   this.AV18ClientAllowGetSessionAppDataREST = false ;
   this.ZV18ClientAllowGetSessionAppDataREST = false ;
   this.OV18ClientAllowGetSessionAppDataREST = false ;
   this.AV19ClientAllowAdditionalScopeREST = "" ;
   this.ZV19ClientAllowAdditionalScopeREST = "" ;
   this.OV19ClientAllowAdditionalScopeREST = "" ;
   this.AV5APIkey = "" ;
   this.ZV5APIkey = "" ;
   this.OV5APIkey = "" ;
   this.AV8Expires = gx.date.nullDate() ;
   this.ZV8Expires = gx.date.nullDate() ;
   this.OV8Expires = gx.date.nullDate() ;
   this.AV12GAMUserEmail = "" ;
   this.AV6ClientID = "" ;
   this.AV14ClientAllowGetUserDataREST = false ;
   this.AV15ClientAllowGetUserAddDataREST = false ;
   this.AV16ClientAllowGetUserRolesRest = false ;
   this.AV17ClientAllowGetSessionIniPropREST = false ;
   this.AV18ClientAllowGetSessionAppDataREST = false ;
   this.AV19ClientAllowAdditionalScopeREST = "" ;
   this.AV5APIkey = "" ;
   this.AV8Expires = gx.date.nullDate() ;
   this.AV13UserGUID = "" ;
   this.AV20DetailedScope = "" ;
   this.AV22UserAPIkey = "" ;
   this.AV23UserAPIkeyExpires = gx.date.nullDate() ;
   this.Events = {"e123g2_client": ["'CONFIRM'", true] ,"e133g2_client": ["'CANCEL'", true] ,"e153g2_client": ["ENTER", true] ,"e163g2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{"av":"AV14ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"AV15ClientAllowGetUserAddDataREST","fld":"vCLIENTALLOWGETUSERADDDATAREST"},{"av":"AV16ClientAllowGetUserRolesRest","fld":"vCLIENTALLOWGETUSERROLESREST"},{"av":"AV17ClientAllowGetSessionIniPropREST","fld":"vCLIENTALLOWGETSESSIONINIPROPREST"},{"av":"AV18ClientAllowGetSessionAppDataREST","fld":"vCLIENTALLOWGETSESSIONAPPDATAREST"},{"av":"AV13UserGUID","fld":"vUSERGUID","hsh":true},{"av":"AV20DetailedScope","fld":"vDETAILEDSCOPE","hsh":true},{"av":"AV22UserAPIkey","fld":"vUSERAPIKEY","hsh":true},{"av":"AV23UserAPIkeyExpires","fld":"vUSERAPIKEYEXPIRES","pic":"99/99/9999 99:99","hsh":true},{"av":"AV6ClientID","fld":"vCLIENTID","hsh":true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"AV13UserGUID","fld":"vUSERGUID","hsh":true},{"av":"AV14ClientAllowGetUserDataREST","fld":"vCLIENTALLOWGETUSERDATAREST"},{"av":"AV15ClientAllowGetUserAddDataREST","fld":"vCLIENTALLOWGETUSERADDDATAREST"},{"av":"AV16ClientAllowGetUserRolesRest","fld":"vCLIENTALLOWGETUSERROLESREST"},{"av":"AV17ClientAllowGetSessionIniPropREST","fld":"vCLIENTALLOWGETSESSIONINIPROPREST"},{"av":"AV18ClientAllowGetSessionAppDataREST","fld":"vCLIENTALLOWGETSESSIONAPPDATAREST"},{"av":"AV19ClientAllowAdditionalScopeREST","fld":"vCLIENTALLOWADDITIONALSCOPEREST"},{"av":"AV20DetailedScope","fld":"vDETAILEDSCOPE","hsh":true},{"av":"AV6ClientID","fld":"vCLIENTID","hsh":true},{"av":"AV22UserAPIkey","fld":"vUSERAPIKEY","hsh":true},{"av":"AV23UserAPIkeyExpires","fld":"vUSERAPIKEYEXPIRES","pic":"99/99/9999 99:99","hsh":true}],[{"av":"AV5APIkey","fld":"vAPIKEY"},{"av":"gx.fn.getCtrlProperty(\u0027vCLIENTALLOWGETUSERDATAREST\u0027,\u0027Enabled\u0027)","ctrl":"vCLIENTALLOWGETUSERDATAREST","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLIENTALLOWGETUSERADDDATAREST\u0027,\u0027Enabled\u0027)","ctrl":"vCLIENTALLOWGETUSERADDDATAREST","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLIENTALLOWGETUSERROLESREST\u0027,\u0027Enabled\u0027)","ctrl":"vCLIENTALLOWGETUSERROLESREST","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLIENTALLOWGETSESSIONINIPROPREST\u0027,\u0027Enabled\u0027)","ctrl":"vCLIENTALLOWGETSESSIONINIPROPREST","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLIENTALLOWGETSESSIONAPPDATAREST\u0027,\u0027Enabled\u0027)","ctrl":"vCLIENTALLOWGETSESSIONAPPDATAREST","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLIENTALLOWADDITIONALSCOPEREST\u0027,\u0027Enabled\u0027)","ctrl":"vCLIENTALLOWADDITIONALSCOPEREST","prop":"Enabled"},{"av":"AV8Expires","fld":"vEXPIRES","pic":"99/99/9999 99:99"},{"av":"gx.fn.getCtrlProperty(\u0027vEXPIRES\u0027,\u0027Visible\u0027)","ctrl":"vEXPIRES","prop":"Visible"},{"ctrl":"GAM_FOOTERPOPUP_BTNCONFIRM","prop":"Visible"},{"ctrl":"GAM_FOOTERPOPUP_BTNCANCEL","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'CANCEL'"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_EXPIRES"] = [[],[]];
   this.setVCMap("AV13UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV20DetailedScope", "vDETAILEDSCOPE", 0, "svchar", 2048, 100);
   this.setVCMap("AV22UserAPIkey", "vUSERAPIKEY", 0, "svchar", 2048, 100);
   this.setVCMap("AV23UserAPIkeyExpires", "vUSERAPIKEYEXPIRES", 0, "dtime", 10, 5);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0075" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_userapplicationapikey);});
