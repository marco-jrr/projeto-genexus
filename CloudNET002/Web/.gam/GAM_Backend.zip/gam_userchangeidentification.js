/*
               File: GAM_UserChangeIdentification
        Description: GAM_ChangeuserID
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:35:28.87
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_userchangeidentification', false, function () {
   this.ServerClass =  "gam_userchangeidentification" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_userchangeidentification.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV6ChangeType=gx.fn.getControlValue("vCHANGETYPE") ;
   };
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e123b2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e143b2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e153b2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,27,28,29,30,31,32,33,34,35,36];
   this.GXLastCtrlId =36;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id:8 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTUSERIDENTIFICATON",fmt:0,gxz:"ZV8CurrentUserIdentificaton",gxold:"OV8CurrentUserIdentificaton",gxvar:"AV8CurrentUserIdentificaton",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8CurrentUserIdentificaton=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8CurrentUserIdentificaton=Value},v2c:function(){gx.fn.setControlValue("vCURRENTUSERIDENTIFICATON",gx.O.AV8CurrentUserIdentificaton,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8CurrentUserIdentificaton=this.val()},val:function(){return gx.fn.getControlValue("vCURRENTUSERIDENTIFICATON")},nac:gx.falseFn};
   this.declareDomainHdlr( 8 , function() {
   });
   GXValidFnc[9]={ id: 9, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id:13 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNEWUSERIDENTIFICATION",fmt:0,gxz:"ZV12NewUserIdentification",gxold:"OV12NewUserIdentification",gxvar:"AV12NewUserIdentification",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12NewUserIdentification=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12NewUserIdentification=Value},v2c:function(){gx.fn.setControlValue("vNEWUSERIDENTIFICATION",gx.O.AV12NewUserIdentification,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12NewUserIdentification=this.val()},val:function(){return gx.fn.getControlValue("vNEWUSERIDENTIFICATION")},nac:gx.falseFn};
   this.declareDomainHdlr( 13 , function() {
   });
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id:18 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONFIRMUSERIDENTIFICATION",fmt:0,gxz:"ZV7ConfirmUserIdentification",gxold:"OV7ConfirmUserIdentification",gxvar:"AV7ConfirmUserIdentification",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7ConfirmUserIdentification=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7ConfirmUserIdentification=Value},v2c:function(){gx.fn.setControlValue("vCONFIRMUSERIDENTIFICATION",gx.O.AV7ConfirmUserIdentification,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV7ConfirmUserIdentification=this.val()},val:function(){return gx.fn.getControlValue("vCONFIRMUSERIDENTIFICATION")},nac:gx.falseFn};
   this.declareDomainHdlr( 18 , function() {
   });
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id:23 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",fmt:0,gxz:"ZV13UserPassword",gxold:"OV13UserPassword",gxvar:"AV13UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV13UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 23 , function() {
   });
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"GAM_FOOTERPOPUP",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"GAM_FOOTERPOPUP_TABLEBUTTONS",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"GAM_FOOTERPOPUP_BTNCANCEL",grid:0,evt:"e163b1_client"};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"GAM_FOOTERPOPUP_BTNCONFIRM",grid:0,evt:"e123b2_client"};
   this.AV8CurrentUserIdentificaton = "" ;
   this.ZV8CurrentUserIdentificaton = "" ;
   this.OV8CurrentUserIdentificaton = "" ;
   this.AV12NewUserIdentification = "" ;
   this.ZV12NewUserIdentification = "" ;
   this.OV12NewUserIdentification = "" ;
   this.AV7ConfirmUserIdentification = "" ;
   this.ZV7ConfirmUserIdentification = "" ;
   this.OV7ConfirmUserIdentification = "" ;
   this.AV13UserPassword = "" ;
   this.ZV13UserPassword = "" ;
   this.OV13UserPassword = "" ;
   this.AV8CurrentUserIdentificaton = "" ;
   this.AV12NewUserIdentification = "" ;
   this.AV7ConfirmUserIdentification = "" ;
   this.AV13UserPassword = "" ;
   this.AV6ChangeType = "" ;
   this.Events = {"e123b2_client": ["'CONFIRM'", true] ,"e143b2_client": ["ENTER", true] ,"e153b2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{"av":"AV6ChangeType","fld":"vCHANGETYPE","hsh":true},{"av":"AV8CurrentUserIdentificaton","fld":"vCURRENTUSERIDENTIFICATON","hsh":true}],[]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"AV6ChangeType","fld":"vCHANGETYPE","hsh":true},{"av":"AV12NewUserIdentification","fld":"vNEWUSERIDENTIFICATION"},{"av":"AV7ConfirmUserIdentification","fld":"vCONFIRMUSERIDENTIFICATION"},{"av":"AV8CurrentUserIdentificaton","fld":"vCURRENTUSERIDENTIFICATON","hsh":true},{"av":"AV13UserPassword","fld":"vUSERPASSWORD"}],[{"av":"gx.fn.getCtrlProperty(\u0027vNEWUSERIDENTIFICATION\u0027,\u0027Enabled\u0027)","ctrl":"vNEWUSERIDENTIFICATION","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCONFIRMUSERIDENTIFICATION\u0027,\u0027Enabled\u0027)","ctrl":"vCONFIRMUSERIDENTIFICATION","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vUSERPASSWORD\u0027,\u0027Enabled\u0027)","ctrl":"vUSERPASSWORD","prop":"Enabled"},{"ctrl":"GAM_FOOTERPOPUP_BTNCONFIRM","prop":"Visible"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV6ChangeType", "vCHANGETYPE", 0, "svchar", 40, 0);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0026" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_userchangeidentification);});
