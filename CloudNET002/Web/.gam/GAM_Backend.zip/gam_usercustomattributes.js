/*
               File: GAM_UserCustomAttributes
        Description: GAM_UserCustomAttributes
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:35:50.46
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_usercustomattributes', false, function () {
   this.ServerClass =  "gam_usercustomattributes" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_usercustomattributes.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV17GUID=gx.fn.getControlValue("vGUID") ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV19Title=gx.fn.getControlValue("vTITLE") ;
      this.subGridattributes_Recordcount=gx.fn.getIntegerValue("subGridattributes_Recordcount",gx.thousandSeparator) ;
   };
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.s122_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'EVALUATEMODEANDATTTYPE' Routine */
         this.AV10Delete =  gx.getMessage( "GAM_Delete")  ;
         this.AV11ClearMV =  gx.getMessage( "GAM_Clear")  ;
         if ( gx.text.compare( this.Gx_mode , "DSP" ) == 0 || gx.text.compare( this.Gx_mode , "DLT" ) == 0 )
         {
            gx.fn.setCtrlProperty("vATTRIBUTEID","Enabled", false );
            gx.fn.setCtrlProperty("vATTRIBUTEVALUE","Enabled", false );
            gx.fn.setCtrlProperty("vATTRIBUTEISMV","Enabled", false );
            gx.fn.setCtrlProperty("vDELETE","Visible", false );
            gx.fn.setCtrlProperty("vCLEARMV","Visible", false );
            gx.fn.setCtrlProperty("NEWMV","Visible", false );
            if ( this.AV6AttributeIsMV )
            {
               gx.fn.setCtrlProperty("TABLEMV","Visible", true );
               gx.fn.setCtrlProperty("vATTRIBUTEVALUE","Visible", false );
            }
            else
            {
               gx.fn.setCtrlProperty("TABLEMV","Visible", false );
               gx.fn.setCtrlProperty("vATTRIBUTEVALUE","Visible", true );
            }
         }
         else
         {
            gx.fn.setCtrlProperty("vATTRIBUTEID","Enabled", true );
            gx.fn.setCtrlProperty("vATTRIBUTEVALUE","Enabled", true );
            gx.fn.setCtrlProperty("vATTRIBUTEISMV","Enabled", true );
            if ( this.AV6AttributeIsMV )
            {
               gx.fn.setCtrlProperty("vCLEARMV","Visible", true );
               gx.fn.setCtrlProperty("NEWMV","Visible", true );
               gx.fn.setCtrlProperty("TABLEMV","Visible", true );
               gx.fn.setCtrlProperty("vATTRIBUTEVALUE","Visible", false );
            }
            else
            {
               gx.fn.setCtrlProperty("vCLEARMV","Visible", false );
               gx.fn.setCtrlProperty("NEWMV","Visible", false );
               gx.fn.setCtrlProperty("TABLEMV","Visible", false );
               gx.fn.setCtrlProperty("vATTRIBUTEVALUE","Visible", true );
            }
         }
      }, arguments);
   };
   this.e203j2_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Attributeismv_Controlvaluechanged Routine */
         this.clearMessages();
         this.s122_client();
         this.refreshOutputs([{"av":"AV10Delete","fld":"vDELETE"},{"av":"AV11ClearMV","fld":"vCLEARMV"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEID\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEID","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEISMV\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEISMV","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLEARMV\u0027,\u0027Visible\u0027)","ctrl":"vCLEARMV","prop":"Visible"},{"ctrl":"NEWMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLEMV\u0027,\u0027Visible\u0027)","ctrl":"TABLEMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e193j2_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'DeleteRow' Routine */
         this.clearMessages();
         gx.fn.setCtrlProperty("vATTRIBUTEID","Visible", false );
         gx.fn.setCtrlProperty("vDELETE","Visible", false );
         this.AV5AttributeID =  ''  ;
         this.AV10Delete =  ''  ;
         gx.fn.setCtrlProperty("MVTABLE","Visible", false );
         gx.fn.setCtrlProperty("VALUESTABLE","Visible", false );
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEID\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEID","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"AV5AttributeID","fld":"vATTRIBUTEID"},{"av":"AV10Delete","fld":"vDELETE"},{"av":"gx.fn.getCtrlProperty(\u0027MVTABLE\u0027,\u0027Visible\u0027)","ctrl":"MVTABLE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027VALUESTABLE\u0027,\u0027Visible\u0027)","ctrl":"VALUESTABLE","prop":"Visible"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e183j2_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearRowsMV' Routine */
         this.clearMessages();
         /* Start For Each Line in Gridmv */
         var rowIdxS30 = gx.fn.currentGridRowImpl(30) ;
         var rowIdx71 = 1 ;
         var currentRowIdx71 = gx.fn.currentGridRowImpl(71) ;
         var rowIdxS71 ;
         var gridObj71 = gx.O.getGridById(71,rowIdxS30) ;
         while ( rowIdx71 <= gridObj71.grid.rows.length )
         {
            rowIdxS71 =  gx.text.padl( gx.text.tostring( rowIdx71), 4, "0")  ;
            gridObj71.instanciateRow(gridObj71.grid.getRowById(rowIdx71 - 1));
            gx.fn.setCtrlProperty("vATTRIBUTEMVID","Visible", false );
            gx.fn.setCtrlProperty("vATTRIBUTEMVVALUE","Visible", false );
            this.AV7AttributeMVID =  ''  ;
            this.AV8AttributeMVValue =  ''  ;
            rowIdx71 = gx.num.trunc( rowIdx71 + 1 ,0) ;
            this.refreshRowOutputs([{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVID\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEMVID","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEMVVALUE","prop":"Visible"},{"av":"AV7AttributeMVID","fld":"vATTRIBUTEMVID"},{"av":"AV8AttributeMVValue","fld":"vATTRIBUTEMVVALUE"}]);
         }
         if ( currentRowIdx71 )
         {
            gridObj71.instanciateRow(currentRowIdx71);
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVID\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEMVID","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEMVVALUE","prop":"Visible"},{"av":"AV7AttributeMVID","fld":"vATTRIBUTEMVID"},{"av":"AV8AttributeMVValue","fld":"vATTRIBUTEMVVALUE"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e113j2_client=function()
   {
      /* 'NewRow' Routine */
      return this.executeServerEvent("'NEWROW'", false, null, false, false);
   };
   this.e143j2_client=function()
   {
      /* 'NewRowMV' Routine */
      return this.executeServerEvent("'NEWROWMV'", true, arguments[0], false, false);
   };
   this.e123j2_client=function()
   {
      /* 'Cancel' Routine */
      return this.executeServerEvent("'CANCEL'", false, null, false, false);
   };
   this.e133j2_client=function()
   {
      /* 'Confirm' Routine */
      return this.executeServerEvent("'CONFIRM'", false, null, false, false);
   };
   this.e213j2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e223j2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,31,32,33,34,35,36,37,38,41,42,43,46,47,48,51,52,53,56,59,62,64,67,68,72,73,74,75,76,77,78,79,81,82,83,84,85,86,87,88,89,90];
   this.GXLastCtrlId =90;
   this.GridmvContainer = new gx.grid.grid(this, 3,"WbpLvl3",71,"Gridmv","Gridmv","GridmvContainer",this.CmpContext,this.IsMasterPage,"gam_usercustomattributes",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridmvContainer = this.GridmvContainer;
   GridmvContainer.addSingleLineEdit("Attributemvid",72,"vATTRIBUTEMVID",gx.getMessage( "GAM_AttributeID"),"","AttributeMVID","svchar",0,"px",40,40,"start",null,[],"Attributemvid","AttributeMVID",true,0,false,false,"Attribute",0,"");
   GridmvContainer.addSingleLineEdit("Attributemvvalue",73,"vATTRIBUTEMVVALUE",gx.getMessage( "GAM_AttributeValue"),"","AttributeMVValue","svchar",0,"px",40,40,"start",null,[],"Attributemvvalue","AttributeMVValue",true,0,false,false,"Attribute",0,"");
   this.GridmvContainer.emptyText = gx.getMessage( "");
   this.GridattributesContainer = new gx.grid.grid(this, 2,"WbpLvl2",30,"Gridattributes","Gridattributes","GridattributesContainer",this.CmpContext,this.IsMasterPage,"gam_usercustomattributes",[],true,1,false,true,0,false,false,false,"",100,"%",0,"px",gx.getMessage( "GXM_newrow"),false,false,true,null,null,false,"",true,[1,1,1,1],false,0,false,false);
   var GridattributesContainer = this.GridattributesContainer;
   GridattributesContainer.startDiv(31,"Resposibletable","0px","0px");
   GridattributesContainer.startDiv(32,"","0px","0px");
   GridattributesContainer.startDiv(33,"","0px","0px");
   GridattributesContainer.startDiv(34,"","0px","0px");
   GridattributesContainer.addLabel();
   GridattributesContainer.startDiv(35,"","0px","0px");
   GridattributesContainer.addSingleLineEdit("Attributeid",36,"vATTRIBUTEID","","","AttributeID","svchar",40,"chr",40,40,"start",null,[],"Attributeid","AttributeID",true,0,false,false,"Attribute",0,"");
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   GridattributesContainer.startDiv(37,"","0px","0px");
   GridattributesContainer.startTable("Mvtable",38,"0px");
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.startDiv(41,"","0px","0px");
   GridattributesContainer.addLabel();
   GridattributesContainer.startDiv(42,"","0px","100%");
   GridattributesContainer.addCheckBox("Attributeismv",43,"vATTRIBUTEISMV","","","AttributeIsMV","boolean","true","false",null,true,false,1,"chr","");
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","stack-bottom-r");
   GridattributesContainer.addButton(46,"NEWMV","standard","'","e143j2_client");
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.endTable();
   GridattributesContainer.endDiv();
   GridattributesContainer.startDiv(47,"","0px","0px");
   GridattributesContainer.startTable("Valuestable",48,"0px");
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.startDiv(51,"","0px","0px");
   GridattributesContainer.addLabel();
   GridattributesContainer.startDiv(52,"","0px","100%");
   GridattributesContainer.addSingleLineEdit("Attributevalue",53,"vATTRIBUTEVALUE","","","AttributeValue","svchar",75,"%",40,40,"start",null,[],"Attributevalue","AttributeValue",true,0,false,false,"Attribute",0,"");
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.startTable("Tablemv",56,"0px");
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.startTable("Tablemvtitle",59,"0px");
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.addTextBlock('TBATTRIBUTEVALUELIST',null,62);
   GridattributesContainer.endCell();
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.startTable("Tableclearmv",64,"0px");
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.startDiv(67,"","0px","0px");
   GridattributesContainer.addSingleLineEdit("Clearmv",68,"vCLEARMV","","","ClearMV","char",20,"chr",20,20,"start","e183j2_client",[],"Clearmv","ClearMV",true,0,false,false,"TextActionAttribute",0,"");
   GridattributesContainer.endDiv();
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.endTable();
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.endTable();
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.startRow("","","","","","");
   GridattributesContainer.startCell("","","","","","","","","","");
   GridattributesContainer.addGrid(this.GridmvContainer);
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.endTable();
   GridattributesContainer.endCell();
   GridattributesContainer.endRow();
   GridattributesContainer.endTable();
   GridattributesContainer.endDiv();
   GridattributesContainer.startDiv(74,"","0px","0px");
   GridattributesContainer.startDiv(75,"","0px","0px");
   GridattributesContainer.startDiv(76,"","0px","0px");
   GridattributesContainer.addSingleLineEdit("Delete",77,"vDELETE","","","Delete","char",20,"chr",20,20,"start","e193j2_client",[],"Delete","Delete",true,0,false,false,"TextActionAttribute",0,"");
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   GridattributesContainer.endDiv();
   this.GridattributesContainer.emptyText = gx.getMessage( "GAM_Noresultsfound");
   this.setGrid(GridattributesContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWNOFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWNOFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWWNOFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWWNOFILTERS_ADDNEW",grid:0,evt:"e233j1_client"};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV18Search",gxold:"OV18Search",gxvar:"AV18Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV18Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"SECTION1",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GRIDTABLE",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"GROUPPROPERTIES",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GROUPPROPERTIESTABLE1",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"BTNADDGRIDLINE",grid:0,evt:"e113j2_client"};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"RESPOSIBLETABLE",grid:30};
   GXValidFnc[32]={ id: 32, fld:"",grid:30};
   GXValidFnc[33]={ id: 33, fld:"",grid:30};
   GXValidFnc[34]={ id: 34, fld:"",grid:30};
   GXValidFnc[35]={ id: 35, fld:"",grid:30};
   GXValidFnc[36]={ id:36 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:30,gxgrid:this.GridattributesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vATTRIBUTEID",fmt:0,gxz:"ZV5AttributeID",gxold:"OV5AttributeID",gxvar:"AV5AttributeID",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5AttributeID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AttributeID=Value},v2c:function(row){gx.fn.setGridControlValue("vATTRIBUTEID",row || gx.fn.currentGridRowImpl(30),gx.O.AV5AttributeID,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5AttributeID=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vATTRIBUTEID",row || gx.fn.currentGridRowImpl(30))},nac:gx.falseFn};
   GXValidFnc[37]={ id: 37, fld:"",grid:30};
   GXValidFnc[38]={ id: 38, fld:"MVTABLE",grid:30};
   GXValidFnc[41]={ id: 41, fld:"",grid:30};
   GXValidFnc[42]={ id: 42, fld:"",grid:30};
   GXValidFnc[43]={ id:43 ,lvl:2,type:"boolean",len:1,dec:0,sign:false,ro:0,isacc:0,grid:30,gxgrid:this.GridattributesContainer,fnc:null,isvalid:null,evt_cvc:'e203j2_client',evt_cvcing:null,rgrid:[],fld:"vATTRIBUTEISMV",fmt:0,gxz:"ZV6AttributeIsMV",gxold:"OV6AttributeIsMV",gxvar:"AV6AttributeIsMV",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV6AttributeIsMV=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV6AttributeIsMV=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vATTRIBUTEISMV",row || gx.fn.currentGridRowImpl(30),gx.O.AV6AttributeIsMV,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6AttributeIsMV=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vATTRIBUTEISMV",row || gx.fn.currentGridRowImpl(30))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[46]={ id: 46, fld:"NEWMV",grid:30,evt:"e143j2_client"};
   GXValidFnc[47]={ id: 47, fld:"",grid:30};
   GXValidFnc[48]={ id: 48, fld:"VALUESTABLE",grid:30};
   GXValidFnc[51]={ id: 51, fld:"",grid:30};
   GXValidFnc[52]={ id: 52, fld:"",grid:30};
   GXValidFnc[53]={ id:53 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:30,gxgrid:this.GridattributesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vATTRIBUTEVALUE",fmt:0,gxz:"ZV9AttributeValue",gxold:"OV9AttributeValue",gxvar:"AV9AttributeValue",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV9AttributeValue=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9AttributeValue=Value},v2c:function(row){gx.fn.setGridControlValue("vATTRIBUTEVALUE",row || gx.fn.currentGridRowImpl(30),gx.O.AV9AttributeValue,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV9AttributeValue=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vATTRIBUTEVALUE",row || gx.fn.currentGridRowImpl(30))},nac:gx.falseFn};
   GXValidFnc[56]={ id: 56, fld:"TABLEMV",grid:30};
   GXValidFnc[59]={ id: 59, fld:"TABLEMVTITLE",grid:30};
   GXValidFnc[62]={ id: 62, fld:"TBATTRIBUTEVALUELIST", format:0,grid:30, ctrltype: "textblock"};
   GXValidFnc[64]={ id: 64, fld:"TABLECLEARMV",grid:30};
   GXValidFnc[67]={ id: 67, fld:"",grid:30};
   GXValidFnc[68]={ id:68 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:30,gxgrid:this.GridattributesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLEARMV",fmt:0,gxz:"ZV11ClearMV",gxold:"OV11ClearMV",gxvar:"AV11ClearMV",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11ClearMV=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11ClearMV=Value},v2c:function(row){gx.fn.setGridControlValue("vCLEARMV",row || gx.fn.currentGridRowImpl(30),gx.O.AV11ClearMV,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11ClearMV=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vCLEARMV",row || gx.fn.currentGridRowImpl(30))},nac:gx.falseFn,evt:"e183j2_client"};
   GXValidFnc[72]={ id:72 ,lvl:3,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:71,gxgrid:this.GridmvContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vATTRIBUTEMVID",fmt:0,gxz:"ZV7AttributeMVID",gxold:"OV7AttributeMVID",gxvar:"AV7AttributeMVID",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV7AttributeMVID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7AttributeMVID=Value},v2c:function(row){gx.fn.setGridControlValue("vATTRIBUTEMVID",row || gx.fn.currentGridRowImpl(71),gx.O.AV7AttributeMVID,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV7AttributeMVID=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vATTRIBUTEMVID",row || gx.fn.currentGridRowImpl(71))},nac:gx.falseFn};
   GXValidFnc[73]={ id:73 ,lvl:3,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:71,gxgrid:this.GridmvContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vATTRIBUTEMVVALUE",fmt:0,gxz:"ZV8AttributeMVValue",gxold:"OV8AttributeMVValue",gxvar:"AV8AttributeMVValue",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8AttributeMVValue=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8AttributeMVValue=Value},v2c:function(row){gx.fn.setGridControlValue("vATTRIBUTEMVVALUE",row || gx.fn.currentGridRowImpl(71),gx.O.AV8AttributeMVValue,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8AttributeMVValue=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vATTRIBUTEMVVALUE",row || gx.fn.currentGridRowImpl(71))},nac:gx.falseFn};
   GXValidFnc[74]={ id: 74, fld:"",grid:30};
   GXValidFnc[75]={ id: 75, fld:"",grid:30};
   GXValidFnc[76]={ id: 76, fld:"",grid:30};
   GXValidFnc[77]={ id:77 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:30,gxgrid:this.GridattributesContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDELETE",fmt:0,gxz:"ZV10Delete",gxold:"OV10Delete",gxvar:"AV10Delete",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV10Delete=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Delete=Value},v2c:function(row){gx.fn.setGridControlValue("vDELETE",row || gx.fn.currentGridRowImpl(30),gx.O.AV10Delete,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10Delete=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDELETE",row || gx.fn.currentGridRowImpl(30))},nac:gx.falseFn,evt:"e193j2_client"};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"GAM_FOOTERPOPUP",grid:0};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"GAM_FOOTERPOPUP_TABLEBUTTONS",grid:0};
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"GAM_FOOTERPOPUP_BTNCANCEL",grid:0,evt:"e123j2_client"};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"GAM_FOOTERPOPUP_BTNCONFIRM",grid:0,evt:"e133j2_client"};
   this.AV18Search = "" ;
   this.ZV18Search = "" ;
   this.OV18Search = "" ;
   this.ZV5AttributeID = "" ;
   this.OV5AttributeID = "" ;
   this.ZV6AttributeIsMV = false ;
   this.OV6AttributeIsMV = false ;
   this.ZV9AttributeValue = "" ;
   this.OV9AttributeValue = "" ;
   this.ZV11ClearMV = "" ;
   this.OV11ClearMV = "" ;
   this.ZV7AttributeMVID = "" ;
   this.OV7AttributeMVID = "" ;
   this.ZV8AttributeMVValue = "" ;
   this.OV8AttributeMVValue = "" ;
   this.ZV10Delete = "" ;
   this.OV10Delete = "" ;
   this.AV18Search = "" ;
   this.AV19Title = "" ;
   this.AV17GUID = "" ;
   this.AV5AttributeID = "" ;
   this.AV6AttributeIsMV = false ;
   this.AV9AttributeValue = "" ;
   this.AV11ClearMV = "" ;
   this.AV10Delete = "" ;
   this.AV7AttributeMVID = "" ;
   this.AV8AttributeMVValue = "" ;
   this.Gx_mode = "" ;
   this.Events = {"e113j2_client": ["'NEWROW'", true] ,"e143j2_client": ["'NEWROWMV'", true] ,"e123j2_client": ["'CANCEL'", true] ,"e133j2_client": ["'CONFIRM'", true] ,"e213j2_client": ["ENTER", true] ,"e223j2_client": ["CANCEL", true] ,"e203j2_client": ["VATTRIBUTEISMV.CONTROLVALUECHANGED", false] ,"e193j2_client": ["'DELETEROW'", false] ,"e183j2_client": ["'CLEARROWSMV'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDATTRIBUTES_nFirstRecordOnPage"},{"av":"GRIDATTRIBUTES_nEOF"},{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV"},{"av":"GRIDMV_nFirstRecordOnPage"},{"av":"GRIDMV_nEOF"},{"av":"AV17GUID","fld":"vGUID","hsh":true},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV19Title","fld":"vTITLE","hsh":true}],[]];
   this.EvtParms["GRIDATTRIBUTES.LOAD"] = [[{"av":"AV17GUID","fld":"vGUID","hsh":true},{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV"}],[{"av":"AV5AttributeID","fld":"vATTRIBUTEID"},{"av":"AV9AttributeValue","fld":"vATTRIBUTEVALUE"},{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV"},{"ctrl":"WCMESSAGES"},{"av":"AV10Delete","fld":"vDELETE"},{"av":"AV11ClearMV","fld":"vCLEARMV"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEID\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEID","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEISMV\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEISMV","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLEARMV\u0027,\u0027Visible\u0027)","ctrl":"vCLEARMV","prop":"Visible"},{"ctrl":"NEWMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLEMV\u0027,\u0027Visible\u0027)","ctrl":"TABLEMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Visible"}]];
   this.EvtParms["GRIDMV.LOAD"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true}],[{"av":"AV7AttributeMVID","fld":"vATTRIBUTEMVID"},{"av":"AV8AttributeMVValue","fld":"vATTRIBUTEMVVALUE"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVID\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEMVID","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVVALUE\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEMVVALUE","prop":"Enabled"}]];
   this.EvtParms["VATTRIBUTEISMV.CONTROLVALUECHANGED"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV"}],[{"av":"AV10Delete","fld":"vDELETE"},{"av":"AV11ClearMV","fld":"vCLEARMV"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEID\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEID","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEISMV\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEISMV","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLEARMV\u0027,\u0027Visible\u0027)","ctrl":"vCLEARMV","prop":"Visible"},{"ctrl":"NEWMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLEMV\u0027,\u0027Visible\u0027)","ctrl":"TABLEMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Visible"}]];
   this.EvtParms["'NEWROW'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV"}],[{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV"},{"av":"AV10Delete","fld":"vDELETE"},{"av":"AV11ClearMV","fld":"vCLEARMV"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEID\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEID","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEISMV\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEISMV","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLEARMV\u0027,\u0027Visible\u0027)","ctrl":"vCLEARMV","prop":"Visible"},{"ctrl":"NEWMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLEMV\u0027,\u0027Visible\u0027)","ctrl":"TABLEMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Visible"}]];
   this.EvtParms["'NEWROWMV'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!","hsh":true},{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV"}],[{"av":"AV10Delete","fld":"vDELETE"},{"av":"AV11ClearMV","fld":"vCLEARMV"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEID\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEID","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEISMV\u0027,\u0027Enabled\u0027)","ctrl":"vATTRIBUTEISMV","prop":"Enabled"},{"av":"gx.fn.getCtrlProperty(\u0027vCLEARMV\u0027,\u0027Visible\u0027)","ctrl":"vCLEARMV","prop":"Visible"},{"ctrl":"NEWMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027TABLEMV\u0027,\u0027Visible\u0027)","ctrl":"TABLEMV","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEVALUE","prop":"Visible"}]];
   this.EvtParms["'DELETEROW'"] = [[],[{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEID\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEID","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vDELETE\u0027,\u0027Visible\u0027)","ctrl":"vDELETE","prop":"Visible"},{"av":"AV5AttributeID","fld":"vATTRIBUTEID"},{"av":"AV10Delete","fld":"vDELETE"},{"av":"gx.fn.getCtrlProperty(\u0027MVTABLE\u0027,\u0027Visible\u0027)","ctrl":"MVTABLE","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027VALUESTABLE\u0027,\u0027Visible\u0027)","ctrl":"VALUESTABLE","prop":"Visible"}]];
   this.EvtParms["'CLEARROWSMV'"] = [[],[{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVID\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEMVID","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vATTRIBUTEMVVALUE\u0027,\u0027Visible\u0027)","ctrl":"vATTRIBUTEMVVALUE","prop":"Visible"},{"av":"AV7AttributeMVID","fld":"vATTRIBUTEMVID"},{"av":"AV8AttributeMVValue","fld":"vATTRIBUTEMVVALUE"}]];
   this.EvtParms["'CANCEL'"] = [[],[]];
   this.EvtParms["'CONFIRM'"] = [[{"av":"AV17GUID","fld":"vGUID","hsh":true},{"av":"AV5AttributeID","fld":"vATTRIBUTEID","grid":30},{"av":"GRIDATTRIBUTES_nFirstRecordOnPage"},{"av":"nRC_GXsfl_30","ctrl":"GRIDATTRIBUTES","grid":30,"prop":"GridRC","grid":30},{"av":"AV6AttributeIsMV","fld":"vATTRIBUTEISMV","grid":30},{"av":"AV7AttributeMVID","fld":"vATTRIBUTEMVID","grid":71},{"av":"GRIDMV_nFirstRecordOnPage"},{"av":"nRC_GXsfl_71","ctrl":"GRIDMV","grid":71,"prop":"GridRC","grid":71},{"av":"AV8AttributeMVValue","fld":"vATTRIBUTEMVVALUE","grid":71},{"av":"AV9AttributeValue","fld":"vATTRIBUTEVALUE","grid":30}],[{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV17GUID", "vGUID", 0, "svchar", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV19Title", "vTITLE", 0, "svchar", 40, 0);
   this.setVCMap("AV17GUID", "vGUID", 0, "svchar", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV17GUID", "vGUID", 0, "svchar", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   GridmvContainer.addRefreshingVar({rfrVar:"Gx_mode"});
   GridmvContainer.addRefreshingVar({rfrVar:"AV17GUID"});
   GridmvContainer.addRefreshingVar({rfrVar:"AV19Title"});
   GridmvContainer.addRefreshingParm({rfrVar:"Gx_mode"});
   GridmvContainer.addRefreshingParm({rfrVar:"AV17GUID"});
   GridmvContainer.addRefreshingParm({rfrVar:"AV19Title"});
   GridattributesContainer.addRefreshingVar({rfrVar:"AV17GUID"});
   GridattributesContainer.addRefreshingVar({rfrVar:"Gx_mode"});
   GridattributesContainer.addRefreshingVar({rfrVar:"AV6AttributeIsMV", rfrProp:"Value", gxAttId:"Attributeismv"});
   GridattributesContainer.addRefreshingVar({rfrVar:"AV19Title"});
   GridattributesContainer.addRefreshingParm({rfrVar:"AV17GUID"});
   GridattributesContainer.addRefreshingParm({rfrVar:"Gx_mode"});
   GridattributesContainer.addRefreshingParm({rfrVar:"AV6AttributeIsMV", rfrProp:"Value", gxAttId:"Attributeismv"});
   GridattributesContainer.addRefreshingParm({rfrVar:"AV19Title"});
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0080" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_usercustomattributes);});
