/*
               File: GAM_UserHeader
        Description: GAM_UserHeader
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:31:20.29
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_userheader', true, function (CmpContext) {
   this.ServerClass =  "gam_userheader" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_userheader.aspx" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV16UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV14PanelId=gx.fn.getControlValue("vPANELID") ;
   };
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'LOADBUTTONSTOOLBAR' Routine */
         this.AV7ActionGroupItem =  {Id:"",Caption:"",Link:"",EventName:"",Class:"",TooltipText:"",Children:[]}  ;
         if ( gx.text.compare( this.AV9BtnToolbar , "EditUser" ) == 0 )
         {
            this.AV7ActionGroupItem.Id =  "EditUser"  ;
            this.AV7ActionGroupItem.Class =  gx.text.format( "%1 %2 %3", "action-group-option", "Button", "button-primary", "", "", "", "", "", "")  ;
            this.AV7ActionGroupItem.EventName =  "Edit"  ;
            this.AV7ActionGroupItem.Caption =  gx.getMessage( "GAM_Edituser")  ;
            this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "GAM_Edituserinformation")  ;
         }
         else if ( gx.text.compare( this.AV9BtnToolbar , "UndeleteUser" ) == 0 )
         {
            this.AV7ActionGroupItem.Id =  "UndeleteUser"  ;
            this.AV7ActionGroupItem.Class =  gx.text.format( "%1", "action-group-option", "", "", "", "", "", "", "", "")  ;
            this.AV7ActionGroupItem.EventName =  "Undelete"  ;
            this.AV7ActionGroupItem.Caption =  gx.getMessage( "GAM_Undeleteuser")  ;
            this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "GAM_Undeletetheuser")  ;
         }
         else if ( gx.text.compare( this.AV9BtnToolbar , "DeletePhysically" ) == 0 )
         {
            this.AV7ActionGroupItem.Id =  "DeletePhysically"  ;
            this.AV7ActionGroupItem.Class =  gx.text.format( "%1 %2 %3", "action-group-option", "Button", "button-primary", "", "", "", "", "", "")  ;
            this.AV7ActionGroupItem.EventName =  "DeletePhysically"  ;
            this.AV7ActionGroupItem.Caption =  gx.getMessage( "GAM_Deletepermanently")  ;
            this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "GAM_Permanentlydeletetheuser")  ;
         }
         else if ( gx.text.compare( this.AV9BtnToolbar , "EditRoles" ) == 0 )
         {
            this.AV7ActionGroupItem.Id =  "EditRoles"  ;
            this.AV7ActionGroupItem.Class =  gx.text.format( "%1 %2 %3", "action-group-option", "Button", "button-tertiary", "", "", "", "", "", "")  ;
            this.AV7ActionGroupItem.EventName =  "Roles"  ;
            this.AV7ActionGroupItem.Caption =  gx.getMessage( "GAM_Editroles")  ;
            this.AV7ActionGroupItem.TooltipText =  gx.getMessage( "GAM_Edituserroles")  ;
         }
      }, arguments);
   };
   this.e15351_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Delete' Routine */
         this.clearMessages();
         this.call("gam_userentry.aspx", ["DLT", this.AV16UserGUID], null, ["Mode","UserGUID"]);
         this.refreshOutputs([{"av":"AV16UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e24352_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Undelete' Routine */
         this.clearMessages();
         this.AV17Window.Url =  gx.http.formatLink("gam_warningnotification.aspx",["user:undelete", this.AV16UserGUID, ""])  ;
         this.AV17Window.ReturnParms =  []  ;
         this.popupOpen(this.AV17Window) ;
         this.call("gam_userentry.aspx", ["DSP", this.AV16UserGUID], null, ["Mode","UserGUID"]);
         this.refreshOutputs([{"av":"AV16UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e25352_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'DeletePhysically' Routine */
         this.clearMessages();
         this.AV17Window.Url =  gx.http.formatLink("gam_warningnotification.aspx",["user:physicaldelete", this.AV16UserGUID, ""])  ;
         this.AV17Window.ReturnParms =  []  ;
         this.popupOpen(this.AV17Window) ;
         this.call("gam_wwusers.aspx", [], null, []);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e26352_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Roles' Routine */
         this.clearMessages();
         this.call("gam_wwuserroles.aspx", [this.AV16UserGUID], null, ["UserGUID"]);
         this.refreshOutputs([{"av":"AV16UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e27352_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Edit' Routine */
         this.clearMessages();
         this.call("gam_userentry.aspx", ["UPD", this.AV16UserGUID], null, ["Mode","UserGUID"]);
         this.refreshOutputs([{"av":"AV16UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e13351_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Change Password' Routine */
         this.clearMessages();
         this.call("gam_setpassword.aspx", [this.AV16UserGUID], null, ["UserGUID"]);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e14351_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ApplicationAPIkeys' Routine */
         this.clearMessages();
         this.call("gam_wwuserapplications.aspx", [this.AV16UserGUID], null, ["UserGUID"]);
         this.refreshOutputs([{"av":"AV16UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e11351_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UserPermissions' Routine */
         this.clearMessages();
         this.call("gam_wwuserpermissions.aspx", [this.AV16UserGUID, 0], null, ["UserGUID","pApplicationId"]);
         this.refreshOutputs([{"av":"AV16UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e12351_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UserAttributes' Routine */
         this.clearMessages();
         this.AV17Window.Url =  gx.http.formatLink("gam_usercustomattributes.aspx",[this.Gx_mode, gx.getMessage( "GAM_CustomAttributes"), this.AV16UserGUID])  ;
         this.AV17Window.ReturnParms =  []  ;
         this.popupOpen(this.AV17Window) ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e28351_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Gam_headerentry_tableback_Click Routine */
         this.clearMessages();
         this.s132_client();
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.s132_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'GOBACK' Routine */
         if ( gx.text.compare( this.AV14PanelId , "user:entry" ) == 0 || gx.text.compare( this.AV14PanelId , "user:chgpwd" ) == 0 || gx.text.compare( this.AV14PanelId , "totp" ) == 0 || gx.text.compare( this.AV14PanelId , "user:deleted" ) == 0 )
         {
            this.call("gam_wwusers.aspx", [], null, []);
         }
      }, arguments);
   };
   this.e17352_client=function()
   {
      /* 'EnableDisableInRepository' Routine */
      return this.executeServerEvent("'ENABLEDISABLEINREPOSITORY'", true, null, false, false);
   };
   this.e18352_client=function()
   {
      /* 'KillSessions' Routine */
      return this.executeServerEvent("'KILLSESSIONS'", true, null, false, false);
   };
   this.e19352_client=function()
   {
      /* 'SendActivationEmail' Routine */
      return this.executeServerEvent("'SENDACTIVATIONEMAIL'", true, null, false, false);
   };
   this.e20352_client=function()
   {
      /* 'UnblockOTPCodes' Routine */
      return this.executeServerEvent("'UNBLOCKOTPCODES'", true, null, false, false);
   };
   this.e21352_client=function()
   {
      /* 'AuthenticatorApp' Routine */
      return this.executeServerEvent("'AUTHENTICATORAPP'", true, null, false, false);
   };
   this.e22352_client=function()
   {
      /* 'BlockOrUnblockUser' Routine */
      return this.executeServerEvent("'BLOCKORUNBLOCKUSER'", true, null, false, false);
   };
   this.e29352_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e30352_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49];
   this.GXLastCtrlId =49;
   this.BUTTONSTOOLBARContainer = gx.uc.getNew(this, 30, 0, "gx.ui.controls.actionGroup.dynamicItems", this.CmpContext + "BUTTONSTOOLBARContainer", "Buttonstoolbar", "BUTTONSTOOLBAR");
   var BUTTONSTOOLBARContainer = this.BUTTONSTOOLBARContainer;
   BUTTONSTOOLBARContainer.setProp("Class", "Class", "", "char");
   BUTTONSTOOLBARContainer.setProp("Enabled", "Enabled", true, "boolean");
   BUTTONSTOOLBARContainer.addV2CFunction('AV8ActionGroupItemCollection', "vACTIONGROUPITEMCOLLECTION", 'setItems');
   BUTTONSTOOLBARContainer.addC2VFunction(function(UC) { UC.ParentObject.AV8ActionGroupItemCollection=UC.getItems();gx.fn.setControlValue("vACTIONGROUPITEMCOLLECTION",UC.ParentObject.AV8ActionGroupItemCollection); });
   BUTTONSTOOLBARContainer.setProp("ItemPressed", "Itempressed", '', "str");
   BUTTONSTOOLBARContainer.setProp("Visible", "Visible", true, "bool");
   BUTTONSTOOLBARContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(BUTTONSTOOLBARContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"HEADERENTRY",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERENTRY",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERENTRY_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERENTRY_TABLEBACK",grid:0,evt:"e28351_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERENTRY_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERENTRY_TABLETITLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERENTRY_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERENTRY_TXTSTATUS", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"GAM_HEADERENTRY_TBLTOOLBARS",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"GAM_HEADERENTRY_BUTTONSTOOLBAR_INNER",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"GAM_HEADERENTRY_MENUTABLE",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[37]={ id: 37, fld:"GAM_HEADERENTRY_MENUTOOLBAR_INNER",grid:0};
   GXValidFnc[38]={ id: 38, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[39]={ id: 39, fld:"BTNPERMISSIONS", format:0,grid:0,evt:"e11351_client", ctrltype: "textblock"};
   GXValidFnc[40]={ id: 40, fld:"BTNATTRIBUTES", format:0,grid:0,evt:"e12351_client", ctrltype: "textblock"};
   GXValidFnc[41]={ id: 41, fld:"BTNSENDACTIVATIONEMAIL", format:0,grid:0,evt:"e19352_client", ctrltype: "textblock"};
   GXValidFnc[42]={ id: 42, fld:"BTNCHANGEPASSWORD", format:0,grid:0,evt:"e13351_client", ctrltype: "textblock"};
   GXValidFnc[43]={ id: 43, fld:"BTNAPIKEYS", format:0,grid:0,evt:"e14351_client", ctrltype: "textblock"};
   GXValidFnc[44]={ id: 44, fld:"BTNTOTPAUTHENTICATOR", format:0,grid:0,evt:"e21352_client", ctrltype: "textblock"};
   GXValidFnc[45]={ id: 45, fld:"BTNUNBLOCKOTPCODES", format:0,grid:0,evt:"e20352_client", ctrltype: "textblock"};
   GXValidFnc[46]={ id: 46, fld:"BTNUNBLOCKUSER", format:0,grid:0,evt:"e22352_client", ctrltype: "textblock"};
   GXValidFnc[47]={ id: 47, fld:"BTNKILLSESSIONS", format:0,grid:0,evt:"e18352_client", ctrltype: "textblock"};
   GXValidFnc[48]={ id: 48, fld:"BTNENABLEINREPO", format:0,grid:0,evt:"e17352_client", ctrltype: "textblock"};
   GXValidFnc[49]={ id: 49, fld:"BTNDELETEUSER", format:0,grid:0,evt:"e15351_client", ctrltype: "textblock"};
   this.AV8ActionGroupItemCollection = [ ] ;
   this.AV14PanelId = "" ;
   this.AV16UserGUID = "" ;
   this.Gx_mode = "" ;
   this.AV7ActionGroupItem = {Id:"",Caption:"",Link:"",EventName:"",Class:"",TooltipText:"",Children:[]} ;
   this.AV9BtnToolbar = "" ;
   this.AV17Window = {} ;
   this.Events = {"e17352_client": ["'ENABLEDISABLEINREPOSITORY'", true] ,"e18352_client": ["'KILLSESSIONS'", true] ,"e19352_client": ["'SENDACTIVATIONEMAIL'", true] ,"e20352_client": ["'UNBLOCKOTPCODES'", true] ,"e21352_client": ["'AUTHENTICATORAPP'", true] ,"e22352_client": ["'BLOCKORUNBLOCKUSER'", true] ,"e29352_client": ["ENTER", true] ,"e30352_client": ["CANCEL", true] ,"e15351_client": ["'DELETE'", false] ,"e24352_client": ["'UNDELETE'", false] ,"e25352_client": ["'DELETEPHYSICALLY'", false] ,"e26352_client": ["'ROLES'", false] ,"e27352_client": ["'EDIT'", false] ,"e13351_client": ["'CHANGE PASSWORD'", false] ,"e14351_client": ["'APPLICATIONAPIKEYS'", false] ,"e11351_client": ["'USERPERMISSIONS'", false] ,"e12351_client": ["'USERATTRIBUTES'", false] ,"e28351_client": ["GAM_HEADERENTRY_TABLEBACK.CLICK", false]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["'ENABLEDISABLEINREPOSITORY'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'KILLSESSIONS'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'DELETE'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'UNDELETE'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'DELETEPHYSICALLY'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[]];
   this.EvtParms["'ROLES'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'EDIT'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'CHANGE PASSWORD'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[]];
   this.EvtParms["'APPLICATIONAPIKEYS'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'USERPERMISSIONS'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'USERATTRIBUTES'"] = [[{"av":"Gx_mode","fld":"vMODE","pic":"@!"},{"av":"AV16UserGUID","fld":"vUSERGUID"}],[]];
   this.EvtParms["'SENDACTIVATIONEMAIL'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'UNBLOCKOTPCODES'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'AUTHENTICATORAPP'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'BLOCKORUNBLOCKUSER'"] = [[{"av":"AV16UserGUID","fld":"vUSERGUID"}],[{"av":"gx.fn.getCtrlProperty(\u0027BTNUNBLOCKUSER\u0027,\u0027Caption\u0027)","ctrl":"BTNUNBLOCKUSER","prop":"Caption"},{"av":"AV16UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["GAM_HEADERENTRY_TABLEBACK.CLICK"] = [[{"av":"AV14PanelId","fld":"vPANELID"}],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV16UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV14PanelId", "vPANELID", 0, "svchar", 40, 0);
   this.setVCMap("AV14PanelId", "vPANELID", 0, "svchar", 40, 0);
   this.setVCMap("AV16UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV16UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.Initialize( );
});
