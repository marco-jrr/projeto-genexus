/*
               File: GAM_WWAuthTypes
        Description: GAM_Authenticationtypes
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:32:6.36
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwauthtypes', false, function () {
   this.ServerClass =  "gam_wwauthtypes" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwauthtypes.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV16CurrentPage=gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator) ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Typeid=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(42);
      return this.validCliEvt("Validv_Typeid", 42, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vTYPEID");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV13TypeId , "APIkey" ) == 0 || gx.text.compare( this.AV13TypeId , "AppleID" ) == 0 || gx.text.compare( this.AV13TypeId , "Custom" ) == 0 || gx.text.compare( this.AV13TypeId , "ExternalWebService" ) == 0 || gx.text.compare( this.AV13TypeId , "Facebook" ) == 0 || gx.text.compare( this.AV13TypeId , "GAMLocal" ) == 0 || gx.text.compare( this.AV13TypeId , "GAMRemote" ) == 0 || gx.text.compare( this.AV13TypeId , "GAMRemoteRest" ) == 0 || gx.text.compare( this.AV13TypeId , "Google" ) == 0 || gx.text.compare( this.AV13TypeId , "Oauth20" ) == 0 || gx.text.compare( this.AV13TypeId , "OTP" ) == 0 || gx.text.compare( this.AV13TypeId , "Saml20" ) == 0 || gx.text.compare( this.AV13TypeId , "Twitter" ) == 0 || gx.text.compare( this.AV13TypeId , "WeChat" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Type Id"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Filauthtypetype=function()
   {
      return this.validCliEvt("Validv_Filauthtypetype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vFILAUTHTYPETYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV17FilAuthTypeType , "APIkey" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "AppleID" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "Custom" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "ExternalWebService" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "Facebook" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "GAMLocal" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "GAMRemote" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "GAMRemoteRest" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "Google" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "Oauth20" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "OTP" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "Saml20" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "Twitter" ) == 0 || gx.text.compare( this.AV17FilAuthTypeType , "WeChat" ) == 0 || (gx.text.compare('',this.AV17FilAuthTypeType)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Filisenable=function()
   {
      return this.validCliEvt("Validv_Filisenable", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vFILISENABLE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV18FilIsEnable , "A" ) == 0 || gx.text.compare( this.AV18FilIsEnable , "T" ) == 0 || gx.text.compare( this.AV18FilIsEnable , "F" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Enabled?"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e330e1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Search_Controlvaluechanged Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e110e1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Hide' Routine */
         this.clearMessages();
         if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
            gx.fn.setCtrlProperty("GAM_ACTIONSSTENCIL_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
         }
         else
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
            gx.fn.setCtrlProperty("GAM_ACTIONSSTENCIL_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_ACTIONSSTENCIL_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_ACTIONSSTENCIL_TOGGLEFILTERS","prop":"Tooltiptext"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e120e1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearFilters' Routine */
         this.clearMessages();
         this.AV17FilAuthTypeType =  ''  ;
         this.AV18FilIsEnable =  "A"  ;
         this.AV16CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e130e1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Apply' Routine */
         this.clearMessages();
         this.AV16CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e320e2_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Btntestws_Click Routine */
         this.clearMessages();
         this.AV15Window.Url =  gx.http.formatLink("gam_testexternallogin.aspx",[this.AV12Name, this.AV13TypeId])  ;
         this.AV15Window.ReturnParms =  ["AV12Name", "AV13TypeId"]  ;
         this.popupOpen(this.AV15Window) ;
         this.refreshOutputs([{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"},{"av":"AV12Name","fld":"vNAME"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e140e2_client=function()
   {
      /* 'Add APIkey' Routine */
      return this.executeServerEvent("'ADD APIKEY'", true, null, false, false);
   };
   this.e150e2_client=function()
   {
      /* 'Add Apple' Routine */
      return this.executeServerEvent("'ADD APPLE'", true, null, false, false);
   };
   this.e160e2_client=function()
   {
      /* 'Add Custom' Routine */
      return this.executeServerEvent("'ADD CUSTOM'", true, null, false, false);
   };
   this.e170e2_client=function()
   {
      /* 'Add External Web Service' Routine */
      return this.executeServerEvent("'ADD EXTERNAL WEB SERVICE'", true, null, false, false);
   };
   this.e180e2_client=function()
   {
      /* 'Add Facebook' Routine */
      return this.executeServerEvent("'ADD FACEBOOK'", true, null, false, false);
   };
   this.e190e2_client=function()
   {
      /* 'Add GAM Remote' Routine */
      return this.executeServerEvent("'ADD GAM REMOTE'", true, null, false, false);
   };
   this.e200e2_client=function()
   {
      /* 'Add GAM Remote REST' Routine */
      return this.executeServerEvent("'ADD GAM REMOTE REST'", true, null, false, false);
   };
   this.e210e2_client=function()
   {
      /* 'Add Google' Routine */
      return this.executeServerEvent("'ADD GOOGLE'", true, null, false, false);
   };
   this.e220e2_client=function()
   {
      /* 'Add OAuth20' Routine */
      return this.executeServerEvent("'ADD OAUTH20'", true, null, false, false);
   };
   this.e230e2_client=function()
   {
      /* 'Add OTP' Routine */
      return this.executeServerEvent("'ADD OTP'", true, null, false, false);
   };
   this.e240e2_client=function()
   {
      /* 'Add SAML' Routine */
      return this.executeServerEvent("'ADD SAML'", true, null, false, false);
   };
   this.e250e2_client=function()
   {
      /* 'Add Twitter' Routine */
      return this.executeServerEvent("'ADD TWITTER'", true, null, false, false);
   };
   this.e260e2_client=function()
   {
      /* 'Add WeChat' Routine */
      return this.executeServerEvent("'ADD WECHAT'", true, null, false, false);
   };
   this.e290e2_client=function()
   {
      /* Name_Click Routine */
      return this.executeServerEvent("VNAME.CLICK", true, arguments[0], false, false);
   };
   this.e300e2_client=function()
   {
      /* Btnupd_Click Routine */
      return this.executeServerEvent("VBTNUPD.CLICK", true, arguments[0], false, false);
   };
   this.e310e2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e340e2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e350e2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69];
   this.GXLastCtrlId =69;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",42,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwauthtypes",[],false,1,true,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",43,"vNAME",gx.getMessage( "GAM_Name"),"","Name","char",0,"px",60,60,"start","e290e2_client",[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addComboBox("Typeid",44,"vTYPEID",gx.getMessage( "GAM_AuthenticationType"),"TypeId","char",null,0,true,false,150,"px","column column-optional");
   GridwwContainer.addSingleLineEdit("Btntestws",45,"vBTNTESTWS","","","BtnTestWS","char",0,"px",20,20,"start","e320e2_client",[],"Btntestws","BtnTestWS",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btnupd",46,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"start","e300e2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btndlt",47,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e310e2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADER",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TABLE3",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"TEXTBLOCK1", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"GAM_ADD_INNER",grid:0};
   GXValidFnc[17]={ id: 17, fld:"", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[18]={ id: 18, fld:"OPTIONAPIKEY", format:0,grid:0,evt:"e140e2_client", ctrltype: "textblock"};
   GXValidFnc[19]={ id: 19, fld:"OPTIONAPPLE", format:0,grid:0,evt:"e150e2_client", ctrltype: "textblock"};
   GXValidFnc[20]={ id: 20, fld:"OPTION", format:0,grid:0,evt:"e160e2_client", ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"OPTIONEXTERNALWS", format:0,grid:0,evt:"e170e2_client", ctrltype: "textblock"};
   GXValidFnc[22]={ id: 22, fld:"OPTIONFACEBOOK", format:0,grid:0,evt:"e180e2_client", ctrltype: "textblock"};
   GXValidFnc[23]={ id: 23, fld:"OPTIONGAMREMOTE", format:0,grid:0,evt:"e190e2_client", ctrltype: "textblock"};
   GXValidFnc[24]={ id: 24, fld:"OPTIONGAMREMOTEREST", format:0,grid:0,evt:"e200e2_client", ctrltype: "textblock"};
   GXValidFnc[25]={ id: 25, fld:"OPTIONGOOGLE", format:0,grid:0,evt:"e210e2_client", ctrltype: "textblock"};
   GXValidFnc[26]={ id: 26, fld:"OPTIONOAUTH", format:0,grid:0,evt:"e220e2_client", ctrltype: "textblock"};
   GXValidFnc[27]={ id: 27, fld:"OPTIONOTP", format:0,grid:0,evt:"e230e2_client", ctrltype: "textblock"};
   GXValidFnc[28]={ id: 28, fld:"OPTIONSAML", format:0,grid:0,evt:"e240e2_client", ctrltype: "textblock"};
   GXValidFnc[29]={ id: 29, fld:"OPTIONTWITTER", format:0,grid:0,evt:"e250e2_client", ctrltype: "textblock"};
   GXValidFnc[30]={ id: 30, fld:"OPTIONWECHAT", format:0,grid:0,evt:"e260e2_client", ctrltype: "textblock"};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id:33 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e330e1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV14Search",gxold:"OV14Search",gxvar:"AV14Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV14Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 33 , function() {
   });
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"GAM_ACTIONSSTENCIL_TOGGLEFILTERS",grid:0,evt:"e110e1_client"};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"SECTION1",grid:0};
   GXValidFnc[39]={ id: 39, fld:"GRIDCONTAINER",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[43]={ id:43 ,lvl:2,type:"char",len:60,dec:0,sign:false,ro:0,isacc:0,grid:42,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV12Name",gxold:"OV12Name",gxvar:"AV12Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(42),gx.O.AV12Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(42))},nac:gx.falseFn,evt:"e290e2_client"};
   GXValidFnc[44]={ id:44 ,lvl:2,type:"char",len:30,dec:0,sign:false,ro:0,isacc:0,grid:42,gxgrid:this.GridwwContainer,fnc:this.Validv_Typeid,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTYPEID",fmt:0,gxz:"ZV13TypeId",gxold:"OV13TypeId",gxvar:"AV13TypeId",ucs:[],op:[44],ip:[44],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV13TypeId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13TypeId=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vTYPEID",row || gx.fn.currentGridRowImpl(42),gx.O.AV13TypeId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV13TypeId=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vTYPEID",row || gx.fn.currentGridRowImpl(42))},nac:gx.falseFn};
   GXValidFnc[45]={ id:45 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:42,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNTESTWS",fmt:0,gxz:"ZV7BtnTestWS",gxold:"OV7BtnTestWS",gxvar:"AV7BtnTestWS",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV7BtnTestWS=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7BtnTestWS=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNTESTWS",row || gx.fn.currentGridRowImpl(42),gx.O.AV7BtnTestWS,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV7BtnTestWS=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNTESTWS",row || gx.fn.currentGridRowImpl(42))},nac:gx.falseFn,evt:"e320e2_client"};
   GXValidFnc[46]={ id:46 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:42,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV8BtnUpd",gxold:"OV8BtnUpd",gxvar:"AV8BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(42),gx.O.AV8BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(42))},nac:gx.falseFn,evt:"e300e2_client"};
   GXValidFnc[47]={ id:47 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:42,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV6BtnDlt",gxold:"OV6BtnDlt",gxvar:"AV6BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(42),gx.O.AV6BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(42))},nac:gx.falseFn,evt:"e310e2_client"};
   GXValidFnc[48]={ id: 48, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e110e1_client"};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id:59 ,lvl:0,type:"char",len:30,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Filauthtypetype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILAUTHTYPETYPE",fmt:0,gxz:"ZV17FilAuthTypeType",gxold:"OV17FilAuthTypeType",gxvar:"AV17FilAuthTypeType",ucs:[],op:[59],ip:[59],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV17FilAuthTypeType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17FilAuthTypeType=Value},v2c:function(){gx.fn.setComboBoxValue("vFILAUTHTYPETYPE",gx.O.AV17FilAuthTypeType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17FilAuthTypeType=this.val()},val:function(){return gx.fn.getControlValue("vFILAUTHTYPETYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 59 , function() {
   });
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id:64 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Filisenable,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILISENABLE",fmt:0,gxz:"ZV18FilIsEnable",gxold:"OV18FilIsEnable",gxvar:"AV18FilIsEnable",ucs:[],op:[64],ip:[64],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV18FilIsEnable=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18FilIsEnable=Value},v2c:function(){gx.fn.setComboBoxValue("vFILISENABLE",gx.O.AV18FilIsEnable);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18FilIsEnable=this.val()},val:function(){return gx.fn.getControlValue("vFILISENABLE")},nac:gx.falseFn};
   this.declareDomainHdlr( 64 , function() {
   });
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e120e1_client"};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e130e1_client"};
   this.AV14Search = "" ;
   this.ZV14Search = "" ;
   this.OV14Search = "" ;
   this.ZV12Name = "" ;
   this.OV12Name = "" ;
   this.ZV13TypeId = "" ;
   this.OV13TypeId = "" ;
   this.ZV7BtnTestWS = "" ;
   this.OV7BtnTestWS = "" ;
   this.ZV8BtnUpd = "" ;
   this.OV8BtnUpd = "" ;
   this.ZV6BtnDlt = "" ;
   this.OV6BtnDlt = "" ;
   this.AV17FilAuthTypeType = "" ;
   this.ZV17FilAuthTypeType = "" ;
   this.OV17FilAuthTypeType = "" ;
   this.AV18FilIsEnable = "" ;
   this.ZV18FilIsEnable = "" ;
   this.OV18FilIsEnable = "" ;
   this.AV14Search = "" ;
   this.AV17FilAuthTypeType = "" ;
   this.AV18FilIsEnable = "" ;
   this.AV12Name = "" ;
   this.AV13TypeId = "" ;
   this.AV7BtnTestWS = "" ;
   this.AV8BtnUpd = "" ;
   this.AV6BtnDlt = "" ;
   this.AV16CurrentPage = 0 ;
   this.AV15Window = {} ;
   this.Events = {"e140e2_client": ["'ADD APIKEY'", true] ,"e150e2_client": ["'ADD APPLE'", true] ,"e160e2_client": ["'ADD CUSTOM'", true] ,"e170e2_client": ["'ADD EXTERNAL WEB SERVICE'", true] ,"e180e2_client": ["'ADD FACEBOOK'", true] ,"e190e2_client": ["'ADD GAM REMOTE'", true] ,"e200e2_client": ["'ADD GAM REMOTE REST'", true] ,"e210e2_client": ["'ADD GOOGLE'", true] ,"e220e2_client": ["'ADD OAUTH20'", true] ,"e230e2_client": ["'ADD OTP'", true] ,"e240e2_client": ["'ADD SAML'", true] ,"e250e2_client": ["'ADD TWITTER'", true] ,"e260e2_client": ["'ADD WECHAT'", true] ,"e290e2_client": ["VNAME.CLICK", true] ,"e300e2_client": ["VBTNUPD.CLICK", true] ,"e310e2_client": ["VBTNDLT.CLICK", true] ,"e340e2_client": ["ENTER", true] ,"e350e2_client": ["CANCEL", true] ,"e330e1_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e110e1_client": ["'HIDE'", false] ,"e120e1_client": ["'CLEARFILTERS'", false] ,"e130e1_client": ["'APPLY'", false] ,"e320e2_client": ["VBTNTESTWS.CLICK", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[{"av":"AV8BtnUpd","fld":"vBTNUPD"},{"av":"AV6BtnDlt","fld":"vBTNDLT"},{"av":"AV7BtnTestWS","fld":"vBTNTESTWS"},{"av":"AV12Name","fld":"vNAME"},{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNTESTWS\u0027,\u0027Visible\u0027)","ctrl":"vBTNTESTWS","prop":"Visible"}]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'HIDE'"] = [[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_ACTIONSSTENCIL_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_ACTIONSSTENCIL_TOGGLEFILTERS","prop":"Tooltiptext"}]];
   this.EvtParms["'CLEARFILTERS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}]];
   this.EvtParms["'APPLY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD APIKEY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD APPLE'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD CUSTOM'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD EXTERNAL WEB SERVICE'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD FACEBOOK'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD GAM REMOTE'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD GAM REMOTE REST'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD GOOGLE'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD OAUTH20'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD OTP'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD SAML'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD TWITTER'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["'ADD WECHAT'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["VNAME.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"},{"av":"AV12Name","fld":"vNAME"},{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"}],[{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"},{"av":"AV12Name","fld":"vNAME"}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"},{"av":"AV12Name","fld":"vNAME"},{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"}],[{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"},{"av":"AV12Name","fld":"vNAME"}]];
   this.EvtParms["VBTNTESTWS.CLICK"] = [[{"av":"AV12Name","fld":"vNAME"},{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"}],[{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"},{"av":"AV12Name","fld":"vNAME"}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"},{"av":"AV12Name","fld":"vNAME"},{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"}],[{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"},{"av":"AV12Name","fld":"vNAME"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV14Search","fld":"vSEARCH"},{"ctrl":"vFILAUTHTYPETYPE"},{"av":"AV17FilAuthTypeType","fld":"vFILAUTHTYPETYPE"},{"ctrl":"vFILISENABLE"},{"av":"AV18FilIsEnable","fld":"vFILISENABLE"},{"av":"subGridww_Recordcount"}],[]];
   this.EvtParms["VALIDV_FILAUTHTYPETYPE"] = [[],[]];
   this.EvtParms["VALIDV_FILISENABLE"] = [[],[]];
   this.EvtParms["VALIDV_TYPEID"] = [[{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"}],[{"ctrl":"vTYPEID"},{"av":"AV13TypeId","fld":"vTYPEID"}]];
   this.setVCMap("AV16CurrentPage", "vCURRENTPAGE", 0, "int", 4, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[33]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[59]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[64]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[33]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[59]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[64]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(this.gam_wwauthtypes);});
