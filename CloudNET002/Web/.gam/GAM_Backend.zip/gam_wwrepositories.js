/*
               File: GAM_WWRepositories
        Description: GAM_Repositories
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:31:54.95
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwrepositories', false, function () {
   this.ServerClass =  "gam_wwrepositories" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwrepositories.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.e160c1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Search_Controlvaluechanged Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e110c2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e130c2_client=function()
   {
      /* Btnupd_Click Routine */
      return this.executeServerEvent("VBTNUPD.CLICK", true, arguments[0], false, false);
   };
   this.e140c2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e150c2_client=function()
   {
      /* Btnconnect_Click Routine */
      return this.executeServerEvent("VBTNCONNECT.CLICK", true, arguments[0], false, false);
   };
   this.e170c2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e180c2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,25,26,27,28,29,30];
   this.GXLastCtrlId =30;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",22,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwrepositories",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Id",23,"vID",gx.getMessage( "GAM_ID"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"WWActionColumn");
   GridwwContainer.addSingleLineEdit("Name",24,"vNAME",gx.getMessage( "GAM_Name"),"","Name","char",0,"px",254,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Guid",25,"vGUID","","","GUID","char",0,"px",254,80,"start",null,[],"Guid","GUID",false,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Btnconnect",26,"vBTNCONNECT","","","BtnConnect","char",0,"px",20,20,"start","e150c2_client",[],"Btnconnect","BtnConnect",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btnupd",27,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"start","e130c2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btndlt",28,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e140c2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWNOFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWNOFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWWNOFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWWNOFILTERS_ADDNEW",grid:0,evt:"e110c2_client"};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e160c1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV16Search",gxold:"OV16Search",gxvar:"AV16Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV16Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"GRIDCONTAINER",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[23]={ id:23 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV11Id",gxold:"OV11Id",gxvar:"AV11Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV11Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(22),gx.O.AV11Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(22),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV13Name",gxold:"OV13Name",gxvar:"AV13Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV13Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(22),gx.O.AV13Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV13Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV19GUID",gxold:"OV19GUID",gxvar:"AV19GUID",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV19GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19GUID=Value},v2c:function(row){gx.fn.setGridControlValue("vGUID",row || gx.fn.currentGridRowImpl(22),gx.O.AV19GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV19GUID=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vGUID",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNCONNECT",fmt:0,gxz:"ZV17BtnConnect",gxold:"OV17BtnConnect",gxvar:"AV17BtnConnect",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV17BtnConnect=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17BtnConnect=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNCONNECT",row || gx.fn.currentGridRowImpl(22),gx.O.AV17BtnConnect,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17BtnConnect=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNCONNECT",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn,evt:"e150c2_client"};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV6BtnUpd",gxold:"OV6BtnUpd",gxvar:"AV6BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(22),gx.O.AV6BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn,evt:"e130c2_client"};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:22,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV5BtnDlt",gxold:"OV5BtnDlt",gxvar:"AV5BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(22),gx.O.AV5BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(22))},nac:gx.falseFn,evt:"e140c2_client"};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   this.AV16Search = "" ;
   this.ZV16Search = "" ;
   this.OV16Search = "" ;
   this.ZV11Id = 0 ;
   this.OV11Id = 0 ;
   this.ZV13Name = "" ;
   this.OV13Name = "" ;
   this.ZV19GUID = "" ;
   this.OV19GUID = "" ;
   this.ZV17BtnConnect = "" ;
   this.OV17BtnConnect = "" ;
   this.ZV6BtnUpd = "" ;
   this.OV6BtnUpd = "" ;
   this.ZV5BtnDlt = "" ;
   this.OV5BtnDlt = "" ;
   this.AV16Search = "" ;
   this.AV11Id = 0 ;
   this.AV13Name = "" ;
   this.AV19GUID = "" ;
   this.AV17BtnConnect = "" ;
   this.AV6BtnUpd = "" ;
   this.AV5BtnDlt = "" ;
   this.Events = {"e110c2_client": ["'ADDNEW'", true] ,"e130c2_client": ["VBTNUPD.CLICK", true] ,"e140c2_client": ["VBTNDLT.CLICK", true] ,"e150c2_client": ["VBTNCONNECT.CLICK", true] ,"e170c2_client": ["ENTER", true] ,"e180c2_client": ["CANCEL", true] ,"e160c1_client": ["VSEARCH.CONTROLVALUECHANGED", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV16Search","fld":"vSEARCH"}],[{"ctrl":"WCMESSAGES"},{"av":"AV6BtnUpd","fld":"vBTNUPD"},{"av":"AV5BtnDlt","fld":"vBTNDLT"},{"av":"AV17BtnConnect","fld":"vBTNCONNECT"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNDLT\u0027,\u0027Visible\u0027)","ctrl":"vBTNDLT","prop":"Visible"},{"av":"AV11Id","fld":"vID","pic":"ZZZZZZZZZZZ9"},{"av":"AV13Name","fld":"vNAME"},{"av":"AV19GUID","fld":"vGUID","hsh":true}]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"}],[]];
   this.EvtParms["'ADDNEW'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"}],[]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"},{"av":"AV11Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"},{"av":"AV11Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV11Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["VBTNCONNECT.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"},{"av":"AV19GUID","fld":"vGUID","hsh":true}],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV16Search","fld":"vSEARCH"},{"av":"subGridww_Recordcount"}],[]];
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0031" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_wwrepositories);});
