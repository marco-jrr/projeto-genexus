/*
               File: GAM_WWRoles
        Description: GAM_Roles
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:31:38.37
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwroles', false, function () {
   this.ServerClass =  "gam_wwroles" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwroles.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV27SearchFilter=gx.fn.getControlValue("vSEARCHFILTER") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.e23061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Search_Controlvaluechanged Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e11061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'AddNew' Routine */
         this.clearMessages();
         this.call("gam_roleentry.aspx", ["INS", 0], null, ["Mode","Id"]);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e21062_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Name_Click Routine */
         this.clearMessages();
         this.call("gam_roleentry.aspx", ["DSP", this.AV12Id], null, ["Mode","Id"]);
         this.refreshOutputs([{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e22062_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Btnupd_Click Routine */
         this.clearMessages();
         this.call("gam_roleentry.aspx", ["UPD", this.AV12Id], null, ["Mode","Id"]);
         this.refreshOutputs([{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e18061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'First' Routine */
         this.clearMessages();
         this.AV8CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e19061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Previous' Routine */
         this.clearMessages();
         this.AV8CurrentPage = gx.num.trunc( this.AV8CurrentPage - 1 ,0) ;
         this.refreshOutputs([{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e20061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Next' Routine */
         this.clearMessages();
         this.AV8CurrentPage = gx.num.trunc( this.AV8CurrentPage + 1 ,0) ;
         this.refreshOutputs([{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e12061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Hide' Routine */
         this.clearMessages();
         if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
            gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
         }
         else
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
            gx.fn.setCtrlProperty("GAM_HEADERWW_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWW_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWW_TOGGLEFILTERS","prop":"Tooltiptext"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e14061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Apply' Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e13061_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearFilters' Routine */
         this.clearMessages();
         this.AV24FilRoleGUID =  ''  ;
         this.AV26FilRoleExternalId =  ''  ;
         this.refreshOutputs([{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e17062_client=function()
   {
      /* Btnsaveas_Click Routine */
      return this.executeServerEvent("VBTNSAVEAS.CLICK", true, arguments[0], false, false);
   };
   this.e24062_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e25062_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,38,40,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70];
   this.GXLastCtrlId =70;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",25,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwroles",[],false,1,true,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",26,"vNAME",gx.getMessage( "GAM_RoleName"),"","Name","char",0,"px",254,80,"start","e21062_client",[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Btnsaveas",27,"vBTNSAVEAS","","","BtnSaveAs","char",0,"px",20,20,"start","e17062_client",[],"Btnsaveas","BtnSaveAs",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btnupd",28,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"start","e22062_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Id",29,"vID",gx.getMessage( "GAM_KeyNumericLong"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWW",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWW_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_HEADERWW_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_HEADERWW_ADDNEW",grid:0,evt:"e11061_client"};
   GXValidFnc[14]={ id: 14, fld:"CELLSEARCH",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e23061_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV18Search",gxold:"OV18Search",gxvar:"AV18Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV18Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWW_TOGGLEFILTERS",grid:0,evt:"e12061_client"};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"SECTION1",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GRIDCONTAINER",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV14Name",gxold:"OV14Name",gxvar:"AV14Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV14Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV14Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV14Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e21062_client"};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNSAVEAS",fmt:0,gxz:"ZV5BtnSaveAs",gxold:"OV5BtnSaveAs",gxvar:"AV5BtnSaveAs",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnSaveAs=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnSaveAs=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNSAVEAS",row || gx.fn.currentGridRowImpl(25),gx.O.AV5BtnSaveAs,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnSaveAs=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNSAVEAS",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e17062_client"};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV6BtnUpd",gxold:"OV6BtnUpd",gxvar:"AV6BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(25),gx.O.AV6BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e22062_client"};
   GXValidFnc[29]={ id:29 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV12Id",gxold:"OV12Id",gxvar:"AV12Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV12Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(25),gx.O.AV12Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(25),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[38]={ id: 38, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e18061_client"};
   GXValidFnc[40]={ id: 40, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e19061_client"};
   GXValidFnc[42]={ id: 42, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e20061_client"};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id:46 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV8CurrentPage",gxold:"OV8CurrentPage",gxvar:"AV8CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV8CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV8CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV8CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[47]={ id: 47, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e12061_client"};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id:58 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILROLEGUID",fmt:0,gxz:"ZV24FilRoleGUID",gxold:"OV24FilRoleGUID",gxvar:"AV24FilRoleGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV24FilRoleGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV24FilRoleGUID=Value},v2c:function(){gx.fn.setControlValue("vFILROLEGUID",gx.O.AV24FilRoleGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV24FilRoleGUID=this.val()},val:function(){return gx.fn.getControlValue("vFILROLEGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 58 , function() {
   });
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id:63 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILROLEEXTERNALID",fmt:0,gxz:"ZV26FilRoleExternalId",gxold:"OV26FilRoleExternalId",gxvar:"AV26FilRoleExternalId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26FilRoleExternalId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV26FilRoleExternalId=Value},v2c:function(){gx.fn.setControlValue("vFILROLEEXTERNALID",gx.O.AV26FilRoleExternalId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV26FilRoleExternalId=this.val()},val:function(){return gx.fn.getControlValue("vFILROLEEXTERNALID")},nac:gx.falseFn};
   this.declareDomainHdlr( 63 , function() {
   });
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e13061_client"};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e14061_client"};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   this.AV18Search = "" ;
   this.ZV18Search = "" ;
   this.OV18Search = "" ;
   this.ZV14Name = "" ;
   this.OV14Name = "" ;
   this.ZV5BtnSaveAs = "" ;
   this.OV5BtnSaveAs = "" ;
   this.ZV6BtnUpd = "" ;
   this.OV6BtnUpd = "" ;
   this.ZV12Id = 0 ;
   this.OV12Id = 0 ;
   this.AV8CurrentPage = 0 ;
   this.ZV8CurrentPage = 0 ;
   this.OV8CurrentPage = 0 ;
   this.AV24FilRoleGUID = "" ;
   this.ZV24FilRoleGUID = "" ;
   this.OV24FilRoleGUID = "" ;
   this.AV26FilRoleExternalId = "" ;
   this.ZV26FilRoleExternalId = "" ;
   this.OV26FilRoleExternalId = "" ;
   this.AV18Search = "" ;
   this.AV8CurrentPage = 0 ;
   this.AV24FilRoleGUID = "" ;
   this.AV26FilRoleExternalId = "" ;
   this.AV14Name = "" ;
   this.AV5BtnSaveAs = "" ;
   this.AV6BtnUpd = "" ;
   this.AV12Id = 0 ;
   this.AV27SearchFilter = "" ;
   this.Events = {"e17062_client": ["VBTNSAVEAS.CLICK", true] ,"e24062_client": ["ENTER", true] ,"e25062_client": ["CANCEL", true] ,"e23061_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e11061_client": ["'ADDNEW'", false] ,"e21062_client": ["VNAME.CLICK", false] ,"e22062_client": ["VBTNUPD.CLICK", false] ,"e18061_client": ["'FIRST'", false] ,"e19061_client": ["'PREVIOUS'", false] ,"e20061_client": ["'NEXT'", false] ,"e12061_client": ["'HIDE'", false] ,"e14061_client": ["'APPLY'", false] ,"e13061_client": ["'CLEARFILTERS'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true}],[]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"}],[{"av":"AV6BtnUpd","fld":"vBTNUPD"},{"av":"AV5BtnSaveAs","fld":"vBTNSAVEAS"},{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"},{"av":"AV14Name","fld":"vNAME"},{"ctrl":"GAM_PAGINGWW_BTNNEXT","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNFIRST","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNPREVIOUS","prop":"Enabled"}]];
   this.EvtParms["'ADDNEW'"] = [[],[]];
   this.EvtParms["VNAME.CLICK"] = [[{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}]];
   this.EvtParms["VBTNSAVEAS.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"},{"av":"AV12Id","fld":"vID","pic":"ZZZZZZZZZZZ9"}],[{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'FIRST'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"}],[{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'PREVIOUS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"}],[{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'NEXT'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"}],[{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'HIDE'"] = [[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWW_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWW_TOGGLEFILTERS","prop":"Tooltiptext"}]];
   this.EvtParms["'APPLY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV8CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV18Search","fld":"vSEARCH"},{"av":"AV27SearchFilter","fld":"vSEARCHFILTER","hsh":true},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"},{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"}],[{"av":"AV24FilRoleGUID","fld":"vFILROLEGUID"},{"av":"AV26FilRoleExternalId","fld":"vFILROLEEXTERNALID"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.setVCMap("AV27SearchFilter", "vSEARCHFILTER", 0, "svchar", 100, 60);
   this.setVCMap("AV27SearchFilter", "vSEARCHFILTER", 0, "svchar", 100, 60);
   this.setVCMap("AV27SearchFilter", "vSEARCHFILTER", 0, "svchar", 100, 60);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[46]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV27SearchFilter"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[63]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[58]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[46]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV27SearchFilter"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[63]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[58]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0071" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_wwroles);});
