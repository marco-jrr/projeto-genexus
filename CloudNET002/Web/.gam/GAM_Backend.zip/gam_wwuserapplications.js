/*
               File: GAM_WWUserApplications
        Description: GAM_ApplicationsAPIkey
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:35:54.37
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwuserapplications', false, function () {
   this.ServerClass =  "gam_wwuserapplications" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwuserapplications.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV31UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.AV10BoolenFilter=gx.fn.getControlValue("vBOOLENFILTER") ;
      this.AV27PermissionAccessType=gx.fn.getControlValue("vPERMISSIONACCESSTYPE") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.e203f2_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Btnrevoke_Click Routine */
         this.clearMessages();
         this.AV33Window.Url =  gx.http.formatLink("gam_warningnotification.aspx",["user:revokeapikey", this.AV31UserGUID, this.AV13ClientID])  ;
         this.AV33Window.ReturnParms =  []  ;
         this.popupOpen(this.AV33Window) ;
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e213f2_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Btngenerate_Click Routine */
         this.clearMessages();
         this.AV33Window.Url =  gx.http.formatLink("gam_userapplicationapikey.aspx",[this.AV31UserGUID, this.AV13ClientID])  ;
         this.AV33Window.ReturnParms =  []  ;
         this.popupOpen(this.AV33Window) ;
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e223f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Search_Controlvaluechanged Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e133f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Apply' Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e123f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearFilters' Routine */
         this.clearMessages();
         this.AV27PermissionAccessType =  ''  ;
         this.AV10BoolenFilter =  ''  ;
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e113f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Hide' Routine */
         this.clearMessages();
         if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
            gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
         }
         else
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
            gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","prop":"Tooltiptext"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e173f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'First' Routine */
         this.clearMessages();
         this.AV15CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e183f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Previous' Routine */
         this.clearMessages();
         this.AV15CurrentPage = gx.num.trunc( this.AV15CurrentPage - 1 ,0) ;
         this.refreshOutputs([{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e193f1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Next' Routine */
         this.clearMessages();
         this.AV15CurrentPage = gx.num.trunc( this.AV15CurrentPage + 1 ,0) ;
         this.refreshOutputs([{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e143f2_client=function()
   {
      /* Gam_headerwwbackfilters_tableback_Click Routine */
      return this.executeServerEvent("GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK", true, null, false, true);
   };
   this.e233f2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e243f2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,35,36,37,38,39,40,41,42,43,44,45,46,47,50,52,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,89,90,91,92,93,94,95,96,97,98];
   this.GXLastCtrlId =98;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",34,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwuserapplications",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Id",35,"vID",gx.getMessage( "GAM_ID"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   GridwwContainer.addSingleLineEdit("Name",36,"vNAME",gx.getMessage( "GAM_ApplicationName"),"","Name","char",300,"px",254,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Description",37,"vDESCRIPTION",gx.getMessage( "GAM_Description"),"","Description","char",300,"px",254,80,"start",null,[],"Description","Description",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Clientid",38,"vCLIENTID",gx.getMessage( "GAM_ClientID"),"","ClientID","char",300,"px",40,40,"start",null,[],"Clientid","ClientID",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Status",39,"vSTATUS",gx.getMessage( "GAM_APIKeyStatus"),"","Status","svchar",100,"px",40,40,"start",null,[],"Status","Status",true,0,false,false,"",0,"column column-optional");
   GridwwContainer.addSingleLineEdit("Btnrevoke",40,"vBTNREVOKE","","","BtnRevoke","char",0,"px",20,20,"start","e203f2_client",[],"Btnrevoke","BtnRevoke",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btngenerate",41,"vBTNGENERATE","","","BtnGenerate","char",0,"px",20,20,"start","e213f2_client",[],"Btngenerate","BtnGenerate",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWBACKFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWBACKFILTERS_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERWWBACKFILTERS_TABLEBACK",grid:0,evt:"e143f2_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERWWBACKFILTERS_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWWBACKFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERWWBACKFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERWWBACKFILTERS_ADDNEW",grid:0,evt:"e253f1_client"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e223f1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV29Search",gxold:"OV29Search",gxvar:"AV29Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV29Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"SECTIONGRID",grid:0};
   GXValidFnc[31]={ id: 31, fld:"GRIDTABLE",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV21Id",gxold:"OV21Id",gxvar:"AV21Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV21Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(34),gx.O.AV21Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV21Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(34),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[36]={ id:36 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV24Name",gxold:"OV24Name",gxvar:"AV24Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV24Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV24Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(34),gx.O.AV24Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV24Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[37]={ id:37 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDESCRIPTION",fmt:0,gxz:"ZV38Description",gxold:"OV38Description",gxvar:"AV38Description",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV38Description=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV38Description=Value},v2c:function(row){gx.fn.setGridControlValue("vDESCRIPTION",row || gx.fn.currentGridRowImpl(34),gx.O.AV38Description,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV38Description=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDESCRIPTION",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[38]={ id:38 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTID",fmt:0,gxz:"ZV13ClientID",gxold:"OV13ClientID",gxvar:"AV13ClientID",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV13ClientID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13ClientID=Value},v2c:function(row){gx.fn.setGridControlValue("vCLIENTID",row || gx.fn.currentGridRowImpl(34),gx.O.AV13ClientID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV13ClientID=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vCLIENTID",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[39]={ id:39 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTATUS",fmt:0,gxz:"ZV30Status",gxold:"OV30Status",gxvar:"AV30Status",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV30Status=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30Status=Value},v2c:function(row){gx.fn.setGridControlValue("vSTATUS",row || gx.fn.currentGridRowImpl(34),gx.O.AV30Status,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV30Status=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vSTATUS",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[40]={ id:40 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNREVOKE",fmt:0,gxz:"ZV12BtnRevoke",gxold:"OV12BtnRevoke",gxvar:"AV12BtnRevoke",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV12BtnRevoke=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12BtnRevoke=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNREVOKE",row || gx.fn.currentGridRowImpl(34),gx.O.AV12BtnRevoke,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV12BtnRevoke=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNREVOKE",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e203f2_client"};
   GXValidFnc[41]={ id:41 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNGENERATE",fmt:0,gxz:"ZV34BtnGenerate",gxold:"OV34BtnGenerate",gxvar:"AV34BtnGenerate",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV34BtnGenerate=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV34BtnGenerate=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNGENERATE",row || gx.fn.currentGridRowImpl(34),gx.O.AV34BtnGenerate,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV34BtnGenerate=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNGENERATE",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e213f2_client"};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[50]={ id: 50, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e173f1_client"};
   GXValidFnc[52]={ id: 52, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e183f1_client"};
   GXValidFnc[54]={ id: 54, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e193f1_client"};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id:58 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV15CurrentPage",gxold:"OV15CurrentPage",gxvar:"AV15CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV15CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV15CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV15CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[59]={ id: 59, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e113f1_client"};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id:70 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILTERGUID",fmt:0,gxz:"ZV35FilterGUID",gxold:"OV35FilterGUID",gxvar:"AV35FilterGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35FilterGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV35FilterGUID=Value},v2c:function(){gx.fn.setControlValue("vFILTERGUID",gx.O.AV35FilterGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35FilterGUID=this.val()},val:function(){return gx.fn.getControlValue("vFILTERGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 70 , function() {
   });
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id:75 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILTERCLIENTID",fmt:0,gxz:"ZV36FilterClientId",gxold:"OV36FilterClientId",gxvar:"AV36FilterClientId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV36FilterClientId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV36FilterClientId=Value},v2c:function(){gx.fn.setControlValue("vFILTERCLIENTID",gx.O.AV36FilterClientId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV36FilterClientId=this.val()},val:function(){return gx.fn.getControlValue("vFILTERCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 75 , function() {
   });
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id:80 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILTERDESCRIPTION",fmt:0,gxz:"ZV37FilterDescription",gxold:"OV37FilterDescription",gxvar:"AV37FilterDescription",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV37FilterDescription=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV37FilterDescription=Value},v2c:function(){gx.fn.setControlValue("vFILTERDESCRIPTION",gx.O.AV37FilterDescription,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37FilterDescription=this.val()},val:function(){return gx.fn.getControlValue("vFILTERDESCRIPTION")},nac:gx.falseFn};
   this.declareDomainHdlr( 80 , function() {
   });
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e123f1_client"};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e133f1_client"};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id: 91, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id: 94, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e263f1_client"};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e273f1_client"};
   this.AV29Search = "" ;
   this.ZV29Search = "" ;
   this.OV29Search = "" ;
   this.ZV21Id = 0 ;
   this.OV21Id = 0 ;
   this.ZV24Name = "" ;
   this.OV24Name = "" ;
   this.ZV38Description = "" ;
   this.OV38Description = "" ;
   this.ZV13ClientID = "" ;
   this.OV13ClientID = "" ;
   this.ZV30Status = "" ;
   this.OV30Status = "" ;
   this.ZV12BtnRevoke = "" ;
   this.OV12BtnRevoke = "" ;
   this.ZV34BtnGenerate = "" ;
   this.OV34BtnGenerate = "" ;
   this.AV15CurrentPage = 0 ;
   this.ZV15CurrentPage = 0 ;
   this.OV15CurrentPage = 0 ;
   this.AV35FilterGUID = "" ;
   this.ZV35FilterGUID = "" ;
   this.OV35FilterGUID = "" ;
   this.AV36FilterClientId = "" ;
   this.ZV36FilterClientId = "" ;
   this.OV36FilterClientId = "" ;
   this.AV37FilterDescription = "" ;
   this.ZV37FilterDescription = "" ;
   this.OV37FilterDescription = "" ;
   this.AV29Search = "" ;
   this.AV15CurrentPage = 0 ;
   this.AV35FilterGUID = "" ;
   this.AV36FilterClientId = "" ;
   this.AV37FilterDescription = "" ;
   this.AV31UserGUID = "" ;
   this.AV21Id = 0 ;
   this.AV24Name = "" ;
   this.AV38Description = "" ;
   this.AV13ClientID = "" ;
   this.AV30Status = "" ;
   this.AV12BtnRevoke = "" ;
   this.AV34BtnGenerate = "" ;
   this.AV10BoolenFilter = "" ;
   this.AV27PermissionAccessType = "" ;
   this.AV33Window = {} ;
   this.Events = {"e143f2_client": ["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK", true] ,"e233f2_client": ["ENTER", true] ,"e243f2_client": ["CANCEL", true] ,"e203f2_client": ["VBTNREVOKE.CLICK", false] ,"e213f2_client": ["VBTNGENERATE.CLICK", false] ,"e223f1_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e133f1_client": ["'APPLY'", false] ,"e123f1_client": ["'CLEARFILTERS'", false] ,"e113f1_client": ["'HIDE'", false] ,"e173f1_client": ["'FIRST'", false] ,"e183f1_client": ["'PREVIOUS'", false] ,"e193f1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"}],[{"av":"AV12BtnRevoke","fld":"vBTNREVOKE"},{"av":"AV34BtnGenerate","fld":"vBTNGENERATE"},{"av":"AV21Id","fld":"vID","pic":"ZZZZZZZZZZZ9"},{"av":"AV24Name","fld":"vNAME"},{"av":"AV38Description","fld":"vDESCRIPTION"},{"av":"AV13ClientID","fld":"vCLIENTID","hsh":true},{"av":"AV30Status","fld":"vSTATUS"},{"av":"gx.fn.getCtrlProperty(\u0027vSTATUS\u0027,\u0027Class\u0027)","ctrl":"vSTATUS","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNREVOKE\u0027,\u0027Enabled\u0027)","ctrl":"vBTNREVOKE","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNNEXT","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNFIRST","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNPREVIOUS","prop":"Enabled"}]];
   this.EvtParms["VBTNREVOKE.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true},{"av":"AV13ClientID","fld":"vCLIENTID","hsh":true}],[]];
   this.EvtParms["VBTNGENERATE.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true},{"av":"AV13ClientID","fld":"vCLIENTID","hsh":true}],[]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["'APPLY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["'HIDE'"] = [[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","prop":"Tooltiptext"}]];
   this.EvtParms["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK"] = [[{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["'FIRST'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'PREVIOUS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'NEXT'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV15CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV29Search","fld":"vSEARCH"},{"av":"AV35FilterGUID","fld":"vFILTERGUID"},{"av":"AV36FilterClientId","fld":"vFILTERCLIENTID"},{"av":"AV37FilterDescription","fld":"vFILTERDESCRIPTION"},{"av":"AV31UserGUID","fld":"vUSERGUID","hsh":true},{"av":"subGridww_Recordcount"}],[]];
   this.setVCMap("AV31UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV10BoolenFilter", "vBOOLENFILTER", 0, "char", 1, 0);
   this.setVCMap("AV27PermissionAccessType", "vPERMISSIONACCESSTYPE", 0, "char", 1, 0);
   this.setVCMap("AV31UserGUID", "vUSERGUID", 0, "char", 40, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[58]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[70]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[75]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[80]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV31UserGUID"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[58]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[70]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[75]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[80]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV31UserGUID"});
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0088" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_wwuserapplications);});
