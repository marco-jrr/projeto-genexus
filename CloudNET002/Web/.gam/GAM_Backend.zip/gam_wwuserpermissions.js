/*
               File: GAM_WWUserPermissions
        Description: GAM_Userspermissions
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:34:56.32
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwuserpermissions', false, function () {
   this.ServerClass =  "gam_wwuserpermissions" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwuserpermissions.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV38UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.AV22pApplicationId=gx.fn.getIntegerValue("vPAPPLICATIONID",gx.thousandSeparator) ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Accesstype=function()
   {
      var currentRow = gx.fn.currentGridRowImpl(39);
      return this.validCliEvt("Validv_Accesstype", 39, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV5AccessType , "A" ) == 0 || gx.text.compare( this.AV5AccessType , "D" ) == 0 || gx.text.compare( this.AV5AccessType , "R" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Access Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Permissionaccesstype=function()
   {
      return this.validCliEvt("Validv_Permissionaccesstype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vPERMISSIONACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV24PermissionAccessType , "A" ) == 0 || gx.text.compare( this.AV24PermissionAccessType , "D" ) == 0 || gx.text.compare( this.AV24PermissionAccessType , "R" ) == 0 || (gx.text.compare('',this.AV24PermissionAccessType)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Permission Access Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Boolenfilter=function()
   {
      return this.validCliEvt("Validv_Boolenfilter", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vBOOLENFILTER");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV9BoolenFilter , "A" ) == 0 || gx.text.compare( this.AV9BoolenFilter , "T" ) == 0 || gx.text.compare( this.AV9BoolenFilter , "F" ) == 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Boolen Filter"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e242s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Applicationid_Controlvaluechanged Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e252s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Search_Controlvaluechanged Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e132s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Apply' Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e122s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearFilters' Routine */
         this.clearMessages();
         this.AV24PermissionAccessType =  ''  ;
         this.AV9BoolenFilter =  ''  ;
         this.refreshOutputs([{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e112s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Hide' Routine */
         this.clearMessages();
         if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
            gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
         }
         else
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
            gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","prop":"Tooltiptext"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e212s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'First' Routine */
         this.clearMessages();
         this.AV35CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e222s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Previous' Routine */
         this.clearMessages();
         this.AV35CurrentPage = gx.num.trunc( this.AV35CurrentPage - 1 ,0) ;
         this.refreshOutputs([{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e232s1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Next' Routine */
         this.clearMessages();
         this.AV35CurrentPage = gx.num.trunc( this.AV35CurrentPage + 1 ,0) ;
         this.refreshOutputs([{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e142s2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e182s2_client=function()
   {
      /* Accesstype_Controlvaluechanged Routine */
      return this.executeServerEvent("VACCESSTYPE.CONTROLVALUECHANGED", true, arguments[0], false, false);
   };
   this.e192s2_client=function()
   {
      /* Inherited_Controlvaluechanged Routine */
      return this.executeServerEvent("VINHERITED.CONTROLVALUECHANGED", true, arguments[0], false, false);
   };
   this.e152s2_client=function()
   {
      /* Gam_headerwwbackfilters_tableback_Click Routine */
      return this.executeServerEvent("GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK", true, null, false, true);
   };
   this.e202s2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e262s2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e272s2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,40,41,42,43,44,45,46,47,48,49,50,51,54,56,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,88,89,90,91,92,93,94,95,96,97];
   this.GXLastCtrlId =97;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",39,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwuserpermissions",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",40,"vNAME",gx.getMessage( "GAM_Permissionname"),"","Name","char",0,"px",120,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Dsc",41,"vDSC",gx.getMessage( "GAM_Description"),"","Dsc","char",0,"px",254,80,"start",null,[],"Dsc","Dsc",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addComboBox("Accesstype",42,"vACCESSTYPE",gx.getMessage( "GAM_Permissionsoptions"),"AccessType","char",null,0,true,false,150,"px","column column-optional");
   GridwwContainer.addCheckBox("Inherited",43,"vINHERITED",gx.getMessage( "GAM_Inherited"),"","Inherited","boolean","true","false",null,true,false,50,"px","column column-optional");
   GridwwContainer.addSingleLineEdit("Btndlt",44,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e202s2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Id",45,"vID",gx.getMessage( "GAM_GUID"),"","Id","char",0,"px",40,40,"start",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWBACKFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWBACKFILTERS_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERWWBACKFILTERS_TABLEBACK",grid:0,evt:"e152s2_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERWWBACKFILTERS_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWWBACKFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERWWBACKFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERWWBACKFILTERS_ADDNEW",grid:0,evt:"e142s2_client"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e252s1_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV37Search",gxold:"OV37Search",gxvar:"AV37Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV37Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV37Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV37Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS",grid:0,evt:"e112s1_client"};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"SECTIONGRID",grid:0};
   GXValidFnc[31]={ id: 31, fld:"GRIDTABLE",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id:36 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e242s1_client',evt_cvcing:null,rgrid:[],fld:"vAPPLICATIONID",fmt:0,gxz:"ZV8ApplicationId",gxold:"OV8ApplicationId",gxvar:"AV8ApplicationId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV8ApplicationId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV8ApplicationId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vAPPLICATIONID",gx.O.AV8ApplicationId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV8ApplicationId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 36 , function() {
   });
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[40]={ id:40 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:39,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV19Name",gxold:"OV19Name",gxvar:"AV19Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV19Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(39),gx.O.AV19Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV19Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(39))},nac:gx.falseFn};
   GXValidFnc[41]={ id:41 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:39,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",fmt:0,gxz:"ZV11Dsc",gxold:"OV11Dsc",gxvar:"AV11Dsc",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV11Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Dsc=Value},v2c:function(row){gx.fn.setGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(39),gx.O.AV11Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Dsc=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vDSC",row || gx.fn.currentGridRowImpl(39))},nac:gx.falseFn};
   GXValidFnc[42]={ id:42 ,lvl:2,type:"char",len:1,dec:0,sign:false,ro:0,isacc:0,grid:39,gxgrid:this.GridwwContainer,fnc:this.Validv_Accesstype,isvalid:null,evt_cvc:'e182s2_client',evt_cvcing:null,rgrid:[],fld:"vACCESSTYPE",fmt:0,gxz:"ZV5AccessType",gxold:"OV5AccessType",gxvar:"AV5AccessType",ucs:[],op:[42],ip:[42],nacdep:[],ctrltype:"combo",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV5AccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AccessType=Value},v2c:function(row){gx.fn.setGridComboBoxValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(39),gx.O.AV5AccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5AccessType=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vACCESSTYPE",row || gx.fn.currentGridRowImpl(39))},nac:gx.falseFn};
   GXValidFnc[43]={ id:43 ,lvl:2,type:"boolean",len:4,dec:0,sign:false,ro:0,isacc:0,grid:39,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:'e192s2_client',evt_cvcing:null,rgrid:[],fld:"vINHERITED",fmt:0,gxz:"ZV17Inherited",gxold:"OV17Inherited",gxvar:"AV17Inherited",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"checkbox",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV17Inherited=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV17Inherited=gx.lang.booleanValue(Value)},v2c:function(row){gx.fn.setGridCheckBoxValue("vINHERITED",row || gx.fn.currentGridRowImpl(39),gx.O.AV17Inherited,true)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV17Inherited=gx.lang.booleanValue(this.val(row))},val:function(row){return gx.fn.getGridControlValue("vINHERITED",row || gx.fn.currentGridRowImpl(39))},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[44]={ id:44 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:39,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV10BtnDlt",gxold:"OV10BtnDlt",gxvar:"AV10BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV10BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(39),gx.O.AV10BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV10BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(39))},nac:gx.falseFn,evt:"e202s2_client"};
   GXValidFnc[45]={ id:45 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:39,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV16Id",gxold:"OV16Id",gxvar:"AV16Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV16Id=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Id=Value},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(39),gx.O.AV16Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Id=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vID",row || gx.fn.currentGridRowImpl(39))},nac:gx.falseFn};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[54]={ id: 54, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e212s1_client"};
   GXValidFnc[56]={ id: 56, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e222s1_client"};
   GXValidFnc[58]={ id: 58, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e232s1_client"};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id:62 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV35CurrentPage",gxold:"OV35CurrentPage",gxvar:"AV35CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV35CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV35CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV35CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[63]={ id: 63, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e112s1_client"};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id:74 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Permissionaccesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPERMISSIONACCESSTYPE",fmt:0,gxz:"ZV24PermissionAccessType",gxold:"OV24PermissionAccessType",gxvar:"AV24PermissionAccessType",ucs:[],op:[74],ip:[74],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV24PermissionAccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV24PermissionAccessType=Value},v2c:function(){gx.fn.setComboBoxValue("vPERMISSIONACCESSTYPE",gx.O.AV24PermissionAccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV24PermissionAccessType=this.val()},val:function(){return gx.fn.getControlValue("vPERMISSIONACCESSTYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 74 , function() {
   });
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id:79 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Boolenfilter,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBOOLENFILTER",fmt:0,gxz:"ZV9BoolenFilter",gxold:"OV9BoolenFilter",gxvar:"AV9BoolenFilter",ucs:[],op:[79],ip:[79],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV9BoolenFilter=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9BoolenFilter=Value},v2c:function(){gx.fn.setComboBoxValue("vBOOLENFILTER",gx.O.AV9BoolenFilter);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV9BoolenFilter=this.val()},val:function(){return gx.fn.getControlValue("vBOOLENFILTER")},nac:gx.falseFn};
   this.declareDomainHdlr( 79 , function() {
   });
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e122s1_client"};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e132s1_client"};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[94]={ id: 94, fld:"",grid:0};
   GXValidFnc[95]={ id: 95, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e282s1_client"};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e292s1_client"};
   this.AV37Search = "" ;
   this.ZV37Search = "" ;
   this.OV37Search = "" ;
   this.AV8ApplicationId = 0 ;
   this.ZV8ApplicationId = 0 ;
   this.OV8ApplicationId = 0 ;
   this.ZV19Name = "" ;
   this.OV19Name = "" ;
   this.ZV11Dsc = "" ;
   this.OV11Dsc = "" ;
   this.ZV5AccessType = "" ;
   this.OV5AccessType = "" ;
   this.ZV17Inherited = false ;
   this.OV17Inherited = false ;
   this.ZV10BtnDlt = "" ;
   this.OV10BtnDlt = "" ;
   this.ZV16Id = "" ;
   this.OV16Id = "" ;
   this.AV35CurrentPage = 0 ;
   this.ZV35CurrentPage = 0 ;
   this.OV35CurrentPage = 0 ;
   this.AV24PermissionAccessType = "" ;
   this.ZV24PermissionAccessType = "" ;
   this.OV24PermissionAccessType = "" ;
   this.AV9BoolenFilter = "" ;
   this.ZV9BoolenFilter = "" ;
   this.OV9BoolenFilter = "" ;
   this.AV37Search = "" ;
   this.AV8ApplicationId = 0 ;
   this.AV35CurrentPage = 0 ;
   this.AV24PermissionAccessType = "" ;
   this.AV9BoolenFilter = "" ;
   this.AV38UserGUID = "" ;
   this.AV22pApplicationId = 0 ;
   this.AV19Name = "" ;
   this.AV11Dsc = "" ;
   this.AV5AccessType = "" ;
   this.AV17Inherited = false ;
   this.AV10BtnDlt = "" ;
   this.AV16Id = "" ;
   this.Events = {"e142s2_client": ["'ADDNEW'", true] ,"e182s2_client": ["VACCESSTYPE.CONTROLVALUECHANGED", true] ,"e192s2_client": ["VINHERITED.CONTROLVALUECHANGED", true] ,"e152s2_client": ["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK", true] ,"e202s2_client": ["VBTNDLT.CLICK", true] ,"e262s2_client": ["ENTER", true] ,"e272s2_client": ["CANCEL", true] ,"e242s1_client": ["VAPPLICATIONID.CONTROLVALUECHANGED", false] ,"e252s1_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e132s1_client": ["'APPLY'", false] ,"e122s1_client": ["'CLEARFILTERS'", false] ,"e112s1_client": ["'HIDE'", false] ,"e212s1_client": ["'FIRST'", false] ,"e222s1_client": ["'PREVIOUS'", false] ,"e232s1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"av":"AV10BtnDlt","fld":"vBTNDLT"},{"av":"AV16Id","fld":"vID","hsh":true},{"av":"AV19Name","fld":"vNAME"},{"av":"AV11Dsc","fld":"vDSC"},{"ctrl":"vACCESSTYPE"},{"av":"AV5AccessType","fld":"vACCESSTYPE"},{"av":"AV17Inherited","fld":"vINHERITED"},{"ctrl":"GAM_PAGINGWW_BTNNEXT","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNFIRST","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNPREVIOUS","prop":"Enabled"}]];
   this.EvtParms["'ADDNEW'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["VACCESSTYPE.CONTROLVALUECHANGED"] = [[{"av":"AV38UserGUID","fld":"vUSERGUID"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV16Id","fld":"vID","hsh":true},{"ctrl":"vACCESSTYPE"},{"av":"AV5AccessType","fld":"vACCESSTYPE"},{"av":"AV17Inherited","fld":"vINHERITED"}],[{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["VINHERITED.CONTROLVALUECHANGED"] = [[{"av":"AV38UserGUID","fld":"vUSERGUID"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV16Id","fld":"vID","hsh":true},{"ctrl":"vACCESSTYPE"},{"av":"AV5AccessType","fld":"vACCESSTYPE"},{"av":"AV17Inherited","fld":"vINHERITED"}],[{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["VAPPLICATIONID.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[]];
   this.EvtParms["'APPLY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[]];
   this.EvtParms["'CLEARFILTERS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"}]];
   this.EvtParms["'HIDE'"] = [[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","prop":"Tooltiptext"}]];
   this.EvtParms["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK"] = [[{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV38UserGUID","fld":"vUSERGUID"}],[]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true},{"av":"AV16Id","fld":"vID","hsh":true}],[{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'FIRST'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'PREVIOUS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'NEXT'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"AV38UserGUID","fld":"vUSERGUID"},{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"ctrl":"vAPPLICATIONID"},{"av":"AV8ApplicationId","fld":"vAPPLICATIONID","pic":"ZZZZZZZZZZZ9"},{"av":"AV37Search","fld":"vSEARCH"},{"ctrl":"vPERMISSIONACCESSTYPE"},{"av":"AV24PermissionAccessType","fld":"vPERMISSIONACCESSTYPE"},{"ctrl":"vBOOLENFILTER"},{"av":"AV9BoolenFilter","fld":"vBOOLENFILTER"},{"av":"AV22pApplicationId","fld":"vPAPPLICATIONID","pic":"ZZZZZZZZZZZ9","hsh":true}],[{"av":"AV35CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_PERMISSIONACCESSTYPE"] = [[],[]];
   this.EvtParms["VALIDV_BOOLENFILTER"] = [[],[]];
   this.EvtParms["VALIDV_ACCESSTYPE"] = [[{"ctrl":"vACCESSTYPE"},{"av":"AV5AccessType","fld":"vACCESSTYPE"}],[{"ctrl":"vACCESSTYPE"},{"av":"AV5AccessType","fld":"vACCESSTYPE"}]];
   this.setVCMap("AV38UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV22pApplicationId", "vPAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("AV38UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV38UserGUID", "vUSERGUID", 0, "char", 40, 0);
   GridwwContainer.addRefreshingVar({rfrVar:"AV38UserGUID"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[62]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[36]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[74]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[79]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV22pApplicationId"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV38UserGUID"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[62]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[36]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[25]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[74]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[79]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV22pApplicationId"});
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0087" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_wwuserpermissions);});
