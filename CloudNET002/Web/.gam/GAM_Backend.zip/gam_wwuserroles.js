/*
               File: GAM_WWUserRoles
        Description: GAM_Userroles
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:33:21.45
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwuserroles', false, function () {
   this.ServerClass =  "gam_wwuserroles" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwuserroles.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV24UserGUID=gx.fn.getControlValue("vUSERGUID") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e130z1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Apply' Routine */
         this.clearMessages();
         this.refreshOutputs([]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e120z1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearFilters' Routine */
         this.clearMessages();
         this.AV9DisplayInheritRoles =  false  ;
         this.refreshOutputs([{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e110z1_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Hide' Routine */
         this.clearMessages();
         if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
            gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
         }
         else
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
            gx.fn.setCtrlProperty("GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","prop":"Tooltiptext"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e140z2_client=function()
   {
      /* Gam_headerwwbackfilters_tableback_Click Routine */
      return this.executeServerEvent("GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK", true, null, false, true);
   };
   this.e180z2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e150z2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e190z2_client=function()
   {
      /* Btnmainrole_Click Routine */
      return this.executeServerEvent("VBTNMAINROLE.CLICK", true, arguments[0], false, false);
   };
   this.e200z2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e210z2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,60,61,62,63,64,65,66,67,68,69];
   this.GXLastCtrlId =69;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",34,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwuserroles",[],false,1,false,true,10,true,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",35,"vNAME",gx.getMessage( "GAM_Rolename"),"","Name","char",90,"%",120,80,"start",null,[],"Name","Name",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Btnmainrole",36,"vBTNMAINROLE","","","BtnMainRole","char",0,"px",10,10,"start","e190z2_client",[],"Btnmainrole","BtnMainRole",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btndlt",37,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"start","e180z2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Guid",38,"vGUID",gx.getMessage( "GAM_GUID"),"","GUID","char",0,"px",40,40,"start",null,[],"Guid","GUID",false,0,false,false,"Attribute",0,"");
   GridwwContainer.addSingleLineEdit("Id",39,"vID",gx.getMessage( "GAM_KeyNumericLong"),"","Id","int",0,"px",12,12,"end",null,[],"Id","Id",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "No results found.");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_HEADERWWBACKFILTERS",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_HEADERWWBACKFILTERS_TBLBACKCONTAINER",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"GAM_HEADERWWBACKFILTERS_TABLEBACK",grid:0,evt:"e140z2_client"};
   GXValidFnc[15]={ id: 15, fld:"GAM_HEADERWWBACKFILTERS_TXTBACK", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_HEADERWWBACKFILTERS_TABLEACTIONS",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"GAM_HEADERWWBACKFILTERS_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"GAM_HEADERWWBACKFILTERS_ADDNEW",grid:0,evt:"e150z2_client"};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV23Search",gxold:"OV23Search",gxvar:"AV23Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV23Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV23Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV23Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV23Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"SECTIONGRID",grid:0};
   GXValidFnc[31]={ id: 31, fld:"GRIDTABLE",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV18Name",gxold:"OV18Name",gxvar:"AV18Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV18Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(34),gx.O.AV18Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV18Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[36]={ id:36 ,lvl:2,type:"char",len:10,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNMAINROLE",fmt:0,gxz:"ZV8BtnMainRole",gxold:"OV8BtnMainRole",gxvar:"AV8BtnMainRole",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8BtnMainRole=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8BtnMainRole=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNMAINROLE",row || gx.fn.currentGridRowImpl(34),gx.O.AV8BtnMainRole,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8BtnMainRole=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNMAINROLE",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e190z2_client"};
   GXValidFnc[37]={ id:37 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",fmt:0,gxz:"ZV7BtnDlt",gxold:"OV7BtnDlt",gxvar:"AV7BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV7BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(34),gx.O.AV7BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV7BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn,evt:"e180z2_client"};
   GXValidFnc[38]={ id:38 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",fmt:0,gxz:"ZV15GUID",gxold:"OV15GUID",gxvar:"AV15GUID",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV15GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15GUID=Value},v2c:function(row){gx.fn.setGridControlValue("vGUID",row || gx.fn.currentGridRowImpl(34),gx.O.AV15GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV15GUID=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vGUID",row || gx.fn.currentGridRowImpl(34))},nac:gx.falseFn};
   GXValidFnc[39]={ id:39 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:34,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",fmt:0,gxz:"ZV16Id",gxold:"OV16Id",gxvar:"AV16Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV16Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(34),gx.O.AV16Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV16Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(34),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[40]={ id: 40, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e110z1_client"};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id:51 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDISPLAYINHERITROLES",fmt:0,gxz:"ZV9DisplayInheritRoles",gxold:"OV9DisplayInheritRoles",gxvar:"AV9DisplayInheritRoles",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV9DisplayInheritRoles=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV9DisplayInheritRoles=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vDISPLAYINHERITROLES",gx.O.AV9DisplayInheritRoles,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV9DisplayInheritRoles=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vDISPLAYINHERITROLES")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e120z1_client"};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e130z1_client"};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"GAM_FOOTERENTRY",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"GAM_FOOTERENTRY_TABLEBUTTONS",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"GAM_FOOTERENTRY_BTNCANCEL",grid:0,evt:"e220z1_client"};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"GAM_FOOTERENTRY_BTNCONFIRM",grid:0,evt:"e230z1_client"};
   this.AV23Search = "" ;
   this.ZV23Search = "" ;
   this.OV23Search = "" ;
   this.ZV18Name = "" ;
   this.OV18Name = "" ;
   this.ZV8BtnMainRole = "" ;
   this.OV8BtnMainRole = "" ;
   this.ZV7BtnDlt = "" ;
   this.OV7BtnDlt = "" ;
   this.ZV15GUID = "" ;
   this.OV15GUID = "" ;
   this.ZV16Id = 0 ;
   this.OV16Id = 0 ;
   this.AV9DisplayInheritRoles = false ;
   this.ZV9DisplayInheritRoles = false ;
   this.OV9DisplayInheritRoles = false ;
   this.AV23Search = "" ;
   this.AV9DisplayInheritRoles = false ;
   this.AV24UserGUID = "" ;
   this.AV18Name = "" ;
   this.AV8BtnMainRole = "" ;
   this.AV7BtnDlt = "" ;
   this.AV15GUID = "" ;
   this.AV16Id = 0 ;
   this.Events = {"e140z2_client": ["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK", true] ,"e180z2_client": ["VBTNDLT.CLICK", true] ,"e150z2_client": ["'ADDNEW'", true] ,"e190z2_client": ["VBTNMAINROLE.CLICK", true] ,"e200z2_client": ["ENTER", true] ,"e210z2_client": ["CANCEL", true] ,"e130z1_client": ["'APPLY'", false] ,"e120z1_client": ["'CLEARFILTERS'", false] ,"e110z1_client": ["'HIDE'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"AV7BtnDlt","fld":"vBTNDLT"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNDLT\u0027,\u0027Visible\u0027)","ctrl":"vBTNDLT","prop":"Visible"},{"av":"AV18Name","fld":"vNAME"},{"av":"AV8BtnMainRole","fld":"vBTNMAINROLE"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNMAINROLE\u0027,\u0027Visible\u0027)","ctrl":"vBTNMAINROLE","prop":"Visible"},{"av":"AV15GUID","fld":"vGUID"},{"av":"AV16Id","fld":"vID","pic":"ZZZZZZZZZZZ9","hsh":true}]];
   this.EvtParms["'APPLY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'CLEARFILTERS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["'HIDE'"] = [[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TOGGLEFILTERS","prop":"Tooltiptext"}]];
   this.EvtParms["GAM_HEADERWWBACKFILTERS_TABLEBACK.CLICK"] = [[{"av":"AV24UserGUID","fld":"vUSERGUID"}],[]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"},{"av":"AV16Id","fld":"vID","pic":"ZZZZZZZZZZZ9","hsh":true}],[{"ctrl":"WCMESSAGES"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"}]];
   this.EvtParms["'ADDNEW'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["VBTNMAINROLE.CLICK"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"},{"av":"AV16Id","fld":"vID","pic":"ZZZZZZZZZZZ9","hsh":true}],[{"ctrl":"WCMESSAGES"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV24UserGUID","fld":"vUSERGUID"},{"av":"AV9DisplayInheritRoles","fld":"vDISPLAYINHERITROLES"},{"av":"subGridww_Recordcount"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_FOOTERENTRY_TABLEBUTTONS\u0027,\u0027Visible\u0027)","ctrl":"GAM_FOOTERENTRY_TABLEBUTTONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vSEARCH\u0027,\u0027Visible\u0027)","ctrl":"vSEARCH","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_HEADERWWBACKFILTERS_TITLE\u0027,\u0027Caption\u0027)","ctrl":"GAM_HEADERWWBACKFILTERS_TITLE","prop":"Caption"},{"ctrl":"WCMESSAGES"}]];
   this.setVCMap("AV24UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV24UserGUID", "vUSERGUID", 0, "char", 40, 0);
   this.setVCMap("AV24UserGUID", "vUSERGUID", 0, "char", 40, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar({rfrVar:"AV24UserGUID"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[51]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV24UserGUID"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[51]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0059" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_wwuserroles);});
