/*
               File: GAM_WWUsers
        Description: GAM_Users
             Author: GeneXus .NET Generator version 18_0_9-182098
       Generated on: 4/19/2024 12:32:11.73
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwusers', false, function () {
   this.ServerClass =  "gam_wwusers" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.ServerFullClass =  "gam_wwusers.aspx" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.DSO =  "GAMDesignSystem" ;
   this.SetStandaloneVars=function()
   {
      this.AV41ShowLogicallyDeletedUsers=gx.fn.getControlValue("vSHOWLOGICALLYDELETEDUSERS") ;
      this.subGridww_Recordcount=gx.fn.getIntegerValue("subGridww_Recordcount",gx.thousandSeparator) ;
   };
   this.Validv_Filusergender=function()
   {
      return this.validCliEvt("Validv_Filusergender", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vFILUSERGENDER");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV18FilUserGender , "N" ) == 0 || gx.text.compare( this.AV18FilUserGender , "F" ) == 0 || gx.text.compare( this.AV18FilUserGender , "M" ) == 0 || (gx.text.compare('',this.AV18FilUserGender)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Filter User Gender"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Showusers=function()
   {
      return this.validCliEvt("Validv_Showusers", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vSHOWUSERS");
         this.AnyError  = 0;
         if ( ! ( gx.text.compare( this.AV43ShowUsers , "Active" ) == 0 || gx.text.compare( this.AV43ShowUsers , "Inactive" ) == 0 || gx.text.compare( this.AV43ShowUsers , "Blocked" ) == 0 || gx.text.compare( this.AV43ShowUsers , "Deleted" ) == 0 || gx.text.compare( this.AV43ShowUsers , "Disabled" ) == 0 || (gx.text.compare('',this.AV43ShowUsers)==0) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Show Users"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Userauthenticateddatefrom=function()
   {
      return this.validCliEvt("Validv_Userauthenticateddatefrom", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERAUTHENTICATEDDATEFROM");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV45UserAuthenticatedDateFrom)===0) || new gx.date.gxdate( this.AV45UserAuthenticatedDateFrom ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User Authenticated Date From"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Userauthenticateddateto=function()
   {
      return this.validCliEvt("Validv_Userauthenticateddateto", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERAUTHENTICATEDDATETO");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV46UserAuthenticatedDateTo)===0) || new gx.date.gxdate( this.AV46UserAuthenticatedDateTo ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User Authenticated Date To"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Userregisterdatefrom=function()
   {
      return this.validCliEvt("Validv_Userregisterdatefrom", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERREGISTERDATEFROM");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV48UserRegisterDateFrom)===0) || new gx.date.gxdate( this.AV48UserRegisterDateFrom ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User Register Date From"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Userregisterdateto=function()
   {
      return this.validCliEvt("Validv_Userregisterdateto", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERREGISTERDATETO");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV49UserRegisterDateTo)===0) || new gx.date.gxdate( this.AV49UserRegisterDateTo ).compare( gx.date.ymdhmstot( 1753, 1, 1, 0, 0, 0) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User Register Date To"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'SHOWMESSAGES' Routine */
         this.createWebComponent('Wcmessages','GAM_Messages',[]);
      }, arguments);
   };
   this.e11071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'AddNew' Routine */
         this.clearMessages();
         this.call("gam_userentry.aspx", ["INS", ""], null, ["Mode","UserGUID"]);
         this.refreshOutputs([]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e12071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Hide' Routine */
         this.clearMessages();
         if ( gx.text.compare( gx.fn.getCtrlProperty("GAM_FILTERSWW","Class") , "filters-container" ) == 0 )
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", gx.text.format( "%1 %2", "filters-container", "filters-container-floating--visible", "", "", "", "", "", "", "") );
            gx.fn.setCtrlProperty("GAM_ACTIONSSTENCIL_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Hidefilters") );
         }
         else
         {
            gx.fn.setCtrlProperty("GAM_FILTERSWW","Class", "filters-container" );
            gx.fn.setCtrlProperty("GAM_ACTIONSSTENCIL_TOGGLEFILTERS","Tooltiptext", gx.getMessage( "GAM_Showfilters") );
         }
         this.refreshOutputs([{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_ACTIONSSTENCIL_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_ACTIONSSTENCIL_TOGGLEFILTERS","prop":"Tooltiptext"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e21072_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Name_Click Routine */
         this.clearMessages();
         this.call("gam_userentry.aspx", ["DSP", this.AV47UserGUID], null, ["Mode","UserGUID"]);
         this.refreshOutputs([{"av":"AV47UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e22072_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Email_Click Routine */
         this.clearMessages();
         this.call("gam_userentry.aspx", ["DSP", this.AV47UserGUID], null, ["Mode","UserGUID"]);
         this.refreshOutputs([{"av":"AV47UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e25072_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Update' Routine */
         this.clearMessages();
         this.call("gam_userentry.aspx", ["UPD", this.AV47UserGUID], null, ["Mode","UserGUID"]);
         this.refreshOutputs([{"av":"AV47UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e24072_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UserPermissions' Routine */
         this.clearMessages();
         this.call("gam_wwuserpermissions.aspx", [this.AV47UserGUID, 0], null, ["UserGUID","pApplicationId"]);
         this.refreshOutputs([{"av":"AV47UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e23072_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'UserRoles' Routine */
         this.clearMessages();
         this.call("gam_wwuserroles.aspx", [this.AV47UserGUID], null, ["UserGUID"]);
         this.refreshOutputs([{"av":"AV47UserGUID","fld":"vUSERGUID"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e13071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'ClearFilters' Routine */
         this.clearMessages();
         this.AV52FilGUID =  ""  ;
         this.AV13FilAutType =  ""  ;
         this.AV14FilRol = gx.num.trunc( 0 ,0) ;
         this.AV18FilUserGender =  ''  ;
         this.AV41ShowLogicallyDeletedUsers =  false  ;
         this.AV45UserAuthenticatedDateFrom =  ''  ;
         this.AV46UserAuthenticatedDateTo =  ''  ;
         this.AV48UserRegisterDateFrom =  ''  ;
         this.AV49UserRegisterDateTo =  ''  ;
         this.AV10CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e26071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* Search_Controlvaluechanged Routine */
         this.clearMessages();
         this.AV10CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e14071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Apply' Routine */
         this.clearMessages();
         this.AV10CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e18071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'First' Routine */
         this.clearMessages();
         this.AV10CurrentPage = gx.num.trunc( 1 ,0) ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e19071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Previous' Routine */
         this.clearMessages();
         this.AV10CurrentPage = gx.num.trunc( this.AV10CurrentPage - 1 ,0) ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e20071_client=function()
   {
      return this.executeClientEvent(  function() {
         /* 'Next' Routine */
         this.clearMessages();
         this.AV10CurrentPage = gx.num.trunc( this.AV10CurrentPage + 1 ,0) ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.refreshGrid('Gridww') ;
         this.refreshOutputs([{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]);
         this.OnClientEventEnd();
      }, arguments);
   };
   this.e27072_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e28072_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,44,46,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114];
   this.GXLastCtrlId =114;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",25,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwusers",[],false,1,true,true,10,true,false,false,"",100,"%",0,"px",gx.getMessage( "GXM_newrow"),true,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",26,"vNAME",gx.getMessage( "GAM_UserName"),"","Name","char",300,"px",120,80,"start","e21072_client",[],"Name","Name",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addSingleLineEdit("Email",27,"vEMAIL",gx.getMessage( "GAM_Email"),"","Email","svchar",300,"px",100,80,"start","e22072_client",[],"Email","Email",true,0,false,false,"Attribute",0,"column");
   GridwwContainer.addSingleLineEdit("Firstname",28,"vFIRSTNAME",gx.getMessage( "GAM_FirstName"),"","FirstName","char",0,"px",120,80,"start",null,[],"Firstname","FirstName",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addSingleLineEdit("Lastname",29,"vLASTNAME",gx.getMessage( "GAM_LastName"),"","LastName","char",0,"px",120,80,"start",null,[],"Lastname","LastName",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addSingleLineEdit("Authenticationtypename",30,"vAUTHENTICATIONTYPENAME",gx.getMessage( "GAM_Authentication"),"","AuthenticationTypeName","char",0,"px",60,60,"start",null,[],"Authenticationtypename","AuthenticationTypeName",true,0,false,false,"Attribute",0,"column column-optional");
   GridwwContainer.addSingleLineEdit("Status",31,"vSTATUS",gx.getMessage( "GAM_Status"),"","Status","svchar",125,"px",40,40,"start",null,[],"Status","Status",true,0,false,false,"",0,"column column-optional");
   GridwwContainer.addSingleLineEdit("Btnroles",32,"vBTNROLES","","","BtnRoles","char",0,"px",20,20,"start","e23072_client",[],"Btnroles","BtnRoles",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btnpermissions",33,"vBTNPERMISSIONS","","","BtnPermissions","char",110,"px",20,20,"start","e24072_client",[],"Btnpermissions","BtnPermissions",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Btnupd",34,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"start","e25072_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute",0,"WWTextActionColumn column-optional");
   GridwwContainer.addSingleLineEdit("Userguid",35,"vUSERGUID",gx.getMessage( "GAM_GUID"),"","UserGUID","char",290,"px",40,40,"start",null,[],"Userguid","UserGUID",false,0,false,false,"Attribute",0,"");
   this.GridwwContainer.emptyText = gx.getMessage( "GAM_Noresultsfound");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"GAM_ACTIONSSTENCIL",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"GAM_ACTIONSSTENCIL_TABLEACTIONS",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"GAM_ACTIONSSTENCIL_TITLE", format:0,grid:0, ctrltype: "textblock"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"GAM_ACTIONSSTENCIL_ADDNEW",grid:0,evt:"e11071_client"};
   GXValidFnc[14]={ id: 14, fld:"CELLSEARCH",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id:16 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:'e26071_client',evt_cvcing:null,rgrid:[],fld:"vSEARCH",fmt:0,gxz:"ZV25Search",gxold:"OV25Search",gxvar:"AV25Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV25Search,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   this.declareDomainHdlr( 16 , function() {
   });
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"GAM_ACTIONSSTENCIL_TOGGLEFILTERS",grid:0,evt:"e12071_client"};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"SECTIONGRID",grid:0};
   GXValidFnc[22]={ id: 22, fld:"TABLEGRIDCONTAINER",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",fmt:0,gxz:"ZV21Name",gxold:"OV21Name",gxvar:"AV21Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV21Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV21Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV21Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e21072_client"};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"svchar",len:100,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vEMAIL",fmt:0,gxz:"ZV11Email",gxold:"OV11Email",gxvar:"AV11Email",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV11Email=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Email=Value},v2c:function(row){gx.fn.setGridControlValue("vEMAIL",row || gx.fn.currentGridRowImpl(25),gx.O.AV11Email,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Email=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vEMAIL",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e22072_client"};
   GXValidFnc[28]={ id:28 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFIRSTNAME",fmt:0,gxz:"ZV19FirstName",gxold:"OV19FirstName",gxvar:"AV19FirstName",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV19FirstName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19FirstName=Value},v2c:function(row){gx.fn.setGridControlValue("vFIRSTNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV19FirstName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV19FirstName=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vFIRSTNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[29]={ id:29 ,lvl:2,type:"char",len:120,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLASTNAME",fmt:0,gxz:"ZV20LastName",gxold:"OV20LastName",gxvar:"AV20LastName",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV20LastName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20LastName=Value},v2c:function(row){gx.fn.setGridControlValue("vLASTNAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV20LastName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV20LastName=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vLASTNAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[30]={ id:30 ,lvl:2,type:"char",len:60,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAUTHENTICATIONTYPENAME",fmt:0,gxz:"ZV6AuthenticationTypeName",gxold:"OV6AuthenticationTypeName",gxvar:"AV6AuthenticationTypeName",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6AuthenticationTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6AuthenticationTypeName=Value},v2c:function(row){gx.fn.setGridControlValue("vAUTHENTICATIONTYPENAME",row || gx.fn.currentGridRowImpl(25),gx.O.AV6AuthenticationTypeName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6AuthenticationTypeName=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vAUTHENTICATIONTYPENAME",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[31]={ id:31 ,lvl:2,type:"svchar",len:40,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSTATUS",fmt:0,gxz:"ZV44Status",gxold:"OV44Status",gxvar:"AV44Status",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV44Status=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV44Status=Value},v2c:function(row){gx.fn.setGridControlValue("vSTATUS",row || gx.fn.currentGridRowImpl(25),gx.O.AV44Status,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV44Status=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vSTATUS",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[32]={ id:32 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNROLES",fmt:0,gxz:"ZV32BtnRoles",gxold:"OV32BtnRoles",gxvar:"AV32BtnRoles",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV32BtnRoles=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32BtnRoles=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNROLES",row || gx.fn.currentGridRowImpl(25),gx.O.AV32BtnRoles,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV32BtnRoles=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNROLES",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e23072_client"};
   GXValidFnc[33]={ id:33 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNPERMISSIONS",fmt:0,gxz:"ZV31BtnPermissions",gxold:"OV31BtnPermissions",gxvar:"AV31BtnPermissions",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV31BtnPermissions=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31BtnPermissions=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNPERMISSIONS",row || gx.fn.currentGridRowImpl(25),gx.O.AV31BtnPermissions,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV31BtnPermissions=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNPERMISSIONS",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e24072_client"};
   GXValidFnc[34]={ id:34 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",fmt:0,gxz:"ZV8BtnUpd",gxold:"OV8BtnUpd",gxvar:"AV8BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV8BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV8BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(25),gx.O.AV8BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV8BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn,evt:"e25072_client"};
   GXValidFnc[35]={ id:35 ,lvl:2,type:"char",len:40,dec:0,sign:false,ro:0,isacc:0,grid:25,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERGUID",fmt:0,gxz:"ZV47UserGUID",gxold:"OV47UserGUID",gxvar:"AV47UserGUID",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV47UserGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV47UserGUID=Value},v2c:function(row){gx.fn.setGridControlValue("vUSERGUID",row || gx.fn.currentGridRowImpl(25),gx.O.AV47UserGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV47UserGUID=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vUSERGUID",row || gx.fn.currentGridRowImpl(25))},nac:gx.falseFn};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"GAM_PAGINGWW",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"GAM_PAGINGWW_TBLPAGINGBUTTONS",grid:0};
   GXValidFnc[44]={ id: 44, fld:"GAM_PAGINGWW_BTNFIRST",grid:0,evt:"e18071_client"};
   GXValidFnc[46]={ id: 46, fld:"GAM_PAGINGWW_BTNPREVIOUS",grid:0,evt:"e19071_client"};
   GXValidFnc[48]={ id: 48, fld:"GAM_PAGINGWW_BTNNEXT",grid:0,evt:"e20071_client"};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id:52 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",fmt:0,gxz:"ZV10CurrentPage",gxold:"OV10CurrentPage",gxvar:"AV10CurrentPage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV10CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV10CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id:55 ,lvl:0,type:"svchar",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPAGINATIONTOKEN",fmt:0,gxz:"ZV51PaginationToken",gxold:"OV51PaginationToken",gxvar:"AV51PaginationToken",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV51PaginationToken=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV51PaginationToken=Value},v2c:function(){gx.fn.setControlValue("vPAGINATIONTOKEN",gx.O.AV51PaginationToken,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV51PaginationToken=this.val()},val:function(){return gx.fn.getControlValue("vPAGINATIONTOKEN")},nac:gx.falseFn};
   GXValidFnc[56]={ id: 56, fld:"GAM_FILTERSWW",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"GAM_FILTERSWW_HIDEFILTERS",grid:0,evt:"e12071_client"};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"GAM_FILTERSWW_TABLEFILTERS",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id:67 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILGUID",fmt:0,gxz:"ZV52FilGUID",gxold:"OV52FilGUID",gxvar:"AV52FilGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV52FilGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV52FilGUID=Value},v2c:function(){gx.fn.setControlValue("vFILGUID",gx.O.AV52FilGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV52FilGUID=this.val()},val:function(){return gx.fn.getControlValue("vFILGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 67 , function() {
   });
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id:72 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILAUTTYPE",fmt:0,gxz:"ZV13FilAutType",gxold:"OV13FilAutType",gxvar:"AV13FilAutType",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV13FilAutType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13FilAutType=Value},v2c:function(){gx.fn.setComboBoxValue("vFILAUTTYPE",gx.O.AV13FilAutType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13FilAutType=this.val()},val:function(){return gx.fn.getControlValue("vFILAUTTYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 72 , function() {
   });
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id:77 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILROL",fmt:0,gxz:"ZV14FilRol",gxold:"OV14FilRol",gxvar:"AV14FilRol",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV14FilRol=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV14FilRol=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vFILROL",gx.O.AV14FilRol);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14FilRol=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vFILROL",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 77 , function() {
   });
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id:82 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Filusergender,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILUSERGENDER",fmt:0,gxz:"ZV18FilUserGender",gxold:"OV18FilUserGender",gxvar:"AV18FilUserGender",ucs:[],op:[82],ip:[82],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV18FilUserGender=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18FilUserGender=Value},v2c:function(){gx.fn.setComboBoxValue("vFILUSERGENDER",gx.O.AV18FilUserGender);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV18FilUserGender=this.val()},val:function(){return gx.fn.getControlValue("vFILUSERGENDER")},nac:gx.falseFn};
   this.declareDomainHdlr( 82 , function() {
   });
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id: 86, fld:"",grid:0};
   GXValidFnc[87]={ id:87 ,lvl:0,type:"svchar",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Showusers,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSHOWUSERS",fmt:0,gxz:"ZV43ShowUsers",gxold:"OV43ShowUsers",gxvar:"AV43ShowUsers",ucs:[],op:[87],ip:[87],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV43ShowUsers=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV43ShowUsers=Value},v2c:function(){gx.fn.setComboBoxValue("vSHOWUSERS",gx.O.AV43ShowUsers);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV43ShowUsers=this.val()},val:function(){return gx.fn.getControlValue("vSHOWUSERS")},nac:gx.falseFn};
   this.declareDomainHdlr( 87 , function() {
   });
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id:92 ,lvl:0,type:"dtime",len:10,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Userauthenticateddatefrom,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERAUTHENTICATEDDATEFROM",fmt:0,gxz:"ZV45UserAuthenticatedDateFrom",gxold:"OV45UserAuthenticatedDateFrom",gxvar:"AV45UserAuthenticatedDateFrom",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/9999 99:99",dec:5},ucs:[],op:[92],ip:[92],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV45UserAuthenticatedDateFrom=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV45UserAuthenticatedDateFrom=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vUSERAUTHENTICATEDDATEFROM",gx.O.AV45UserAuthenticatedDateFrom,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV45UserAuthenticatedDateFrom=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vUSERAUTHENTICATEDDATEFROM")},nac:gx.falseFn};
   this.declareDomainHdlr( 92 , function() {
   });
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id: 94, fld:"",grid:0};
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id:97 ,lvl:0,type:"dtime",len:10,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Userauthenticateddateto,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERAUTHENTICATEDDATETO",fmt:0,gxz:"ZV46UserAuthenticatedDateTo",gxold:"OV46UserAuthenticatedDateTo",gxvar:"AV46UserAuthenticatedDateTo",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/9999 99:99",dec:5},ucs:[],op:[97],ip:[97],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV46UserAuthenticatedDateTo=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV46UserAuthenticatedDateTo=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vUSERAUTHENTICATEDDATETO",gx.O.AV46UserAuthenticatedDateTo,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV46UserAuthenticatedDateTo=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vUSERAUTHENTICATEDDATETO")},nac:gx.falseFn};
   this.declareDomainHdlr( 97 , function() {
   });
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id: 99, fld:"",grid:0};
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id:102 ,lvl:0,type:"dtime",len:10,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Userregisterdatefrom,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERREGISTERDATEFROM",fmt:0,gxz:"ZV48UserRegisterDateFrom",gxold:"OV48UserRegisterDateFrom",gxvar:"AV48UserRegisterDateFrom",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/9999 99:99",dec:5},ucs:[],op:[102],ip:[102],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV48UserRegisterDateFrom=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV48UserRegisterDateFrom=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vUSERREGISTERDATEFROM",gx.O.AV48UserRegisterDateFrom,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV48UserRegisterDateFrom=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vUSERREGISTERDATEFROM")},nac:gx.falseFn};
   this.declareDomainHdlr( 102 , function() {
   });
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id: 104, fld:"",grid:0};
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id: 106, fld:"",grid:0};
   GXValidFnc[107]={ id:107 ,lvl:0,type:"dtime",len:10,dec:5,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Userregisterdateto,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERREGISTERDATETO",fmt:0,gxz:"ZV49UserRegisterDateTo",gxold:"OV49UserRegisterDateTo",gxvar:"AV49UserRegisterDateTo",dp:{f:0,st:true,wn:false,mf:false,pic:"99/99/9999 99:99",dec:5},ucs:[],op:[107],ip:[107],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV49UserRegisterDateTo=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV49UserRegisterDateTo=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vUSERREGISTERDATETO",gx.O.AV49UserRegisterDateTo,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV49UserRegisterDateTo=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getDateTimeValue("vUSERREGISTERDATETO")},nac:gx.falseFn};
   this.declareDomainHdlr( 107 , function() {
   });
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id: 109, fld:"",grid:0};
   GXValidFnc[110]={ id: 110, fld:"GAM_FILTERSWW_CLEARFILTERS",grid:0,evt:"e13071_client"};
   GXValidFnc[111]={ id: 111, fld:"",grid:0};
   GXValidFnc[112]={ id: 112, fld:"GAM_FILTERSWW_APPLY",grid:0,evt:"e14071_client"};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id: 114, fld:"",grid:0};
   this.AV25Search = "" ;
   this.ZV25Search = "" ;
   this.OV25Search = "" ;
   this.ZV21Name = "" ;
   this.OV21Name = "" ;
   this.ZV11Email = "" ;
   this.OV11Email = "" ;
   this.ZV19FirstName = "" ;
   this.OV19FirstName = "" ;
   this.ZV20LastName = "" ;
   this.OV20LastName = "" ;
   this.ZV6AuthenticationTypeName = "" ;
   this.OV6AuthenticationTypeName = "" ;
   this.ZV44Status = "" ;
   this.OV44Status = "" ;
   this.ZV32BtnRoles = "" ;
   this.OV32BtnRoles = "" ;
   this.ZV31BtnPermissions = "" ;
   this.OV31BtnPermissions = "" ;
   this.ZV8BtnUpd = "" ;
   this.OV8BtnUpd = "" ;
   this.ZV47UserGUID = "" ;
   this.OV47UserGUID = "" ;
   this.AV10CurrentPage = 0 ;
   this.ZV10CurrentPage = 0 ;
   this.OV10CurrentPage = 0 ;
   this.AV51PaginationToken = "" ;
   this.ZV51PaginationToken = "" ;
   this.OV51PaginationToken = "" ;
   this.AV52FilGUID = "" ;
   this.ZV52FilGUID = "" ;
   this.OV52FilGUID = "" ;
   this.AV13FilAutType = "" ;
   this.ZV13FilAutType = "" ;
   this.OV13FilAutType = "" ;
   this.AV14FilRol = 0 ;
   this.ZV14FilRol = 0 ;
   this.OV14FilRol = 0 ;
   this.AV18FilUserGender = "" ;
   this.ZV18FilUserGender = "" ;
   this.OV18FilUserGender = "" ;
   this.AV43ShowUsers = "" ;
   this.ZV43ShowUsers = "" ;
   this.OV43ShowUsers = "" ;
   this.AV45UserAuthenticatedDateFrom = gx.date.nullDate() ;
   this.ZV45UserAuthenticatedDateFrom = gx.date.nullDate() ;
   this.OV45UserAuthenticatedDateFrom = gx.date.nullDate() ;
   this.AV46UserAuthenticatedDateTo = gx.date.nullDate() ;
   this.ZV46UserAuthenticatedDateTo = gx.date.nullDate() ;
   this.OV46UserAuthenticatedDateTo = gx.date.nullDate() ;
   this.AV48UserRegisterDateFrom = gx.date.nullDate() ;
   this.ZV48UserRegisterDateFrom = gx.date.nullDate() ;
   this.OV48UserRegisterDateFrom = gx.date.nullDate() ;
   this.AV49UserRegisterDateTo = gx.date.nullDate() ;
   this.ZV49UserRegisterDateTo = gx.date.nullDate() ;
   this.OV49UserRegisterDateTo = gx.date.nullDate() ;
   this.AV25Search = "" ;
   this.AV10CurrentPage = 0 ;
   this.AV51PaginationToken = "" ;
   this.AV52FilGUID = "" ;
   this.AV13FilAutType = "" ;
   this.AV14FilRol = 0 ;
   this.AV18FilUserGender = "" ;
   this.AV43ShowUsers = "" ;
   this.AV45UserAuthenticatedDateFrom = gx.date.nullDate() ;
   this.AV46UserAuthenticatedDateTo = gx.date.nullDate() ;
   this.AV48UserRegisterDateFrom = gx.date.nullDate() ;
   this.AV49UserRegisterDateTo = gx.date.nullDate() ;
   this.AV21Name = "" ;
   this.AV11Email = "" ;
   this.AV19FirstName = "" ;
   this.AV20LastName = "" ;
   this.AV6AuthenticationTypeName = "" ;
   this.AV44Status = "" ;
   this.AV32BtnRoles = "" ;
   this.AV31BtnPermissions = "" ;
   this.AV8BtnUpd = "" ;
   this.AV47UserGUID = "" ;
   this.AV41ShowLogicallyDeletedUsers = false ;
   this.Events = {"e27072_client": ["ENTER", true] ,"e28072_client": ["CANCEL", true] ,"e11071_client": ["'ADDNEW'", false] ,"e12071_client": ["'HIDE'", false] ,"e21072_client": ["VNAME.CLICK", false] ,"e22072_client": ["VEMAIL.CLICK", false] ,"e25072_client": ["'UPDATE'", false] ,"e24072_client": ["'USERPERMISSIONS'", false] ,"e23072_client": ["'USERROLES'", false] ,"e13071_client": ["'CLEARFILTERS'", false] ,"e26071_client": ["VSEARCH.CONTROLVALUECHANGED", false] ,"e14071_client": ["'APPLY'", false] ,"e18071_client": ["'FIRST'", false] ,"e19071_client": ["'PREVIOUS'", false] ,"e20071_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV32BtnRoles","fld":"vBTNROLES"},{"av":"AV31BtnPermissions","fld":"vBTNPERMISSIONS"},{"av":"AV8BtnUpd","fld":"vBTNUPD"},{"av":"AV6AuthenticationTypeName","fld":"vAUTHENTICATIONTYPENAME"},{"av":"AV47UserGUID","fld":"vUSERGUID"},{"av":"AV21Name","fld":"vNAME"},{"av":"AV19FirstName","fld":"vFIRSTNAME"},{"av":"AV20LastName","fld":"vLASTNAME"},{"av":"AV11Email","fld":"vEMAIL"},{"av":"AV44Status","fld":"vSTATUS"},{"av":"gx.fn.getCtrlProperty(\u0027vSTATUS\u0027,\u0027Class\u0027)","ctrl":"vSTATUS","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNROLES\u0027,\u0027Visible\u0027)","ctrl":"vBTNROLES","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNPERMISSIONS\u0027,\u0027Visible\u0027)","ctrl":"vBTNPERMISSIONS","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vBTNUPD\u0027,\u0027Visible\u0027)","ctrl":"vBTNUPD","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vNAME\u0027,\u0027Visible\u0027)","ctrl":"vNAME","prop":"Visible"},{"av":"gx.fn.getCtrlProperty(\u0027vEMAIL\u0027,\u0027Visible\u0027)","ctrl":"vEMAIL","prop":"Visible"},{"ctrl":"GAM_PAGINGWW_BTNNEXT","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNFIRST","prop":"Enabled"},{"ctrl":"GAM_PAGINGWW_BTNPREVIOUS","prop":"Enabled"}]];
   this.EvtParms["'ADDNEW'"] = [[],[]];
   this.EvtParms["'HIDE'"] = [[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"}],[{"av":"gx.fn.getCtrlProperty(\u0027GAM_FILTERSWW\u0027,\u0027Class\u0027)","ctrl":"GAM_FILTERSWW","prop":"Class"},{"av":"gx.fn.getCtrlProperty(\u0027GAM_ACTIONSSTENCIL_TOGGLEFILTERS\u0027,\u0027Tooltiptext\u0027)","ctrl":"GAM_ACTIONSSTENCIL_TOGGLEFILTERS","prop":"Tooltiptext"}]];
   this.EvtParms["VNAME.CLICK"] = [[{"av":"AV47UserGUID","fld":"vUSERGUID"}],[{"av":"AV47UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["VEMAIL.CLICK"] = [[{"av":"AV47UserGUID","fld":"vUSERGUID"}],[{"av":"AV47UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'UPDATE'"] = [[{"av":"AV47UserGUID","fld":"vUSERGUID"}],[{"av":"AV47UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'USERPERMISSIONS'"] = [[{"av":"AV47UserGUID","fld":"vUSERGUID"}],[{"av":"AV47UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'USERROLES'"] = [[{"av":"AV47UserGUID","fld":"vUSERGUID"}],[{"av":"AV47UserGUID","fld":"vUSERGUID"}]];
   this.EvtParms["'CLEARFILTERS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["VSEARCH.CONTROLVALUECHANGED"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'APPLY'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'FIRST'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'PREVIOUS'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["'NEXT'"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"}]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["GRIDWW_FIRSTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[]];
   this.EvtParms["GRIDWW_PREVPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[]];
   this.EvtParms["GRIDWW_NEXTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true}],[]];
   this.EvtParms["GRIDWW_LASTPAGE"] = [[{"av":"GRIDWW_nFirstRecordOnPage"},{"av":"GRIDWW_nEOF"},{"av":"","ctrl":"GRIDWW","prop":"Rows"},{"av":"AV52FilGUID","fld":"vFILGUID"},{"ctrl":"vFILAUTTYPE"},{"av":"AV13FilAutType","fld":"vFILAUTTYPE"},{"ctrl":"vFILROL"},{"av":"AV14FilRol","fld":"vFILROL","pic":"ZZZZZZZZZZZ9"},{"ctrl":"vFILUSERGENDER"},{"av":"AV18FilUserGender","fld":"vFILUSERGENDER"},{"av":"AV45UserAuthenticatedDateFrom","fld":"vUSERAUTHENTICATEDDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV46UserAuthenticatedDateTo","fld":"vUSERAUTHENTICATEDDATETO","pic":"99/99/9999 99:99"},{"av":"AV48UserRegisterDateFrom","fld":"vUSERREGISTERDATEFROM","pic":"99/99/9999 99:99"},{"av":"AV49UserRegisterDateTo","fld":"vUSERREGISTERDATETO","pic":"99/99/9999 99:99"},{"ctrl":"vSHOWUSERS"},{"av":"AV43ShowUsers","fld":"vSHOWUSERS"},{"av":"AV25Search","fld":"vSEARCH"},{"av":"AV10CurrentPage","fld":"vCURRENTPAGE","pic":"ZZZ9"},{"av":"AV51PaginationToken","fld":"vPAGINATIONTOKEN","hsh":true},{"av":"subGridww_Recordcount"}],[]];
   this.EvtParms["VALIDV_FILUSERGENDER"] = [[],[]];
   this.EvtParms["VALIDV_SHOWUSERS"] = [[],[]];
   this.EvtParms["VALIDV_USERAUTHENTICATEDDATEFROM"] = [[],[]];
   this.EvtParms["VALIDV_USERAUTHENTICATEDDATETO"] = [[],[]];
   this.EvtParms["VALIDV_USERREGISTERDATEFROM"] = [[],[]];
   this.EvtParms["VALIDV_USERREGISTERDATETO"] = [[],[]];
   this.setVCMap("AV41ShowLogicallyDeletedUsers", "vSHOWLOGICALLYDELETEDUSERS", 0, "boolean", 1, 0);
   GridwwContainer.addRefreshingParm({rfrProp:"Rows", gxGrid:"Gridww"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[67]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[72]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[77]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[82]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[92]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[97]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[102]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[107]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[87]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[52]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[55]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[67]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[72]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[77]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[82]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[92]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[97]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[102]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[107]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[87]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[16]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[52]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[55]);
   this.Initialize( );
   this.setComponent({id: "WCMESSAGES" ,GXClass: null , Prefix: "W0115" , lvl: 1 });
});
gx.wi( function() { gx.createParentObj(this.gam_wwusers);});
